// ============================================================
// clip-sync.js — ☁️ Cloud Sync: ส่งคลิปจาก PC เข้าแอพมือถือ Ai Affiliate Shopee
// มือถือรับคลิป → โพสต์ Shopee Video + ปักตะกร้าให้อัตโนมัติ (เข้าถึงผ่าน window.ASUClipSync)
// รองรับทั้ง Supabase โปรเจกต์เดิม และ Custom Supabase โปรเจกต์ใหม่ของผู้ใช้
// ============================================================
(function () {
  'use strict';

  const DEFAULT_SUPABASE_URL = 'https://guhdweujxgsbflkvgryb.supabase.co';
  const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_Jk_pcsCymh1jJrmnBMJUhw_H_UqTpTx';
  const SETTINGS_KEY = 'asu-clip-sync-settings';
  const LOG_KEY = 'asu-clip-sync-log';

  // เพดานแคปชั่นและแท็กของ Shopee Video (App v3.7.8+: 480 ตัวอักษร, แท็ก 140 ตัวอักษร)
  const CAP_CAPTION = 480;
  const CAP_TAGS = 140;

  const STATUS_TH = {
    uploading: '⏳ กำลังอัปโหลด…',
    upload_failed: '❌ อัปโหลดล้มเหลว',
    sent: '☁️ ส่งขึ้นคลาวด์แล้ว',
    ready: '📡 รอมือถือดึงคลิป',
    downloaded: '📲 มือถือรับคลิปแล้ว',
    queued: '🗂️ เข้าคิวโพสต์',
    posting: '🚀 กำลังโพสต์ Shopee…',
    posted: '✅ โพสต์แล้ว',
    failed: '❌ โพสต์ไม่สำเร็จ',
    expired: '⌛ หมดอายุ'
  };

  function normalizePairCode(s) {
    const raw = String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
    if (raw.length !== 12) return '';
    return raw.slice(0, 4) + '-' + raw.slice(4, 8) + '-' + raw.slice(8, 12);
  }

  function generatePairCode() {
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let code = '';
    const array = new Uint8Array(12);
    if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
      crypto.getRandomValues(array);
      for (let i = 0; i < 12; i++) {
        code += chars[array[i] % chars.length];
      }
    } else {
      for (let i = 0; i < 12; i++) {
        code += chars[Math.floor(Math.random() * chars.length)];
      }
    }
    return code.slice(0, 4) + '-' + code.slice(4, 8) + '-' + code.slice(8, 12);
  }

  async function getClipSyncSettings() {
    try {
      const stored = await chrome.storage.local.get(SETTINGS_KEY);
      const s = (stored && stored[SETTINGS_KEY]) || {};

      let devices = Array.isArray(s.devices) ? s.devices : null;
      if (!devices || devices.length === 0) {
        const initialCode = (s.pairCode && normalizePairCode(s.pairCode)) || 'RC6N-WPVW-M34P';
        devices = [
          {
            id: 'dev_1',
            name: 'เครื่องที่ 1 (OPPO)',
            pairCode: initialCode,
            isDefault: true,
            addedAt: Date.now()
          }
        ];
      }

      let defaultDev = devices.find(d => d.id === s.activeDeviceId) || devices.find(d => d.isDefault) || devices[0];
      if (defaultDev) {
        devices.forEach(d => { d.isDefault = (d.id === defaultDev.id); });
      }

      const activePairCode = defaultDev ? defaultDev.pairCode : (s.pairCode || '');

      return {
        enabled: s.enabled !== undefined ? !!s.enabled : true,
        pairCode: activePairCode,
        activeDeviceId: defaultDev ? defaultDev.id : (s.activeDeviceId || 'dev_1'),
        devices: devices,
        autoStart: s.autoStart !== false,
        lastCheck: s.lastCheck || null,
        supabaseUrl: DEFAULT_SUPABASE_URL,
        supabaseAnonKey: DEFAULT_SUPABASE_ANON_KEY
      };
    } catch (_) {
      const fallbackCode = 'RC6N-WPVW-M34P';
      return {
        enabled: true,
        pairCode: fallbackCode,
        activeDeviceId: 'dev_1',
        devices: [
          {
            id: 'dev_1',
            name: 'เครื่องที่ 1 (OPPO)',
            pairCode: fallbackCode,
            isDefault: true,
            addedAt: Date.now()
          }
        ],
        autoStart: true,
        lastCheck: null,
        supabaseUrl: DEFAULT_SUPABASE_URL,
        supabaseAnonKey: DEFAULT_SUPABASE_ANON_KEY
      };
    }
  }

  async function saveClipSyncSettings(patch) {
    const current = await getClipSyncSettings();
    const next = Object.assign({}, current, patch || {});
    if (Array.isArray(next.devices) && next.devices.length > 0) {
      let defaultDev = next.devices.find(d => d.id === next.activeDeviceId) || next.devices.find(d => d.isDefault) || next.devices[0];
      if (defaultDev) {
        next.devices.forEach(d => { d.isDefault = (d.id === defaultDev.id); });
        next.activeDeviceId = defaultDev.id;
        next.pairCode = defaultDev.pairCode;
      }
    }
    try {
      await chrome.storage.local.set({ [SETTINGS_KEY]: next });
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('asu-devices-changed', { detail: next }));
      }
    } catch (_) {}
    return next;
  }

  async function addClipSyncDevice(name, pairCode) {
    const code = normalizePairCode(pairCode);
    if (!code) throw new Error('รหัสจับคู่ไม่ถูกต้อง (ต้องเป็น 12 ตัวอักษร เช่น XXXX-XXXX-XXXX)');
    const s = await getClipSyncSettings();
    const devices = Array.isArray(s.devices) ? [...s.devices] : [];
    const existing = devices.find(d => d.pairCode === code);
    if (existing) {
      throw new Error(`รหัส ${code} มีอยู่ในรายการแล้ว (${existing.name})`);
    }
    const newDev = {
      id: 'dev_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      name: (name || '').trim() || `เครื่องที่ ${devices.length + 1}`,
      pairCode: code,
      isDefault: devices.length === 0,
      addedAt: Date.now()
    };
    devices.push(newDev);
    return await saveClipSyncSettings({ devices, enabled: true });
  }

  async function removeClipSyncDevice(deviceId) {
    const s = await getClipSyncSettings();
    let devices = Array.isArray(s.devices) ? [...s.devices] : [];
    if (devices.length <= 1) {
      throw new Error('ต้องมีอุปกรณ์อย่างน้อย 1 เครื่อง');
    }
    devices = devices.filter(d => d.id !== deviceId);
    if (!devices.some(d => d.isDefault)) {
      devices[0].isDefault = true;
    }
    return await saveClipSyncSettings({ devices });
  }

  async function setDefaultClipSyncDevice(deviceId) {
    const s = await getClipSyncSettings();
    const devices = Array.isArray(s.devices) ? [...s.devices] : [];
    devices.forEach(d => {
      d.isDefault = (d.id === deviceId);
    });
    return await saveClipSyncSettings({ devices, activeDeviceId: deviceId });
  }

  function sanitizeVideoName(mode, rowNumber, productName) {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const stamp = '' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) +
      '_' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
    const slug = String(productName || 'clip')
      .replace(/[\\/:*?"<>|]+/g, '_')
      .replace(/\s+/g, '_')
      .slice(0, 40);
    const rand4 = Math.random().toString(36).slice(2, 6);
    return 'ASU_' + stamp + '_' + (mode || 'clip') + '_' + (rowNumber || 0) + '_' + slug + '_' + rand4 + '.mp4';
  }

  function resolveClipSyncProductUrl(product) {
    const p = product || {};
    const raw = p.raw || {};
    const pm = p.lastPostMeta || {};
    const url = p.affiliateUrl || p.warehouseShopeeProductUrl || p.productUrl || p.url || p.pageUrl ||
      p.link || p.productLink || p.shortLink || p.offerUrl ||
      raw.affiliateUrl || raw.warehouseShopeeProductUrl || raw.productUrl || raw.url || raw.pageUrl ||
      raw.link || raw.productLink || raw.shortLink || raw.offerUrl ||
      pm.productUrl || pm.affiliateUrl || pm.url || '';
    return typeof url === 'string' ? url.trim() : '';
  }

  async function callEdge(fn, body, customUrl, customAnon, timeoutMs) {
    const settings = await getClipSyncSettings();
    const url = ((customUrl || settings.supabaseUrl || DEFAULT_SUPABASE_URL).replace(/\/+$/, '')) + '/functions/v1/' + fn;
    const anon = customAnon || settings.supabaseAnonKey || DEFAULT_SUPABASE_ANON_KEY;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs || 20000);
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': anon,
          'Authorization': 'Bearer ' + anon
        },
        body: JSON.stringify(body || {}),
        signal: controller.signal
      });
      const json = await res.json().catch(() => ({}));
      return json && typeof json === 'object' ? json : { ok: false, error: 'bad_response' };
    } finally {
      clearTimeout(timer);
    }
  }

  async function appendLocalLog(entry) {
    try {
      const stored = await chrome.storage.local.get(LOG_KEY);
      const list = Array.isArray(stored && stored[LOG_KEY]) ? stored[LOG_KEY] : [];
      list.unshift(entry);
      await chrome.storage.local.set({ [LOG_KEY]: list.slice(0, 20) });
    } catch (_) {}
  }

  // ── จุดเรียกหลัก: ส่งคลิป (DataURL / Base64 / storageUrl) + ข้อมูลสินค้า เข้ามือถือ ──
  async function pushClipToRelay(videoSource, meta) {
    const settings = await getClipSyncSettings();
    if (!settings.enabled) return { skipped: true, reason: 'disabled' };
    const m = meta || {};
    const pairCode = m.pairCode || settings.pairCode;
    if (!pairCode) return { skipped: true, reason: 'no_pair_code' };

    const videoName = sanitizeVideoName(m.sourceMode || 'phimbot', m.rowNumber || 1, m.productTitle || m.productName);

    // ตัดแต่งแท็ก (ตัดที่ช่องว่าง) และแคปชั่น (ตัดที่ขอบคำ)
    const fitTagsWhole = (value, max) => {
      const t = String(value || '').trim();
      if (t.length <= max) return t;
      let out = '';
      for (const tag of t.split(/\s+/)) {
        if (!tag) continue;
        const extra = (out ? 1 : 0) + tag.length;
        if (out.length + extra > max) break;
        out += (out ? ' ' : '') + tag;
      }
      return out;
    };

    const fitCaptionWordEdge = (value, max) => {
      const t = String(value || '').trim();
      if (max <= 0) return '';
      if (t.length <= max) return t;
      let cut = t.slice(0, max);
      const lastSpace = Math.max(cut.lastIndexOf(' '), cut.lastIndexOf('\n'));
      if (lastSpace >= Math.max(20, max - 60)) cut = cut.slice(lastSpace);
      return cut.trim();
    };

    // กรองคำที่เกี่ยวกับ TikTok ออกสำหรับโพสต์ Shopee Video
    const _sanitizedTags = (Array.isArray(m.hashtags) ? m.hashtags.join(' ') : String(m.hashtags || ''))
      .split(/\s+/).filter(t => t && !/tiktok|tik[_-]?tok|ติ๊กต๊อก|douyin|โต่วอิน|^#?fyp$|foryou|foryoupage/i.test(t)).join(' ');
    const fittedTags = fitTagsWhole(_sanitizedTags, CAP_TAGS);
    const fittedCaption = fitCaptionWordEdge(m.caption, CAP_CAPTION - (fittedTags ? fittedTags.length + 1 : 0));

    // ตรวจสอบแหล่งที่มาของวิดีโอ
    let videoBase64 = m.videoBase64 || '';
    let storageUrl = '';
    if (typeof videoSource === 'string') {
      if (videoSource.startsWith('data:') || videoSource.length > 500) {
        videoBase64 = videoSource;
      } else if (videoSource.startsWith('storage:')) {
        storageUrl = videoSource;
      }
    }

    const payload = {
      storageUrl: storageUrl,
      videoBase64: videoBase64,
      pairCode: pairCode,
      clientRef: (crypto.randomUUID ? crypto.randomUUID() : (Date.now() + '-' + Math.random().toString(36).slice(2))),
      videoName: videoName,
      sourceMode: String(m.sourceMode || 'phimbot'),
      supabaseUrl: settings.supabaseUrl || DEFAULT_SUPABASE_URL,
      supabaseAnonKey: settings.supabaseAnonKey || DEFAULT_SUPABASE_ANON_KEY,
      meta: {
        productTitle: String(m.productTitle || m.productName || ''),
        productUrl: String(m.productUrl || ''),
        caption: fittedCaption,
        hashtags: fittedTags,
        basketName: String(m.basketName || ''),
        cta: String(m.cta || ''),
        autoStart: settings.autoStart !== false
      }
    };

    return await new Promise((resolve) => {
      let done = false;
      const timer = setTimeout(() => {
        if (!done) { done = true; resolve({ success: false, error: 'Sync timeout (Service Worker ไม่ตอบกลับใน 30 วินาที)' }); }
      }, 30000);

      try {
        chrome.runtime.sendMessage({ type: 'ASU_UPLOAD_CLIP_TO_RELAY', data: payload }, (res) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
            return;
          }
          resolve(Object.assign({ clientRef: payload.clientRef }, res || { success: false, error: 'no response' }));
        });
      } catch (err) {
        if (!done) {
          done = true;
          clearTimeout(timer);
          resolve({ success: false, error: err && err.message || String(err) });
        }
      }
    });
  }

  async function testClipSyncConnection(pairCode, customUrl, customKey) {
    const code = normalizePairCode(pairCode);
    if (!code) return { ok: false, error: 'bad_format' };
    try {
      const settings = await getClipSyncSettings();
      const base = (customUrl || settings.supabaseUrl || DEFAULT_SUPABASE_URL).replace(/\/+$/, '');
      const anon = customKey || settings.supabaseAnonKey || DEFAULT_SUPABASE_ANON_KEY;

      // 1. ตรวจสอบผ่าน Supabase PostgREST โดยตรง (รวดเร็วและแม่นยำ ไม่ต้องพึ่งพา Edge Function)
      try {
        const restRes = await fetch(`${base}/rest/v1/pair_codes?pair_code=eq.${encodeURIComponent(code)}&select=*`, {
          headers: {
            'apikey': anon,
            'Authorization': 'Bearer ' + anon
          }
        });
        if (restRes.ok) {
          const rows = await restRes.json().catch(() => []);
          if (Array.isArray(rows) && rows.length > 0) {
            const row = rows[0];
            let seen = null;
            if (row.paired_at || row.created_at) {
              const time = new Date(row.paired_at || row.created_at).getTime();
              if (!isNaN(time)) {
                seen = Math.max(0, Math.round((Date.now() - time) / 1000));
              }
            }
            return { ok: true, phoneLastSeenSec: seen !== null ? seen : 5, pairCode: code };
          }
        }
      } catch (_) {}

      // 2. ตรวจสอบผ่านตาราง clip_sync_pairs (หากมีการรัน schema ตัวใหม่)
      try {
        const restRes2 = await fetch(`${base}/rest/v1/clip_sync_pairs?pair_code=eq.${encodeURIComponent(code)}&select=*`, {
          headers: {
            'apikey': anon,
            'Authorization': 'Bearer ' + anon
          }
        });
        if (restRes2.ok) {
          const rows2 = await restRes2.json().catch(() => []);
          if (Array.isArray(rows2) && rows2.length > 0) {
            return { ok: true, phoneLastSeenSec: 5, pairCode: code };
          }
        }
      } catch (_) {}

      // 3. Fallback ไปที่ Edge Function
      return await callEdge('clip-sync-pair', { action: 'check', pairCode: code }, customUrl, customKey, 15000);
    } catch (err) {
      return { ok: false, error: err && err.message || 'network_error' };
    }
  }

  async function fetchClipSyncStatus() {
    const settings = await getClipSyncSettings();
    if (!settings.pairCode) return { ok: false, error: 'not_paired', jobs: [] };
    let serverJobs = [];
    let phoneLastSeenSec = null;

    try {
      const url = (settings.supabaseUrl || DEFAULT_SUPABASE_URL).replace(/\/+$/, '');
      const anon = settings.supabaseAnonKey || DEFAULT_SUPABASE_ANON_KEY;
      const pair = encodeURIComponent(settings.pairCode.trim());

      // Fetch last seen from pair_codes
      try {
        const pRes = await fetch(`${url}/rest/v1/pair_codes?pair_code=eq.${pair}&select=last_seen_at`, {
          headers: { 'apikey': anon, 'Authorization': 'Bearer ' + anon }
        });
        if (pRes.ok) {
          const rows = await pRes.json().catch(() => []);
          if (Array.isArray(rows) && rows.length > 0 && rows[0].last_seen_at) {
            phoneLastSeenSec = Math.max(0, Math.floor((Date.now() - new Date(rows[0].last_seen_at).getTime()) / 1000));
          }
        }
      } catch (_) {}

      // Fetch jobs from clip_jobs
      const jRes = await fetch(`${url}/rest/v1/clip_jobs?pair_code=eq.${pair}&order=created_at.desc&limit=10`, {
        headers: { 'apikey': anon, 'Authorization': 'Bearer ' + anon }
      });
      if (jRes.ok) {
        const rows = await jRes.json().catch(() => []);
        if (Array.isArray(rows)) {
          serverJobs = rows.map(r => ({
            jobId: (r.meta && r.meta.jobId) || r.id,
            videoName: r.video_name,
            status: r.status,
            error: (r.meta && r.meta.error) || '',
            createdAt: r.created_at,
            updatedAt: r.posted_at || r.uploaded_at || r.created_at
          }));
        }
      }
    } catch (_) {}

    let local = [];
    try {
      const stored = await chrome.storage.local.get(LOG_KEY);
      local = Array.isArray(stored && stored[LOG_KEY]) ? stored[LOG_KEY] : [];
    } catch (_) {}

    const serverRefs = new Set(serverJobs.map(j => j.jobId));
    const localOnly = local
      .filter(e => (e.status === 'uploading' || e.status === 'upload_failed') && !serverRefs.has(e.jobId))
      .map(e => ({
        jobId: e.clientRef,
        videoName: e.videoName,
        status: e.status,
        error: e.error || '',
        createdAt: new Date(e.at || Date.now()).toISOString(),
        updatedAt: new Date(e.at || Date.now()).toISOString()
      }));

    return {
      ok: true,
      phoneLastSeenSec: phoneLastSeenSec,
      jobs: localOnly.concat(serverJobs)
    };
  }

  // ── UI Binding ในแท็บ "ตั้งค่า" (Settings) ──
  function initClipSyncSettingsCard() {
    const card = document.getElementById('ucCloudCard');
    if (!card) return;
    if (card.dataset.asuWired === '1') return;
    card.dataset.asuWired = '1';

    const enabledEl = document.getElementById('ucCloudEnabled');
    const autoStartEl = document.getElementById('ucCloudAutoStart');
    const pill = document.getElementById('ucCloudPill');
    const hint = document.getElementById('ucCloudHint');

    const deviceListEl = document.getElementById('ucCloudDeviceList');
    const btnShowAdd = document.getElementById('ucCloudBtnShowAdd');
    const addForm = document.getElementById('ucCloudAddForm');
    const newDevName = document.getElementById('ucCloudNewDevName');
    const newDevCode = document.getElementById('ucCloudNewDevCode');
    const btnGenKey = document.getElementById('ucCloudBtnGenKey');
    const btnCancelDev = document.getElementById('ucCloudBtnCancelDev');
    const btnSaveDev = document.getElementById('ucCloudBtnSaveDev');

    function setPill(text, okClass) {
      if (!pill) return;
      pill.textContent = text;
      pill.style.background = okClass === 'is-ok' ? 'rgba(34,197,94,0.15)' :
                              okClass === 'is-warn' ? 'rgba(234,179,8,0.15)' : 'rgba(255,255,255,0.08)';
      pill.style.color = okClass === 'is-ok' ? '#22c55e' :
                         okClass === 'is-warn' ? '#eab308' : 'var(--text-muted)';
    }

    function refreshPill(settings) {
      const s = settings;
      if (!s.enabled) { setPill('ปิดอยู่', 'is-idle'); return; }
      const devList = Array.isArray(s.devices) ? s.devices : [];
      if (!devList.length) { setPill('ยังไม่ลงทะเบียนเครื่อง', 'is-warn'); return; }
      if (devList.length === 1) {
        setPill('พร้อมใช้งาน • ' + devList[0].pairCode, 'is-ok');
      } else {
        setPill(`พร้อมใช้งาน ${devList.length} เครื่อง`, 'is-ok');
      }
    }

    function escapeHtml(str) {
      return String(str || '').replace(/[&<>"']/g, (m) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      }[m]));
    }

    async function renderDeviceList(settings) {
      if (!deviceListEl) return;
      const s = settings || await getClipSyncSettings();
      const devices = Array.isArray(s.devices) ? s.devices : [];

      if (!devices.length) {
        deviceListEl.innerHTML = `
          <div style="font-size:11px;color:var(--text-muted);text-align:center;padding:12px;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:6px;">
            ยังไม่มีเครื่องในระบบ — กด "+ เพิ่มเครื่องใหม่" หรือ "✨ สร้าง Key" ด้านบน
          </div>
        `;
        return;
      }

      deviceListEl.innerHTML = devices.map((dev) => `
        <div class="device-item" data-dev-id="${escapeHtml(dev.id)}" style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:rgba(255,255,255,0.03);border:1px solid ${dev.isDefault ? '#ee4d2d' : 'var(--border)'};border-radius:8px;">
          <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;">
            <input type="radio" name="asuDefaultDev" value="${escapeHtml(dev.id)}" ${dev.isDefault ? 'checked' : ''} title="คลิกเพื่อตั้งเป็นเครื่องหลัก" style="cursor:pointer;accent-color:#ee4d2d;">
            <div style="min-width:0;flex:1;">
              <div style="display:flex;align-items:center;gap:6px;">
                <span style="font-size:12px;font-weight:600;color:var(--text-main);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(dev.name)}</span>
                ${dev.isDefault ? '<span style="font-size:9px;background:#ee4d2d;color:#fff;padding:1px 5px;border-radius:4px;font-weight:bold;">เครื่องหลัก</span>' : ''}
              </div>
              <div style="display:flex;align-items:center;gap:6px;margin-top:2px;">
                <code style="font-family:monospace;letter-spacing:1px;font-size:11px;color:#fca5a5;background:rgba(238,77,45,0.12);padding:1px 5px;border-radius:4px;">${escapeHtml(dev.pairCode)}</code>
                <button class="btn-copy-code" data-code="${escapeHtml(dev.pairCode)}" type="button" title="คัดลอกรหัส Key" style="background:none;border:none;color:var(--text-dim);cursor:pointer;font-size:12px;padding:0 2px;">📋</button>
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:4px;margin-left:6px;">
            <button class="btn-test-dev btn btn-secondary btn-sm" data-code="${escapeHtml(dev.pairCode)}" type="button" style="font-size:10px;padding:2px 8px;" title="ทดสอบสัญญาณมือถือ">📡 ทดสอบ</button>
            ${devices.length > 1 ? `<button class="btn-del-dev btn btn-outline btn-sm" data-id="${escapeHtml(dev.id)}" type="button" style="font-size:10px;padding:2px 6px;color:#ef4444;border-color:rgba(239,68,68,0.3);" title="ลบเครื่องนี้">🗑️</button>` : ''}
          </div>
        </div>
      `).join('');

      // Wire Radio buttons (Default Device)
      deviceListEl.querySelectorAll('input[name="asuDefaultDev"]').forEach((radio) => {
        radio.addEventListener('change', async () => {
          const updated = await setDefaultClipSyncDevice(radio.value);
          renderDeviceList(updated);
          refreshPill(updated);
          if (hint) hint.textContent = `✅ ตั้ง "${devices.find(d => d.id === radio.value)?.name}" เป็นเครื่องหลักเรียบร้อย`;
        });
      });

      // Wire Copy Buttons
      deviceListEl.querySelectorAll('.btn-copy-code').forEach((btn) => {
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const code = btn.dataset.code;
          try {
            await navigator.clipboard.writeText(code);
            if (hint) hint.textContent = `📋 คัดลอกรหัส "${code}" แล้ว — นำไปใส่ในเมนู "☁️ รับคลิปจากคอม" บนมือถือได้เลย!`;
          } catch (_) {
            if (hint) hint.textContent = `รหัสของคุณคือ: ${code}`;
          }
        });
      });

      // Wire Test Connection Buttons
      deviceListEl.querySelectorAll('.btn-test-dev').forEach((btn) => {
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const code = btn.dataset.code;
          btn.disabled = true;
          btn.textContent = '⏳...';
          if (hint) hint.textContent = `⏳ กำลังทดสอบการเชื่อมต่อรหัส ${code}…`;

          try {
            const res = await testClipSyncConnection(code);
            if (res && res.ok) {
              const seen = res.phoneLastSeenSec;
              if (seen === null || seen === undefined) {
                if (hint) hint.textContent = `⚠️ รหัส ${code} ถูกต้อง — แต่มือถือยังไม่เคยเปิดแอป หรือยังไม่ได้แตะ "เริ่มรับคลิป"`;
              } else if (seen <= 60) {
                if (hint) hint.textContent = `✅ มือถือออนไลน์แล้ว! (เชื่อมต่อล่าสุด ${seen} วินาทีที่แล้ว) — พร้อมรับคลิป 🚀`;
              } else {
                if (hint) hint.textContent = `✅ รหัสถูกต้อง (มือถือเชื่อมต่อล่าสุด ${Math.round(seen / 60)} นาทีที่แล้ว)`;
              }
            } else {
              if (hint) hint.textContent = `❌ รหัส ${code} ยังไม่พบในระบบ หรือมือถือยังไม่ได้เชื่อมต่อ`;
            }
          } catch (err) {
            if (hint) hint.textContent = `❌ เกิดข้อผิดพลาดในการเชื่อมต่อ: ${err.message || err}`;
          } finally {
            btn.disabled = false;
            btn.textContent = '📡 ทดสอบ';
          }
        });
      });

      // Wire Delete Buttons
      deviceListEl.querySelectorAll('.btn-del-dev').forEach((btn) => {
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const devId = btn.dataset.id;
          const target = devices.find(d => d.id === devId);
          if (!confirm(`คุณต้องการลบ "${target ? target.name : devId}" ออกจากระบบใช่หรือไม่?`)) return;
          try {
            const updated = await removeClipSyncDevice(devId);
            renderDeviceList(updated);
            refreshPill(updated);
            if (hint) hint.textContent = `🗑️ ลบเครื่องเรียบร้อยแล้ว`;
          } catch (err) {
            alert(err.message || err);
          }
        });
      });
    }

    async function loadValues() {
      const s = await getClipSyncSettings();
      if (enabledEl) enabledEl.checked = !!s.enabled;
      if (autoStartEl) autoStartEl.checked = s.autoStart !== false;
      refreshPill(s);
      renderDeviceList(s);
    }

    if (enabledEl) {
      enabledEl.addEventListener('change', async () => {
        const s = await saveClipSyncSettings({ enabled: !!enabledEl.checked });
        refreshPill(s);
      });
    }

    if (autoStartEl) {
      autoStartEl.addEventListener('change', async () => {
        await saveClipSyncSettings({ autoStart: !!autoStartEl.checked });
      });
    }

    // Show/Hide Add Form
    if (btnShowAdd) {
      btnShowAdd.addEventListener('click', () => {
        if (!addForm) return;
        const isHidden = addForm.classList.toggle('hidden');
        if (!isHidden) {
          if (newDevCode) newDevCode.value = generatePairCode();
          if (newDevName) {
            chrome.storage.local.get(SETTINGS_KEY).then((st) => {
              const count = (st && st[SETTINGS_KEY] && st[SETTINGS_KEY].devices && st[SETTINGS_KEY].devices.length) || 1;
              newDevName.value = `เครื่องที่ ${count + 1}`;
              newDevName.focus();
              newDevName.select();
            });
          }
        }
      });
    }

    // Generate Key Button inside Add Form
    if (btnGenKey) {
      btnGenKey.addEventListener('click', () => {
        if (newDevCode) {
          newDevCode.value = generatePairCode();
          newDevCode.focus();
        }
      });
    }

    // Cancel Add Form
    if (btnCancelDev) {
      btnCancelDev.addEventListener('click', () => {
        if (addForm) addForm.classList.add('hidden');
      });
    }

    // Save New Device
    if (btnSaveDev) {
      btnSaveDev.addEventListener('click', async () => {
        const name = (newDevName ? newDevName.value : '').trim();
        const code = normalizePairCode(newDevCode ? newDevCode.value : '');
        if (!code) {
          if (hint) hint.textContent = '❌ รหัสต้องเป็น 12 ตัวอักษร เช่น 7K3M-Q2XN-9DPF (หรือกดปุ่ม "✨ สร้าง Key")';
          newDevCode?.focus();
          return;
        }

        btnSaveDev.disabled = true;
        try {
          const updated = await addClipSyncDevice(name, code);
          if (addForm) addForm.classList.add('hidden');
          renderDeviceList(updated);
          refreshPill(updated);
          if (hint) hint.textContent = `🎉 เพิ่ม "${name || 'เครื่องใหม่'}" (Key: ${code}) สำเร็จ! นำรหัสนี้ไปใส่ในแอปมือถือเพื่อเริ่มใช้งานได้ทันที`;
        } catch (err) {
          if (hint) hint.textContent = `❌ ${err.message || err}`;
        } finally {
          btnSaveDev.disabled = false;
        }
      });
    }

    // Re-render when devices change elsewhere
    window.addEventListener('asu-devices-changed', (e) => {
      if (e.detail) {
        refreshPill(e.detail);
        renderDeviceList(e.detail);
      }
    });

    loadValues();
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initClipSyncSettingsCard);
    } else {
      initClipSyncSettingsCard();
    }
  }

  // แจ้งเตือน Callback เมื่ออัปโหลดเสร็จ
  const _clipSyncResultCbs = [];
  function onClipSyncResult(cb) {
    if (typeof cb === 'function' && _clipSyncResultCbs.indexOf(cb) < 0) _clipSyncResultCbs.push(cb);
  }

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.type !== 'ASU_CLIP_SYNC_RESULT') return;
      for (const cb of _clipSyncResultCbs) {
        try {
          cb({ clientRef: msg.clientRef, videoName: msg.videoName || '', status: msg.status, error: msg.error || '' });
        } catch (_) {}
      }
    });
  } catch (_) {}

  window.ASUClipSync = {
    DEFAULT_SUPABASE_URL,
    DEFAULT_SUPABASE_ANON_KEY,
    getClipSyncSettings,
    saveClipSyncSettings,
    addClipSyncDevice,
    removeClipSyncDevice,
    setDefaultClipSyncDevice,
    generatePairCode,
    pushClipToRelay,
    testClipSyncConnection,
    fetchClipSyncStatus,
    resolveClipSyncProductUrl,
    sanitizeVideoName,
    normalizePairCode,
    appendLocalLog,
    onClipSyncResult,
    initClipSyncSettingsCard,
    STATUS_TH
  };
})();
