/* ═══ SETTINGS TAB ═══ */
  const settingsApiKey = $('#settingsApiKey');
  const settingsApiProvider = $('#settingsApiProvider');
  const settingsGeminiKey = $('#settingsGeminiKey');
  const settingsModel = $('#settingsModel');
  const settingsLang = $('#settingsLang');

  const models = window.PhimAI?.POPULAR_MODELS || [
    { id: 'google/gemini-2.5-flash', name: 'Gemini 2.5 Flash' },
    { id: 'anthropic/claude-sonnet-4', name: 'Claude Sonnet 4' },
    { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini' },
  ];
  models.forEach((m) => { const o = document.createElement('option'); o.value = m.id; o.textContent = m.name; settingsModel?.appendChild(o); });

  const settingsZoom = document.querySelector("#settingsZoom");

  async function loadSettings() {
    const config = await sendMsg('PHIMBOT_GET_API_CONFIG');
    if (settingsApiKey) settingsApiKey.value = config.apiKey || '';
    if (settingsApiProvider) settingsApiProvider.value = config.apiProvider || 'openrouter';
    if (settingsGeminiKey) settingsGeminiKey.value = config.geminiKey || '';
    if (settingsModel) settingsModel.value = config.model || 'google/gemini-2.5-flash';
    if (settingsLang) settingsLang.value = window.PhimI18n.getLanguage();
    const data = await chrome.storage.local.get(['phimbot_queue_delay_min', 'phimbot_queue_delay_max', 'phimbot_zoom']);
    if (queueDelayMin) queueDelayMin.value = data.phimbot_queue_delay_min || 100;
    if (queueDelayMax) queueDelayMax.value = data.phimbot_queue_delay_max || 200;
    
    const zoom = data.phimbot_zoom || '1';
    if (settingsZoom) settingsZoom.value = zoom;
    document.body.style.zoom = zoom;
  }

  $('#btnSaveSettings')?.addEventListener('click', async () => {
    await sendMsg('PHIMBOT_SAVE_API_KEY', { apiKey: settingsApiKey?.value?.trim(), geminiKey: settingsGeminiKey?.value?.trim(), model: settingsModel?.value, apiProvider: settingsApiProvider?.value });
    const newLang = settingsLang?.value;
    if (newLang && newLang !== window.PhimI18n.getLanguage()) await window.PhimI18n.setLanguage(newLang);
    const zoom = document.querySelector('#settingsZoom')?.value || '1';
    await chrome.storage.local.set({ phimbot_zoom: zoom });
    document.body.style.zoom = zoom;
    showToast('✅ บันทึกตั้งค่าแล้ว!');
  });

  $('#btnTestApi')?.addEventListener('click', async () => {
    const btn = $('#btnTestApi');
    btn.disabled = true;
    btn.textContent = '⏳ กำลังทดสอบ...';
    try {
      await sendMsg('PHIMBOT_SAVE_API_KEY', { apiKey: settingsApiKey?.value?.trim(), geminiKey: settingsGeminiKey?.value?.trim(), model: settingsModel?.value, apiProvider: settingsApiProvider?.value });
      const res = await sendMsg('PHIMBOT_AI_GENERATE', { action: 'generate_caption', prompt: 'นี่คือข้อความทดสอบระบบ กรุณาตอบกลับแค่คำว่า "OK" เท่านั้น' });
      if (res && res.success) { showToast('✅ เชื่อมต่อ AI สำเร็จ! ระบบพร้อมใช้งาน'); }
      else { showToast('❌ ผิดพลาด: ' + (res?.error || 'ไม่สามารถเชื่อมต่อได้'), true); alert('เชื่อมต่อ AI ไม่สำเร็จ:\n' + (res?.error || 'ไม่ทราบสาเหตุ')); }
    } catch (e) { showToast('❌ ผิดพลาด: ' + e.message, true); }
    finally { btn.disabled = false; btn.textContent = '🧪 ทดสอบ API Key'; }
  });