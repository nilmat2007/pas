import http.server
import socketserver
import json
import base64
import os
import subprocess
import tempfile
import urllib.request
import urllib.error
import urllib.parse
import time
import threading

PORT = 17882
ADB_PATHS = [
    r'C:\Users\ezcom\Desktop\bot\android-sdk\platform-tools\adb.exe',
    r'tools\platform-tools\adb.exe',
    'adb'
]

def get_adb():
    for p in ADB_PATHS:
        if os.path.isabs(p) and os.path.exists(p):
            return p
        elif not os.path.isabs(p) and os.path.exists(p):
            return os.path.abspath(p)
    return 'adb'

def run_adb_cmd(args):
    adb = get_adb()
    cmd = [adb] + args
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return res.returncode == 0, res.stdout.strip(), res.stderr.strip()
    except Exception as e:
        return False, '', str(e)

_cached_phone_online = False
_cached_device_connected = False

def check_phone_bridge(timeout=1):
    try:
        req = urllib.request.Request('http://127.0.0.1:17881/health')
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return data.get('ok', False)
    except Exception:
        return False

def ensure_phone_bridge_awake():
    global _cached_phone_online
    if check_phone_bridge(timeout=1):
        _cached_phone_online = True
        return True
    run_adb_cmd(['forward', 'tcp:17881', 'tcp:17881'])
    if check_phone_bridge(timeout=1):
        _cached_phone_online = True
        return True
    # Awaken phone app and bridge server
    run_adb_cmd(['shell', 'am', 'start', '-n', 'com.aiaffiliate.shopee/.MainActivity'])
    for _ in range(6):
        time.sleep(0.5)
        if check_phone_bridge(timeout=1):
            _cached_phone_online = True
            return True
    return False

def adb_monitor_loop():
    global _cached_phone_online, _cached_device_connected
    while True:
        try:
            ok, devices, _ = run_adb_cmd(['devices'])
            has_device = 'device\n' in (devices + '\n') or '\tdevice' in devices
            _cached_device_connected = has_device
            if has_device:
                run_adb_cmd(['forward', 'tcp:17881', 'tcp:17881'])
                _cached_phone_online = check_phone_bridge(timeout=1)
            else:
                _cached_phone_online = False
        except Exception:
            pass
        time.sleep(2)

class ShopeeBridgeHandler(http.server.BaseHTTPRequestHandler):
    def _send_cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors()
        self.end_headers()

    def do_GET(self):
        if self.path == '/health' or self.path == '/':
            self.send_response(200)
            self._send_cors()
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.end_headers()
            resp = {
                'ok': True,
                'service': 'phimbot_shopee_pc_bridge',
                'port': PORT,
                'phoneBridgeOnline': _cached_phone_online,
                'adbDeviceConnected': _cached_device_connected
            }
            self.wfile.write(json.dumps(resp).encode('utf-8'))
        elif self.path.startswith('/jobs/'):
            handoff_id = self.path[len('/jobs/'):].strip()
            if not handoff_id:
                self.send_response(400)
                self._send_cors()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({'ok': False, 'error': 'Missing handoffId'}).encode('utf-8'))
                return

            ensure_phone_bridge_awake()
            target_url = f'http://127.0.0.1:17881/jobs/{urllib.parse.quote(handoff_id)}'
            try:
                req = urllib.request.Request(target_url)
                with urllib.request.urlopen(req, timeout=5) as resp:
                    resp_body = resp.read()
                    self.send_response(resp.status)
                    self._send_cors()
                    self.send_header('Content-Type', 'application/json; charset=utf-8')
                    self.end_headers()
                    self.wfile.write(resp_body)
            except urllib.error.HTTPError as he:
                err_body = he.read()
                self.send_response(he.code)
                self._send_cors()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(err_body)
            except Exception as e:
                self.send_response(502)
                self._send_cors()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({'ok': False, 'error': f'Cannot reach phone bridge: {e}'}).encode('utf-8'))
        else:
            self.send_response(404)
            self._send_cors()
            self.end_headers()

    def do_POST(self):
        if self.path == '/jobs':
            length = int(self.headers.get('Content-Length', 0))
            body_bytes = self.rfile.read(length)
            try:
                payload = json.loads(body_bytes.decode('utf-8'))
            except Exception as e:
                self.send_response(400)
                self._send_cors()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({'ok': False, 'error': 'Invalid JSON: ' + str(e)}).encode('utf-8'))
                return

            video_data_url = payload.get('videoDataUrl', '')
            video_name = payload.get('videoName') or ('shopee_' + str(int(time.time())) + '.mp4')
            if not video_name.lower().endswith(('.mp4', '.mov')):
                video_name += '.mp4'

            # 1. Push video if base64 provided
            if video_data_url and 'base64,' in video_data_url:
                if not _cached_device_connected:
                    self.send_response(400)
                    self._send_cors()
                    self.send_header('Content-Type', 'application/json; charset=utf-8')
                    self.end_headers()
                    self.wfile.write(json.dumps({'ok': False, 'error': 'no_usb_device', 'message': 'ไม่พบสาย USB เชื่อมต่อกับมือถือ'}).encode('utf-8'))
                    return
                try:
                    _, b64data = video_data_url.split('base64,', 1)
                    raw_video = base64.b64decode(b64data)
                    ext = '.mov' if video_name.lower().endswith('.mov') else '.mp4'
                    # Use a clean safe ASCII filename on phone to avoid MediaStore query & shell quoting bugs with Thai/brackets
                    clean_video_name = f"shopee_{int(time.time())}_{int(time.time() * 1000) % 10000}{ext}"
                    dest_on_phone = '/sdcard/Download/' + clean_video_name

                    with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
                        tmp.write(raw_video)
                        tmp_path = tmp.name

                    ok, out, err = run_adb_cmd(['push', tmp_path, dest_on_phone])
                    try:
                        os.unlink(tmp_path)
                    except:
                        pass

                    if not ok:
                        self.send_response(500)
                        self._send_cors()
                        self.send_header('Content-Type', 'application/json; charset=utf-8')
                        self.end_headers()
                        self.wfile.write(json.dumps({'ok': False, 'error': 'ADB push failed: ' + (err or out)}).encode('utf-8'))
                        return

                    # Broadcast MediaScanner
                    run_adb_cmd(['shell', 'am', 'broadcast', '-a', 'android.intent.action.MEDIA_SCANNER_SCAN_FILE', '-d', 'file://' + dest_on_phone])
                    time.sleep(1.5)
                    # Update video_name to clean name so phone BridgeJobImporter finds it in MediaStore
                    video_name = clean_video_name
                except Exception as e:
                    self.send_response(500)
                    self._send_cors()
                    self.send_header('Content-Type', 'application/json; charset=utf-8')
                    self.end_headers()
                    self.wfile.write(json.dumps({'ok': False, 'error': 'File transfer error: ' + str(e)}).encode('utf-8'))
                    return

            # Ensure port forward is active & phone bridge is awake
            ensure_phone_bridge_awake()

            # 2. Call phone bridge 17881/jobs
            raw_caption = str(payload.get('caption', '') or '')
            raw_tags = payload.get('hashtags', '') or ''
            if isinstance(raw_tags, list):
                raw_tags = ' '.join(f"#{t.lstrip('#')}" for t in raw_tags)
            raw_tags = str(raw_tags).strip()
            if not raw_tags:
                raw_tags = '#ShopeeTH #รีวิว #ของดีบอกต่อ'

            # Strict 140 char limit so Shopee never rejects or truncates hashtags
            max_cap = max(15, 140 - len(raw_tags) - 1)
            clean_caption = raw_caption.strip()
            if len(clean_caption) > max_cap:
                clean_caption = clean_caption[:max(0, max_cap - 3)].strip() + '...'

            phone_payload = {
                'handoffId': payload.get('handoffId') or ('phim_' + str(int(time.time()))),
                'videoName': video_name,
                'productUrl': payload.get('productUrl', ''),
                'productTitle': payload.get('productTitle', ''),
                'caption': clean_caption,
                'hashtags': raw_tags,
                'autoStart': payload.get('autoStart', True)
            }

            try:
                req_data = json.dumps(phone_payload).encode('utf-8')
                req = urllib.request.Request(
                    'http://127.0.0.1:17881/jobs',
                    data=req_data,
                    headers={'Content-Type': 'application/json; charset=utf-8'}
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    resp_body = resp.read().decode('utf-8')
                    self.send_response(resp.status)
                    self._send_cors()
                    self.send_header('Content-Type', 'application/json; charset=utf-8')
                    self.end_headers()
                    self.wfile.write(resp_body.encode('utf-8'))
            except urllib.error.HTTPError as he:
                err_body = he.read().decode('utf-8')
                self.send_response(he.code)
                self._send_cors()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(err_body.encode('utf-8'))
            except Exception as e:
                self.send_response(502)
                self._send_cors()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({'ok': False, 'error': 'Failed to contact phone bridge: ' + str(e)}).encode('utf-8'))
        else:
            self.send_response(404)
            self._send_cors()
            self.end_headers()

    def log_message(self, format, *args):
        pass

def main():
    print('[*] Starting PhimBot Shopee PC Bridge on http://127.0.0.1:' + str(PORT))
    run_adb_cmd(['forward', 'tcp:17881', 'tcp:17881'])
    t = threading.Thread(target=adb_monitor_loop, daemon=True)
    t.start()
    with socketserver.ThreadingTCPServer(('127.0.0.1', PORT), ShopeeBridgeHandler) as httpd:
        httpd.allow_reuse_address = True
        print('[+] PC Bridge listening on http://127.0.0.1:' + str(PORT))
        httpd.serve_forever()

if __name__ == '__main__':
    main()
