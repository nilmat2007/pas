@echo off
title PhimBot Shopee PC Bridge
set PYTHONDONTWRITEBYTECODE=1
echo Starting Shopee PC Bridge (Port 17882)...
python -B %~dp0shopee_bridge_daemon.py
pause
