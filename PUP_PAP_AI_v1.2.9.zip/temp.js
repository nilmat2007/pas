/**
 * PhimBot — Side Panel UI Logic (v3 — OmniPost-style)
 * Toggle switches, Product modal, Custom dropdown, Batch queue
 */
(async function () {
  'use strict';
  await window.PhimI18n.init();
  window.PhimI18n.applyToDOM();

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);
  const t = (key, ...a) => window.PhimI18n.t(key, ...a);
  const toast = $('#toast');

  function showToast(msg, dur = 3000) { toast.textContent = msg; toast.classList.remove('hidden'); setTimeout(() => toast.classList.add('hidden'), dur); }
  function sendMsg(type, payload) { return new Promise((r) => chrome.runtime.sendMessage({ type, payload }, (res) => r(res || {}))); }
  function formatSize(b) { if (b < 1024) return `${b} B`; if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`; return `${(b / 1048576).toFixed(1)} MB`; }

  /* ═══ Tab Switching ═══ */
  $$('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      $$('.tab-btn').forEach((b) => b.classList.remove('active'));
      $$('.tab-content').forEach((c) => c.classList.remove('active'));
      btn.classList.add('active');
      $(`#tab-${btn.dataset.tab}`).classList.add('active');
      if (btn.dataset.tab === 'queue') refreshQueue();
      if (btn.dataset.tab === 'products') refreshProducts();
    });
  });

  /* ═══════════════════════════════════════════════════════════════
     ① TOGGLE SWITCHES
     ═══════════════════════════════════════════════════════════════ */
  const masterToggle = $('#masterToggle');
  const toggleBasket = $('#toggleBasket');
  const toggleSkipAI = $('#toggleSkipAI');
  const toggleDisclose = $('#toggleDisclose');
  const toggleAutoHashtags = $('#toggleAutoHashtags');

  const subToggles = [toggleBasket, toggleSkipAI, toggleDisclose, toggleAutoHashtags];

  masterToggle?.addEventListener('change', () => {
    const on = masterToggle.checked;
    subToggles.forEach((t) => { if (t) t.disabled = !on; });
    if (!on) {
      subToggles.forEach((t) => { if (t) t.checked = false; });
    }
  });

  /* ═══════════════════════════════════════════════════════════════
     ② PRODUCT PICKER + MODAL
     ═══════════════════════════════════════════════════════════════ */
  const selectedProductCard = $('#selectedProductCard');
  const selectedProductImg = $('#selectedProductImg');
  const selectedProductName = $('#selectedProductName');
  const selectedProductMeta = $('#selectedProductMeta');
  const clearSelectedProduct = $('#clearSelectedProduct');
  const productPickerCard = $('#productPickerCard');
  const noProductHint = $('#noProductHint');
  const basketCta = $('#basketCta');

  let selectedProduct = null;
  let selectedProducts = []; // for multi-select modal
  let pickerProducts = [];

  async function loadPickerProducts() {
    const res = await sendMsg('PHIMBOT_GET_PRODUCTS');
    pickerProducts = res.products || [];
  }

  function selectProduct(product) {
    selectedProduct = product;
    selectedProductImg.src = product.imageUrl || '';
    selectedProductName.textContent = product.name;
    selectedProductMeta.textContent = `ID: ${product.productId} | ฿${(product.price || 0).toLocaleString()} | ${product.statusLabel || product.status || ''}`;
    selectedProductCard.classList.remove('hidden');
    productPickerCard.classList.add('hidden');
    noProductHint?.classList.add('hidden');

    // Auto-fill AI fields
    const aiName = $('#aiProductName');
    const aiPrice = $('#aiProductPrice');
    if (aiName) aiName.value = product.name;
    if (aiPrice) aiPrice.value = product.price ? `฿${product.price}` : '';
  }

  function selectMultipleProducts(products) {
    selectedProducts = products;
    if (products.length === 1) {
      selectProduct(products[0]);
    } else if (products.length > 1) {
      selectedProduct = products[0]; // primary product
      selectedProductImg.src = products[0].imageUrl || '';
      selectedProductName.textContent = `${products.length} สินค้าที่เลือก`;
      selectedProductMeta.textContent = products.map((p) => p.name).join(', ');
      selectedProductCard.classList.remove('hidden');
      productPickerCard.classList.add('hidden');
      noProductHint?.classList.add('hidden');

      const aiName = $('#aiProductName');
      if (aiName) aiName.value = products.map((p) => p.name).join(' / ');
    }
  }

  clearSelectedProduct?.addEventListener('click', () => {
    selectedProduct = null;
    selectedProducts = [];
    selectedProductCard.classList.add('hidden');
    productPickerCard.classList.remove('hidden');
    noProductHint?.classList.remove('hidden');
  });

  // Open modal on card click
  productPickerCard?.addEventListener('click', () => openProductModal());

  // Also open modal on selected product click (to change)
  selectedProductCard?.addEventListener('click', (e) => {
    if (e.target.closest('.btn-icon')) return; // don't open on X button
    openProductModal();
  });

  /* ─── Product Modal Logic ───────────────────────────────── */
  const productModal = $('#productModal');
  const modalProductSearch = $('#modalProductSearch');
  const modalProductGrid = $('#modalProductGrid');
  const modalSelectedCount = $('#modalSelectedCount');
  const modalSelectAll = $('#modalSelectAll');
  const modalClearAll = $('#modalClearAll');
  const modalCancel = $('#modalCancel');
  const modalConfirm = $('#modalConfirm');

  let modalSelected = new Set(); // set of productId

  function openProductModal() {
    if (!pickerProducts.length) {
      showToast('กรุณาสแกนสินค้าจากแท็บ "สินค้า" ก่อน');
      return;
    }
    // Pre-select current product(s)
    modalSelected = new Set();
    if (selectedProducts.length) {
      selectedProducts.forEach((p) => modalSelected.add(p.productId));
    } else if (selectedProduct) {
      modalSelected.add(selectedProduct.productId);
    }
    modalProductSearch.value = '';
    renderModalGrid(pickerProducts);
    productModal.classList.remove('hidden');
  }

  function closeProductModal() {
    productModal.classList.add('hidden');
  }

  function renderModalGrid(products) {
    const total = pickerProducts.length;
    modalSelectedCount.textContent = `เลือก ${modalSelected.size} / ${total}`;

    if (!products.length) {
      modalProductGrid.innerHTML = '<div class="modal-empty">ไม่พบสินค้า</div>';
      return;
    }

    modalProductGrid.innerHTML = products.map((p) => {
      const safeName = String(p.name || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      return `
      <div class="grid-product${modalSelected.has(p.productId) ? ' selected' : ''}" data-id="${p.productId}" style="min-height: 100px; display: flex; flex-direction: column;">
        <img class="grid-product-img" src="${p.imageUrl || ''}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2264%22 height=%2264%22%3E%3Crect fill=%22%23333%22 width=%2264%22 height=%2264%22/%3E%3Ctext x=%2232%22 y=%2236%22 text-anchor=%22middle%22 fill=%22%23666%22 font-size=%2216%22%3E📦%3C/text%3E%3C/svg%3E'" style="width: 100%; aspect-ratio: 1; object-fit: cover; background: #2a2a2a; flex-shrink: 0;">
        <div class="grid-product-name" title="${safeName}" style="padding: 6px; font-size: 11px; line-height: 1.3; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; color: #fff;">${safeName}</div>
      </div>
      `;
    }).join('');

    modalProductGrid.querySelectorAll('.grid-product').forEach((el) => {
      el.addEventListener('click', () => {
        const id = el.dataset.id;
        if (modalSelected.has(id)) {
          modalSelected.delete(id);
          el.classList.remove('selected');
        } else {
          modalSelected.add(id);
          el.classList.add('selected');
        }
        modalSelectedCount.textContent = `เลือก ${modalSelected.size} / ${total}`;
      });
    });
  }

  // Search
  modalProductSearch?.addEventListener('input', () => {
    const q = modalProductSearch.value.trim().toLowerCase();
    const filtered = q ? pickerProducts.filter((p) => p.name.toLowerCase().includes(q) || p.productId.includes(q)) : pickerProducts;
    renderModalGrid(filtered);
  });

  // Select all / Clear
  modalSelectAll?.addEventListener('click', () => {
    pickerProducts.forEach((p) => modalSelected.add(p.productId));
    renderModalGrid(pickerProducts);
  });

  modalClearAll?.addEventListener('click', () => {
    modalSelected.clear();
    renderModalGrid(pickerProducts);
  });

  // Filter chips
  $$('input[name="modalFilter"]').forEach((radio) => {
    radio.addEventListener('change', () => {
      const val = radio.value;
      const q = modalProductSearch?.value?.trim().toLowerCase() || '';
      let filtered = pickerProducts;
      if (q) filtered = filtered.filter((p) => p.name.toLowerCase().includes(q) || p.productId.includes(q));
      // For now, filter placeholders (posted tracking not yet implemented)
      renderModalGrid(filtered);
    });
  });

  // Cancel
  modalCancel?.addEventListener('click', closeProductModal);

  // Click outside modal box to close
  productModal?.addEventListener('click', (e) => {
    if (e.target === productModal) closeProductModal();
  });

  // Confirm
  modalConfirm?.addEventListener('click', () => {
    if (modalSelected.size === 0) {
      showToast('กรุณาเลือกสินค้าอย่างน้อย 1 รายการ');
      return;
    }
    const products = pickerProducts.filter((p) => modalSelected.has(p.productId));
    selectMultipleProducts(products);
    closeProductModal();
    showToast(`✅ เลือก ${products.length} สินค้า`);
  });

  /* ═══════════════════════════════════════════════════════════════
     ③ CUSTOM DROPDOWN (Publish Mode)
     ═══════════════════════════════════════════════════════════════ */
  const publishTrigger = $('#publishTrigger');
  const publishMenu = $('#publishMenu');
  const publishText = $('#publishText');
  const scheduleSettings = $('#scheduleSettings');
  let selectedPublishMode = 'now';

  publishTrigger?.addEventListener('click', () => {
    const isOpen = !publishMenu.classList.contains('hidden');
    publishMenu.classList.toggle('hidden');
    publishTrigger.classList.toggle('open', !isOpen);
  });

  // Close dropdown on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#publishDropdown')) {
      publishMenu?.classList.add('hidden');
      publishTrigger?.classList.remove('open');
    }
  });

  $$('#publishMenu .dropdown-option').forEach((opt) => {
    opt.addEventListener('click', () => {
      const value = opt.dataset.value;
      selectedPublishMode = value;
      publishText.textContent = opt.textContent;
      $$('#publishMenu .dropdown-option').forEach((o) => o.classList.remove('active'));
      opt.classList.add('active');
      publishMenu.classList.add('hidden');
      publishTrigger.classList.remove('open');

      // Show/hide schedule fields
      scheduleSettings?.classList.toggle('hidden', value !== 'scheduled');
    });
  });

  /* ═══════════════════════════════════════════════════════════════
     ④ MULTI-VIDEO UPLOAD
     ═══════════════════════════════════════════════════════════════ */
  const dropZone = $('#dropZone');
  const videoInput = $('#videoInput');
  const videoList = $('#videoList');
  const uploadEmpty = $('#uploadEmpty');
  const clearAllVideos = $('#clearAllVideos');
  const btnUploadClip = $('#btnUploadClip');
  const btnFromTasks = $('#btnFromTasks');

  let videoFiles = []; // { file, dataUrl, name, size }

  function isVideoFile(f) {
    return f.type.startsWith('video/') || /\.(mp4|mov|avi|mkv|webm|flv|wmv|m4v)$/i.test(f.name);
  }

  function ensureVideoDataUrl(entry) {
    if (entry.dataUrl) return Promise.resolve(entry.dataUrl);
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => { entry.dataUrl = reader.result; resolve(entry.dataUrl); };
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(entry.file);
    });
  }

  function updateVideoUI() {
    const hasFiles = videoFiles.length > 0;
    uploadEmpty.classList.toggle('hidden', hasFiles);
    clearAllVideos.classList.toggle('hidden', !hasFiles);

    const batchCount = $('#batchQueueCount');
    if (batchCount) batchCount.textContent = hasFiles ? `(${videoFiles.length} คลิป)` : '';

    if (!hasFiles) {
      videoList.innerHTML = '';
      return;
    }

    videoList.innerHTML = videoFiles.map((v, idx) => `
      <div class="video-item" data-idx="${idx}">
        <span class="video-item-num">${idx + 1}</span>
        <span class="video-item-name" title="${v.name}">${v.name}</span>
        <span class="video-item-size">${formatSize(v.size)}</span>
        <button class="btn-icon video-remove" data-idx="${idx}" title="ลบ">✕</button>
      </div>
    `).join('');

    videoList.querySelectorAll('.video-remove').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        videoFiles.splice(parseInt(btn.dataset.idx), 1);
        updateVideoUI();
      });
    });
  }

  function addVideoFiles(files) {
    const list = Array.from(files).filter(isVideoFile);
    if (!list.length) {
      showToast('กรุณาเลือกไฟล์วิดีโอ (.mp4, .mov ฯลฯ)');
      return;
    }
    list.forEach((file) => {
      const entry = { file, dataUrl: null, name: file.name, size: file.size };
      videoFiles.push(entry);
      ensureVideoDataUrl(entry).catch((err) => console.error('[PhimBot] FileReader error:', err));
    });
    updateVideoUI();
  }

  btnUploadClip?.addEventListener('click', (e) => { e.stopPropagation(); videoInput.click(); });
  btnFromTasks?.addEventListener('click', (e) => { e.stopPropagation(); showToast('⏳ ฟีเจอร์นี้กำลังพัฒนา...'); });

  dropZone?.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('drag-over'); });
  dropZone?.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
  dropZone?.addEventListener('drop', (e) => { e.preventDefault(); dropZone.classList.remove('drag-over'); if (e.dataTransfer?.files?.length) addVideoFiles(e.dataTransfer.files); });
  videoInput?.addEventListener('change', () => { if (videoInput.files?.length) addVideoFiles(videoInput.files); videoInput.value = ''; });
  clearAllVideos?.addEventListener('click', (e) => { e.stopPropagation(); videoFiles = []; updateVideoUI(); });

  /* ═══ Toggle sections ═══ */
  const soundEnabled = $('#soundEnabled');
  const soundSettings = $('#soundSettings');
  soundEnabled?.addEventListener('change', () => soundSettings?.classList.toggle('hidden', !soundEnabled.checked));

  /* ═══════════════════════════════════════════════════════════════
     ⑤ BUILD JOB + BATCH QUEUE
     ═══════════════════════════════════════════════════════════════ */
  const captionInput = $('#captionInput');
  const hashtagsInput = $('#hashtagsInput');
  const progressSection = $('#progressSection');
  const progressLog = $('#progressLog');
  const btnBatchQueue = $('#btnBatchQueue');
  const btnPostNow = $('#btnPostNow');

  function buildJobTemplate() {
    const hashtags = (hashtagsInput?.value || '').trim().split(/\s+/).filter(Boolean).slice(0, 5);

    // Map toggle states to job settings
    const basketDisabled = toggleBasket?.checked || false;
    const skipAI = toggleSkipAI?.checked || false;
    const disclose = toggleDisclose?.checked || false;
    const autoHashtags = toggleAutoHashtags?.checked ?? true;

    // Map dropdown to postAction + publishMode
    let postAction = 'post';
    let publishMode = 'now';
    if (selectedPublishMode === 'draft') { postAction = 'draft'; publishMode = 'now'; }
    else if (selectedPublishMode === 'scheduled') { postAction = 'post'; publishMode = 'scheduled'; }
    else if (selectedPublishMode === 'private') { postAction = 'post'; publishMode = 'private'; }
    else { postAction = 'post'; publishMode = 'now'; }

    const hasProduct = !basketDisabled && !!selectedProduct;

    const job = {
      caption: captionInput?.value?.trim() || '',
      hashtags,
      postAction,
      publishMode,
      aiContentEnabled: !skipAI,
      attachProduct: hasProduct,
      productId: hasProduct ? selectedProduct.productId : '',
      basketCta: basketCta?.value?.trim() || '',
      discloseContent: disclose,
      autoHashtags,
      tiktokSettings: {
        soundEnabled: soundEnabled?.checked || false,
        soundTab: $('#soundTab')?.value || 'foryou',
        soundIndex: parseInt($('#soundIndex')?.value) || 1,
        soundSearchMode: 'sequential',
        soundRandomRange: 5,
        originalVolume: parseInt($('#originalVolume')?.value) || 50,
        addedVolume: parseInt($('#addedVolume')?.value) || 50,
      },
    };
    if (publishMode === 'scheduled') {
      const d = $('#scheduleDate')?.value;
      const tm = $('#scheduleTime')?.value;
      if (d && tm) {
        job.scheduledAtBase = new Date(`${d}T${tm}`).getTime();
        job.scheduleInterval = parseInt($('#scheduleInterval')?.value) || 15;
        job.scheduleVariation = parseInt($('#scheduleVariation')?.value) || 0;
      }
    }
    return job;
  }

  function timeStamp() {
    const d = new Date();
    return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
  }

  function addProgressItem(level, msg) {
    const div = document.createElement('div');
    div.className = `progress-item ${level}`;
    div.innerHTML = `<span class="step-icon"></span><span class="step-time">[${timeStamp()}]</span> <span>${msg}</span>`;
    progressLog?.appendChild(div);
    if (progressLog) progressLog.scrollTop = progressLog.scrollHeight;
  }

  // Pool of dynamic CTA texts for TikTok basket (<= 30 chars)
  const DYNAMIC_CTA_LIST = [
    'กดตะกร้าเลย', 'พิกัดในตะกร้าเหลือง', 'จิ้มตะกร้าซ้ายล่างเลย',
    'พิกัดของแท้ในตะกร้า', 'ของดีบอกต่อในตะกร้า', 'กดสั่งในตะกร้าได้เลย',
    'พิกัดสินค้าในตะกร้า', 'จิ้มดูในตะกร้าได้เลย', 'รีบกดก่อนหมดในตะกร้า',
    'พิกัดร้านตรงนี้เลย', 'สั่งซื้อจิ้มตะกร้าเลย', 'ของมันต้องมีในตะกร้า',
    'สนใจจิ้มตะกร้าได้เลย', 'พิกัดตัวนี้ในตะกร้า', 'กดตะกร้าเลยจ้า',
    'ดูสินค้าในตะกร้าได้เลย', 'ปักหมุดในตะกร้าแล้ว', 'ชี้เป้าในตะกร้าเลย',
    'กดดูในตะกร้าได้น้า', 'พิกัดของดีในตะกร้า'
  ];

  /* ─── Batch Queue ───────────────────────────────────────── */
  btnBatchQueue?.addEventListener('click', async () => {
    if (!videoFiles.length) { showToast('กรุณาเลือกคลิปก่อน'); return; }

    btnBatchQueue.disabled = true;
    btnBatchQueue.innerHTML = `<span class="spinner"></span> กำลังเตรียมไฟล์วิดีโอ...`;

    // Show progress log
    progressSection?.classList.remove('hidden');
    if (progressLog) progressLog.innerHTML = '';
    addProgressItem('info', `เริ่มเตรียมคิว ${videoFiles.length} คลิป...`);

    // Ensure all video dataURLs are loaded
    try {
      await Promise.all(videoFiles.map(ensureVideoDataUrl));
      addProgressItem('ok', `อ่านไฟล์วิดีโอสำเร็จ ${videoFiles.length} ไฟล์`);
    } catch (err) {
      console.error('[PhimBot] Read video failed:', err);
      addProgressItem('error', 'อ่านไฟล์วิดีโอบางไฟล์ไม่สำเร็จ');
      showToast('❌ อ่านไฟล์วิดีโอบางไฟล์ไม่สำเร็จ');
      btnBatchQueue.disabled = false;
      btnBatchQueue.innerHTML = '📋 ลงคิวทั้งหมด <span id="batchQueueCount"></span>';
      return;
    }

    const template = buildJobTemplate();
    const userCaption = captionInput?.value?.trim() || '';
    const userBasketCta = basketCta?.value?.trim() || '';

    // Determine product(s) for each video
    const productsToUse = selectedProducts.length > 0 ? selectedProducts : (selectedProduct ? [selectedProduct] : []);

    // Get current queue directly from storage
    const storageData = await chrome.storage.local.get('phimbot_queue');
    const queue = storageData.phimbot_queue || [];
    let addedCount = 0;

    for (let i = 0; i < videoFiles.length; i++) {
      const v = videoFiles[i];
      btnBatchQueue.innerHTML = `<span class="spinner"></span> ${i + 1}/${videoFiles.length} กำลังเตรียมคิว...`;
      addProgressItem('info', `📝 คลิป ${i + 1}/${videoFiles.length}: ${v.name}`);

      // Assign product (round-robin if multiple products)
      const productForVideo = productsToUse.length > 0 ? productsToUse[i % productsToUse.length] : null;
      const productName = productForVideo?.name || $('#aiProductName')?.value || '';
      const productDesc = $('#aiProductDesc')?.value || '';

      const videoCta = userBasketCta || DYNAMIC_CTA_LIST[i % DYNAMIC_CTA_LIST.length];
      const basketDisabled = toggleBasket?.checked || false;

      // Staggered schedule with variation (OmniPost v1.2.7 style)
      let scheduledAt;
      if (template.scheduledAtBase) {
        const baseMs = template.scheduledAtBase + (i * (template.scheduleInterval || 15) * 60000);
        const variation = template.scheduleVariation || 0;
        let variationMs = 0;
        if (variation > 0 && i > 0) {
          const seed = (i * 2654435761) >>> 0;
          const normalized = (seed % (2 * variation * 10 + 1)) / 10 - variation;
          variationMs = normalized * 60000;
        }
        const target = new Date(baseMs + variationMs);
        target.setMinutes(Math.round(target.getMinutes() / 5) * 5);
        target.setSeconds(0, 0);
        if (target.getTime() < Date.now() + 15 * 60000) {
          target.setTime(Date.now() + 16 * 60000);
          target.setMinutes(Math.round(target.getMinutes() / 5) * 5);
        }
        scheduledAt = target.toISOString();
      }

      const job = {
        ...template,
        caption: userCaption || '',
        hashtags: template.hashtags || [],
        basketCta: videoCta,
        videoDataUrl: v.dataUrl,
        filename: v.name,
        attachProduct: !basketDisabled && !!productForVideo,
        productId: productForVideo?.productId || '',
        productImage: productForVideo?.imageUrl || '',
        id: `phim_${Date.now()}_${Math.random().toString(36).slice(2, 6)}_${i}`,
        status: 'pending',
        createdAt: new Date().toISOString(),
        error: null,
        // ★ Lazy AI: generate caption per-row in background.js (saves tokens!)
        needsAiCaption: !userCaption,
        aiContext: {
          productName,
          productDesc,
          videoIndex: i,
          totalVideos: videoFiles.length,
        },
      };
      if (scheduledAt) job.scheduledAt = scheduledAt;

      queue.push(job);
      addedCount++;
      addProgressItem('ok', `📋 คลิป ${i + 1} ลงคิวแล้ว (AI จะคิดแคปชั่นตอนเริ่มโพสต์)`);
    }

    // Save directly to chrome.storage.local
    await chrome.storage.local.set({ phimbot_queue: queue });

    const pName = productsToUse.length > 1 ? `${productsToUse.length} สินค้า` : (productsToUse[0]?.name || 'ไม่ระบุ');
    addProgressItem('ok', `🎉 ลงคิวเสร็จ! ${addedCount} คลิป (${pName})`);
    showToast(`✅ ลงคิวแล้ว ${addedCount} คลิป (${pName})`);
    videoFiles = [];
    updateVideoUI();

    // Switch to queue tab
    $$('.tab-btn').forEach((b) => b.classList.remove('active'));
    $$('.tab-content').forEach((c) => c.classList.remove('active'));
    $('[data-tab="queue"]').classList.add('active');
    $('#tab-queue').classList.add('active');
    await refreshQueue();

    // Auto-start queue removed as requested so the user can review before starting
    

    btnBatchQueue.disabled = false;
    btnBatchQueue.innerHTML = '📋 ลงคิวทั้งหมด <span id="batchQueueCount"></span>';
  });

  /* ─── Post Now ──────────────────────────────────────────── */
  btnPostNow?.addEventListener('click', async () => {
    if (!videoFiles.length) { showToast('กรุณาเลือกคลิปก่อน'); return; }
    const first = videoFiles[0];
    if (!first.dataUrl) {
      btnPostNow.disabled = true;
      btnPostNow.innerHTML = `<span class="spinner"></span> กำลังอ่านไฟล์วิดีโอ...`;
      await ensureVideoDataUrl(first);
    }

    btnPostNow.disabled = true;
    btnPostNow.innerHTML = `<span class="spinner"></span> กำลังโพสต์...`;
    progressSection?.classList.remove('hidden');
    if (progressLog) progressLog.innerHTML = '';
    addProgressItem('info', 'เริ่มโพสต์...');

    const template = buildJobTemplate();
    const userBasketCta = basketCta?.value?.trim() || '';
    const videoCta = userBasketCta || DYNAMIC_CTA_LIST[Math.floor(Math.random() * DYNAMIC_CTA_LIST.length)];
    const job = {
      ...template,
      basketCta: videoCta,
      videoDataUrl: first.dataUrl,
      filename: first.name,
      id: `phim_${Date.now()}`
    };
    const result = await sendMsg('PHIMBOT_POST_NOW', job);

    if (result.ok) { addProgressItem('ok', 'โพสต์สำเร็จ!'); showToast('✅ โพสต์สำเร็จ!'); }
    else { addProgressItem('error', `ผิดพลาด: ${result.reason || 'Unknown'}`); showToast('❌ โพสต์ไม่สำเร็จ'); }

    btnPostNow.disabled = false;
    btnPostNow.innerHTML = '▶ โพสต์เลย (ตัวแรก)';
  });

  // Listen for progress + countdown
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'PHIMBOT_TIKTOK_POST_PROGRESS') addProgressItem(msg.payload?.level || 'info', `[${msg.payload?.step}] ${msg.payload?.message}`);
    if (msg?.type === 'PHIMBOT_QUEUE_PROGRESS') {
      refreshQueue();
      if (msg.payload?.message) {
        const labelEl = document.querySelector('#statTotal');
        if (labelEl) labelEl.parentElement.querySelector('.stat-label').textContent = msg.payload.message;
      }
    }
    if (msg?.type === 'PHIMBOT_COUNTDOWN') {
      const sec = msg.payload?.remaining || 0;
      const total = msg.payload?.total || 0;
      const countdownEl = document.querySelector('#queueCountdown');
      if (sec > 0) {
        const mins = Math.floor(sec / 60);
        const secs = sec % 60;
        const timeStr = mins > 0 ? `${mins}:${String(secs).padStart(2, '0')}` : `${secs}`;
        if (countdownEl) { countdownEl.classList.remove('hidden'); countdownEl.innerHTML = `⏱ แถวถัดไปใน <strong>${timeStr}</strong> วินาที (สุ่ม ${total} วินาที)`; }
      } else {
        if (countdownEl) { countdownEl.classList.add('hidden'); countdownEl.innerHTML = ''; }
      }
    }
  });

  /* ═══ AI Buttons ═══ */
  const btnAiCaption = $('#btnAiCaption');
  const btnAiImprove = $('#btnAiImprove');
  const btnAiHashtags = $('#btnAiHashtags');

  btnAiCaption?.addEventListener('click', async () => {
    const name = $('#aiProductName')?.value || selectedProduct?.name || '';
    const desc = $('#aiProductDesc')?.value || '';
    const price = $('#aiProductPrice')?.value || '';
    if (!name && !desc) { showToast('กรุณากรอกชื่อหรือคำอธิบายสินค้าก่อน'); return; }
    btnAiCaption.disabled = true; btnAiCaption.innerHTML = `<span class="spinner"></span> AI กำลังทำงาน...`;
    const prompt = [name ? `ชื่อสินค้า: ${name}` : '', desc ? `คำอธิบาย: ${desc}` : '', price ? `ราคา: ${price}` : ''].filter(Boolean).join('\n');
    const r = await sendMsg('PHIMBOT_AI_GENERATE', { action: 'generate_caption', prompt: `สร้างแคปชั่น TikTok:\n${prompt}` });
    if (r.success) { captionInput.value = r.text; showToast('✅ สร้างแคปชั่นสำเร็จ!'); } else showToast(`❌ ${r.error}`);
    btnAiCaption.disabled = false; btnAiCaption.innerHTML = '🤖 สร้างแคปชั่น AI';
  });

  btnAiImprove?.addEventListener('click', async () => {
    if (!captionInput?.value?.trim()) { showToast('กรุณากรอกแคปชั่นก่อน'); return; }
    btnAiImprove.disabled = true; btnAiImprove.innerHTML = `<span class="spinner"></span> AI กำลังทำงาน...`;
    const style = $('#aiStyle')?.value || 'engaging';
    const r = await sendMsg('PHIMBOT_AI_GENERATE', { action: 'improve_content', prompt: `ปรับปรุงข้อความนี้แบบ ${style}:\n\n${captionInput.value}` });
    if (r.success) { captionInput.value = r.text; showToast('✅ ปรับปรุงสำเร็จ!'); } else showToast(`❌ ${r.error}`);
    btnAiImprove.disabled = false; btnAiImprove.innerHTML = '✨ ปรับปรุง';
  });

  btnAiHashtags?.addEventListener('click', async () => {
    if (!captionInput?.value?.trim()) { showToast('กรุณากรอกแคปชั่นก่อน'); return; }
    btnAiHashtags.disabled = true; btnAiHashtags.innerHTML = `<span class="spinner"></span> AI กำลังทำงาน...`;
    const r = await sendMsg('PHIMBOT_AI_GENERATE', { action: 'suggest_hashtags', prompt: `แนะนำ 5 แฮชแท็ก TikTok:\n\n${captionInput.value}` });
    if (r.success) { hashtagsInput.value = r.text.split('\n').map((t) => t.replace(/^[#\-\d.\s]+/, '').trim()).filter(Boolean).slice(0, 5).join(' '); showToast('✅ แนะนำแฮชแท็กสำเร็จ!'); } else showToast(`❌ ${r.error}`);
    btnAiHashtags.disabled = false; btnAiHashtags.innerHTML = '🏷️ แนะนำ AI';
  });

  /* ═══ QUEUE TAB ═══ */
  const queueCount = $('#queueCount');
  const queueList = $('#queueList');
  const queueDelayMin = $('#queueDelayMin');
  const queueDelayMax = $('#queueDelayMax');
  const toggleRandomDelay = $('#toggleRandomDelay');

  async function refreshQueue() {
    const storageData = await chrome.storage.local.get('phimbot_queue');
    const queue = storageData.phimbot_queue || [];
    if (queueCount) queueCount.textContent = queue.length;

    // Update stats
    const total = queue.length;
    const success = queue.filter(q => q.status === 'done').length;
    const failed = queue.filter(q => q.status === 'error').length;
    const statTotal = $('#statTotal'); if (statTotal) statTotal.textContent = total;
    const statSuccess = $('#statSuccess'); if (statSuccess) statSuccess.textContent = success;
    const statFailed = $('#statFailed'); if (statFailed) statFailed.textContent = failed;

    if (!queue.length) { queueList.innerHTML = `<tr><td colspan="5" class="queue-empty">ยังไม่มีรายการในคิว</td></tr>`; return; }
    queueList.innerHTML = queue.map((item, idx) => {
      const clipThumb = item.thumbnail ? `<img class="q-thumb" src="${item.thumbnail}" alt="">` : `<div class="q-thumb" style="display:flex;align-items:center;justify-content:center;font-size:14px;">🎬</div>`;
      const prodThumb = item.productImage ? `<img class="q-thumb" src="${item.productImage}" alt="">` : (item.productId ? `<div class="q-thumb" style="display:flex;align-items:center;justify-content:center;font-size:14px;">📦</div>` : '–');
      const caption = item.caption ? item.caption.slice(0, 80) : (item.filename || 'Video');
      const statusClass = item.status || 'pending';
      const statusText = statusLabel(item.status, item.error);
      return `<tr>
        <td style="color:#666;">${idx + 1}</td>
        <td>${clipThumb}</td>
        <td>${prodThumb}</td>
        <td><div class="q-caption">${caption}</div><span class="q-status ${statusClass}">${statusText}</span></td>
        <td><button class="btn-icon queue-remove" data-id="${item.id}" title="ลบ" style="font-size:14px;">✕</button></td>
      </tr>`;
    }).join('');
    queueList.querySelectorAll('.queue-remove').forEach((btn) => btn.addEventListener('click', async () => {
      const qData = await chrome.storage.local.get('phimbot_queue');
      const filtered = (qData.phimbot_queue || []).filter((it) => it.id !== btn.dataset.id);
      await chrome.storage.local.set({ phimbot_queue: filtered });
      refreshQueue();
    }));
    const st = await sendMsg('PHIMBOT_GET_QUEUE_STATUS');
    const startBtn = $('#btnStartQueue'); const pauseBtn = $('#btnPauseQueue');
    if (startBtn) startBtn.disabled = st?.isRunning;
    if (pauseBtn) pauseBtn.disabled = !st?.isRunning;
  }

  function statusLabel(status, error) {
    switch (status) { case 'pending': return '⏳ รอ'; case 'processing': return '🔄 กำลังโพสต์'; case 'done': return '✅ สำเร็จ'; case 'error': return `❌ ${error || 'ผิดพลาด'}`; default: return status || '⏳ รอ'; }
  }

  // Run button → open delay modal
  $('#btnStartQueue')?.addEventListener('click', () => {
    const modal = $('#delayModal');
    if (modal) modal.classList.remove('hidden');
  });

  // Confirm run inside modal → save delay + start queue + close modal
  $('#btnConfirmRun')?.addEventListener('click', async () => {
    const useDelay = toggleRandomDelay?.checked;
    if (useDelay) {
      await sendMsg('PHIMBOT_SAVE_QUEUE_DELAY', { delayMin: parseInt(queueDelayMin?.value) || 100, delayMax: parseInt(queueDelayMax?.value) || 200 });
    } else {
      await sendMsg('PHIMBOT_SAVE_QUEUE_DELAY', { delayMin: 0, delayMax: 0 });
    }
    const r = await sendMsg('PHIMBOT_START_QUEUE');
    if (r.success) showToast('🚀 เริ่มรันคิวแล้ว!');
    const modal = $('#delayModal');
    if (modal) modal.classList.add('hidden');
    refreshQueue();
  });

  // Cancel button → close modal
  $('#btnCancelRun')?.addEventListener('click', () => {
    const modal = $('#delayModal');
    if (modal) modal.classList.add('hidden');
  });

  $('#btnPauseQueue')?.addEventListener('click', async () => { const r = await sendMsg('PHIMBOT_PAUSE_QUEUE'); if (r.success) showToast('⏸️ หยุดคิว'); refreshQueue(); });
  $('#btnClearQueue')?.addEventListener('click', async () => { if (!confirm('ต้องการล้างคิวทั้งหมด?')) return; await sendMsg('PHIMBOT_CLEAR_QUEUE'); refreshQueue(); showToast('🗑️ ล้างคิวแล้ว'); });

  // Toggle delay visibility
  toggleRandomDelay?.addEventListener('change', () => {
    const delaySection = $('#delaySettings');
    if (delaySection) delaySection.style.display = toggleRandomDelay.checked ? 'flex' : 'none';
  });


  /* ═══ FB REELS TAB ═══ */
  const fbReelsFileInput = $('#fbReelsFileInput');
  const fbReelsUploadZone = $('#fbReelsUploadZone');
  const fbReelsFileList = $('#fbReelsFileList');
  const fbReelsCaption = $('#fbReelsCaption');
  const fbReelsHashtags = $('#fbReelsHashtags');
  const fbReelsScheduleMode = $('#fbReelsScheduleMode');
  const fbReelsScheduleFields = $('#fbReelsScheduleFields');
  const fbReelsProgress = $('#fbReelsProgress');
  const fbReelsProgressLog = $('#fbReelsProgressLog');
  let fbReelsFiles = [];

  function addFbProgressItem(type, text) {
    if (!fbReelsProgressLog) return;
    const div = document.createElement('div');
    div.className = 'progress-item ' + type;
    div.textContent = text;
    fbReelsProgressLog.appendChild(div);
    fbReelsProgressLog.scrollTop = fbReelsProgressLog.scrollHeight;
  }

  fbReelsUploadZone?.addEventListener('click', () => fbReelsFileInput?.click());
  fbReelsUploadZone?.addEventListener('dragover', (e) => { e.preventDefault(); fbReelsUploadZone.classList.add('drag-over'); });
  fbReelsUploadZone?.addEventListener('dragleave', () => fbReelsUploadZone.classList.remove('drag-over'));
  fbReelsUploadZone?.addEventListener('drop', (e) => {
    e.preventDefault(); fbReelsUploadZone.classList.remove('drag-over');
    handleFbFiles(Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('video/')));
  });
  fbReelsFileInput?.addEventListener('change', () => handleFbFiles(Array.from(fbReelsFileInput.files)));

  function generateVideoThumb(file) {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.muted = true;
      video.playsInline = true;
      const url = URL.createObjectURL(file);
      video.src = url;
      video.onloadeddata = () => {
        video.currentTime = Math.min(1, video.duration / 2);
      };
      video.onseeked = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 120; canvas.height = 68;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const thumb = canvas.toDataURL('image/jpeg', 0.6);
        const dur = Math.floor(video.duration);
        const durStr = Math.floor(dur / 60) + ':' + String(dur % 60).padStart(2, '0');
        URL.revokeObjectURL(url);
        resolve({ thumb, duration: durStr });
      };
      video.onerror = () => { URL.revokeObjectURL(url); resolve({ thumb: '', duration: '?' }); };
    });
  }

  async function handleFbFiles(files) {
    fbReelsFiles = files;
    if (!fbReelsFileList) return;
    fbReelsFileList.innerHTML = files.map((f, i) => '<div class="file-item"><span class="spinner" style="width:14px;height:14px;"></span> ' + f.name + '</div>').join('');
    // Generate thumbnails async
    const items = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const { thumb, duration } = await generateVideoThumb(f);
      items.push('<div class="file-item-thumb"><div class="file-thumb-wrap">' +
        (thumb ? '<img src="' + thumb + '" class="file-thumb-img">' : '<div class="file-thumb-placeholder">🎬</div>') +
        '<span class="file-thumb-dur">' + duration + '</span></div>' +
        '<div class="file-thumb-info"><div class="file-thumb-name">' + (i + 1) + '. ' + f.name + '</div>' +
        '<div class="file-thumb-size">' + (f.size / 1048576).toFixed(1) + ' MB</div></div></div>');
    }
    fbReelsFileList.innerHTML = items.join('');
  }

  fbReelsScheduleMode?.addEventListener('change', () => {
    if (fbReelsScheduleFields) fbReelsScheduleFields.classList.toggle('hidden', fbReelsScheduleMode.value !== 'scheduled');
  });

  // Batch interval (+/- 5 min)
  let fbBatchIntervalMin = 30;
  const fbIntervalValue = $('#fbIntervalValue');
  function updateIntervalDisplay() {
    if (fbIntervalValue) fbIntervalValue.textContent = fbBatchIntervalMin + ' นาที';
  }
  $('#fbIntervalMinus')?.addEventListener('click', () => {
    fbBatchIntervalMin = Math.max(5, fbBatchIntervalMin - 5);
    updateIntervalDisplay();
  });
  $('#fbIntervalPlus')?.addEventListener('click', () => {
    fbBatchIntervalMin = Math.min(1440, fbBatchIntervalMin + 5);
    updateIntervalDisplay();
  });

  $('#btnFbAiCaption')?.addEventListener('click', async () => {
    const btn = $('#btnFbAiCaption');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> AI...';
    const prompt = 'สร้างแคปชั่น Facebook Reels สั้นๆ ดึงดูดคนดู 1-3 ประโยค ใส่อิโมจิ ห้ามใส่ # ห้ามพูดถึงราคา';
    const r = await sendMsg('PHIMBOT_AI_GENERATE', { action: 'generate_caption', prompt });
    if (r.success && fbReelsCaption) fbReelsCaption.value = r.text;
    else showToast('❌ ' + (r.error || 'AI ไม่ตอบ'));
    btn.disabled = false; btn.innerHTML = '🤖 AI คิดแคปชั่น';
  });

  $('#btnFbAiHashtags')?.addEventListener('click', async () => {
    const btn = $('#btnFbAiHashtags');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> AI...';
    const context = fbReelsCaption?.value || 'วิดีโอ Facebook Reels';
    const r = await sendMsg('PHIMBOT_AI_GENERATE', { action: 'suggest_hashtags', prompt: 'แนะนำ 5 แฮชแท็ก Facebook สำหรับ:\n' + context });
    if (r.success && fbReelsHashtags) {
      const tags = r.text.split('\n').map(t => t.replace(/^[\-\d.\s]+/, '').trim()).filter(Boolean).slice(0, 5).map(t => t.startsWith('#') ? t : '#' + t);
      fbReelsHashtags.value = tags.join(' ');
    } else showToast('❌ ' + (r.error || 'AI ไม่ตอบ'));
    btn.disabled = false; btn.innerHTML = '🏷️ AI แฮชแท็ก';
  });

  async function readFbVideoDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({ name: file.name, type: file.type, dataUrl: reader.result });
      reader.onerror = () => reject(new Error('อ่านไฟล์ไม่สำเร็จ: ' + file.name));
      reader.readAsDataURL(file);
    });
  }

  $('#btnFbReelsPost')?.addEventListener('click', async () => {
    if (!fbReelsFiles.length) { showToast('กรุณาเลือกคลิปก่อน'); return; }
    const btn = $('#btnFbReelsPost');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังโพสต์...';
    fbReelsProgress?.classList.remove('hidden');
    if (fbReelsProgressLog) fbReelsProgressLog.innerHTML = '';
    addFbProgressItem('info', '📤 กำลังอ่านไฟล์วิดีโอ...');
    try {
      const media = await readFbVideoDataUrl(fbReelsFiles[0]);
      addFbProgressItem('ok', '✅ อ่านไฟล์สำเร็จ: ' + media.name);
      const caption = fbReelsCaption?.value?.trim() || '';
      const hashtags = fbReelsHashtags?.value?.trim() || '';
      let fullCaption = [caption, hashtags].filter(Boolean).join('\n\n');
      // Append Shopee affiliate link if product selected
      if (typeof fbReelsSelectedProduct !== 'undefined' && fbReelsSelectedProduct?.affiliateUrl) {
        fullCaption += '\n\n🛒 ' + fbReelsSelectedProduct.affiliateUrl;
      }
      const config = {
        mediaFiles: [media],
        caption: fullCaption,
        aiLabelEnabled: $('#fbReelsAiLabel')?.checked ?? true,
        scheduleMode: fbReelsScheduleMode?.value || 'now',
        scheduleDate: $('#fbReelsDate')?.value || '',
        scheduleTime: $('#fbReelsTime')?.value || '',
        closeTabWhenDone: $('#fbReelsCloseTab')?.checked ?? true,
      };
      addFbProgressItem('info', '🚀 กำลังส่งไปยัง Facebook Reels...');
      const result = await sendMsg('PHIMBOT_POST_FB_REELS', config);
      if (result.ok) { addFbProgressItem('ok', '🎉 โพสต์ Reels สำเร็จ!'); showToast('✅ โพสต์ FB Reels สำเร็จ!'); }
      else { addFbProgressItem('error', '❌ ' + (result.reason || 'ผิดพลาด')); showToast('❌ โพสต์ไม่สำเร็จ'); }
    } catch (e) {
      addFbProgressItem('error', '❌ ' + e.message);
    }
    btn.disabled = false; btn.innerHTML = '🚀 โพสต์ Reels';
  });

  $('#btnFbReelsBatchQueue')?.addEventListener('click', async () => {
    if (!fbReelsFiles.length) { showToast('กรุณาเลือกคลิปก่อน'); return; }
    const btn = $('#btnFbReelsBatchQueue');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังเตรียม...';
    fbReelsProgress?.classList.remove('hidden');
    if (fbReelsProgressLog) fbReelsProgressLog.innerHTML = '';
    try {
      const storageData = await chrome.storage.local.get('phimbot_queue');
      const queue = storageData.phimbot_queue || [];
      let addedCount = 0;
      const isScheduled = fbReelsScheduleMode?.value === 'scheduled';
      const baseDate = $('#fbReelsDate')?.value || '';
      const baseTime = $('#fbReelsTime')?.value || '';

      for (let i = 0; i < fbReelsFiles.length; i++) {
        const media = await readFbVideoDataUrl(fbReelsFiles[i]);
        const caption = fbReelsCaption?.value?.trim() || '';
        const hashtags = fbReelsHashtags?.value?.trim() || '';

        // Calculate schedule time for this clip
        let jobDate = baseDate;
        let jobTime = baseTime;
        if (isScheduled && baseDate && baseTime && i > 0) {
          const base = new Date(baseDate + 'T' + baseTime);
          const offset = new Date(base.getTime() + (i * fbBatchIntervalMin * 60000));
          jobDate = offset.getFullYear() + '-' + String(offset.getMonth() + 1).padStart(2, '0') + '-' + String(offset.getDate()).padStart(2, '0');
          jobTime = String(offset.getHours()).padStart(2, '0') + ':' + String(offset.getMinutes()).padStart(2, '0');
        }

        const job = {
          platform: 'fb-reels',
          caption, hashtags: hashtags ? hashtags.split(/\s+/).filter(Boolean) : [],
          videoDataUrl: media.dataUrl, filename: media.name,
          aiLabelEnabled: $('#fbReelsAiLabel')?.checked ?? true,
          scheduleMode: isScheduled ? 'scheduled' : 'now',
          scheduleDate: jobDate, scheduleTime: jobTime,
          closeTabWhenDone: $('#fbReelsCloseTab')?.checked ?? true,
          needsAiCaption: !caption,
          aiContext: {
            productName: (typeof fbReelsSelectedProduct !== 'undefined' && fbReelsSelectedProduct?.title) || '',
            productDesc: (typeof fbReelsSelectedProduct !== 'undefined' && fbReelsSelectedProduct) ? ('ราคา ฿' + (fbReelsSelectedProduct.price||'') + (fbReelsSelectedProduct.commissionRate ? ' คอมฯ ' + fbReelsSelectedProduct.commissionRate + '%' : '')) : '',
            affiliateUrl: (typeof fbReelsSelectedProduct !== 'undefined' && fbReelsSelectedProduct?.affiliateUrl) || '',
            videoIndex: i, totalVideos: fbReelsFiles.length
          },
          id: 'phim_fb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6) + '_' + i,
          status: 'pending', createdAt: new Date().toISOString(), error: null,
        };
        queue.push(job);
        addedCount++;
        const timeLabel = isScheduled ? ' ⏰ ' + jobDate + ' ' + jobTime : '';
        addFbProgressItem('ok', '📋 คลิป ' + (i + 1) + ' ลงคิวแล้ว' + timeLabel);
      }
      await chrome.storage.local.set({ phimbot_queue: queue });
      addFbProgressItem('ok', '🎉 ลงคิวเสร็จ! ' + addedCount + ' คลิป FB Reels');
      showToast('✅ ลงคิวแล้ว ' + addedCount + ' คลิป FB Reels');
      refreshQueue();
    } catch (e) { addFbProgressItem('error', '❌ ' + e.message); }
    btn.disabled = false; btn.innerHTML = '📋 ลงคิวทั้งหมด';
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'PHIMBOT_FB_REELS_PROGRESS') addFbProgressItem(msg.payload?.level || 'info', msg.payload?.message || '');
  });

  /* ═══ PRODUCTS TAB ═══ */
  const productCount = $('#productCount');
  const productSearch = $('#productSearch');
  const productListEl = $('#productList');
  let allProducts = [];

  async function refreshProducts() { const r = await sendMsg('PHIMBOT_GET_PRODUCTS'); allProducts = r.products || []; renderProducts(allProducts); await loadPickerProducts(); }

  function renderProducts(products) {
    if (productCount) productCount.textContent = products.length;
    if (!products.length) { productListEl.innerHTML = `<div class="queue-empty">ยังไม่มีสินค้า กดสแกนเพื่อดึงจาก TikTok</div>`; return; }
    productListEl.innerHTML = products.map((p, idx) => `
      <div class="product-card" data-id="${p.productId}">
        <img class="product-card-img" src="${p.imageUrl || ''}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2256%22 height=%2256%22%3E%3Crect fill=%22%23333%22 width=%2256%22 height=%2256%22/%3E%3Ctext x=%2228%22 y=%2232%22 text-anchor=%22middle%22 fill=%22%23666%22 font-size=%2214%22%3E📦%3C/text%3E%3C/svg%3E'">
        <div class="product-card-info">
          <div class="product-card-name">${idx + 1}. ${p.name}</div>
          <div class="product-card-meta">
            <span class="price">${p.price ? `฿${p.price.toLocaleString()}` : ''}</span>
            <span>ID: ${p.productId}</span>
            <span class="${p.status === 'active' ? 'status-active' : 'status-inactive'}">${p.statusLabel || p.status}</span>
          </div>
        </div>
        <div class="product-card-actions">
          <button class="btn btn-primary product-use" data-id="${p.productId}">ใช้</button>
          <button class="btn btn-secondary product-copy" data-id="${p.productId}">ID</button>
        </div>
      </div>
    `).join('');

    productListEl.querySelectorAll('.product-use').forEach((btn) => btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const p = allProducts.find((x) => x.productId === btn.dataset.id);
      if (p) { selectProduct(p); $$('.tab-btn').forEach((b) => b.classList.remove('active')); $$('.tab-content').forEach((c) => c.classList.remove('active')); $('[data-tab="post"]').classList.add('active'); $('#tab-post').classList.add('active'); showToast(`✅ เลือก: ${p.name}`); }
    }));
    productListEl.querySelectorAll('.product-copy').forEach((btn) => btn.addEventListener('click', (e) => { e.stopPropagation(); navigator.clipboard.writeText(btn.dataset.id); showToast(`📋 คัดลอก: ${btn.dataset.id}`); }));
  }

  productSearch?.addEventListener('input', () => {
    const q = productSearch.value.trim().toLowerCase();
    renderProducts(q ? allProducts.filter((p) => p.name.toLowerCase().includes(q) || p.productId.includes(q)) : allProducts);
  });

  $('#btnScanProducts')?.addEventListener('click', async () => {
    const btn = $('#btnScanProducts');
    btn.disabled = true; btn.innerHTML = `<span class="spinner"></span> กำลังสแกน...`;
    const scanStatus = $('#scanStatus');
    if (scanStatus) { scanStatus.textContent = 'กำลังสแกนสินค้า กรุณารอ...'; scanStatus.className = 'status-msg'; scanStatus.classList.remove('hidden'); }
    const r = await sendMsg('PHIMBOT_SCAN_PRODUCTS', { limit: 0 });
    if (r.success && r.items?.length) { if (scanStatus) { scanStatus.textContent = `✅ สแกนเสร็จ! พบ ${r.items.length} สินค้า`; scanStatus.className = 'status-msg success'; } showToast(`✅ พบ ${r.items.length} สินค้า`); }
    else { if (scanStatus) { scanStatus.textContent = `❌ สแกนไม่สำเร็จ: ${r.error || r.reason || ''}`; scanStatus.className = 'status-msg error'; } showToast('❌ สแกนไม่สำเร็จ'); }
    btn.disabled = false; btn.innerHTML = '🔍 สแกนสินค้า';
    setTimeout(() => scanStatus?.classList.add('hidden'), 5000);
    await refreshProducts();
  });

  $('#btnClearProducts')?.addEventListener('click', async () => { if (!confirm('ต้องการล้างรายการสินค้า?')) return; await sendMsg('PHIMBOT_CLEAR_PRODUCTS'); allProducts = []; renderProducts([]); showToast('🗑️ ล้างแล้ว'); });

  /* ═══ SETTINGS TAB ═══ */
  const settingsApiKey = $('#settingsApiKey');
  const settingsApiProvider = $('#settingsApiProvider');
  const settingsGeminiKey = $('#settingsGeminiKey');
  const settingsModel = $('#settingsModel');
  const settingsLang = $('#settingsLang');

  const models = window.PhimAI?.POPULAR_MODELS || [
    { id: 'google/gemini-2.5-flash', name: 'Gemini 2.5 Flash' },
    { id: 'anthropic/claude-sonnet-4', name: 'Claude Sonnet 4' },
    { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini' },
  ];
  models.forEach((m) => { const o = document.createElement('option'); o.value = m.id; o.textContent = m.name; settingsModel?.appendChild(o); });

  const settingsZoom = document.querySelector("#settingsZoom");

  async function loadSettings() {
    const config = await sendMsg('PHIMBOT_GET_API_CONFIG');
    if (settingsApiKey) settingsApiKey.value = config.apiKey || '';
    if (settingsApiProvider) settingsApiProvider.value = config.apiProvider || 'openrouter';
    if (settingsGeminiKey) settingsGeminiKey.value = config.geminiKey || '';
    if (settingsModel) settingsModel.value = config.model || 'google/gemini-2.5-flash';
    if (settingsLang) settingsLang.value = window.PhimI18n.getLanguage();
    const data = await chrome.storage.local.get(['phimbot_queue_delay_min', 'phimbot_queue_delay_max', 'phimbot_zoom']);
    if (queueDelayMin) queueDelayMin.value = data.phimbot_queue_delay_min || 100;
    if (queueDelayMax) queueDelayMax.value = data.phimbot_queue_delay_max || 200;
    
    const zoom = data.phimbot_zoom || '1';
    if (settingsZoom) settingsZoom.value = zoom;
    document.body.style.zoom = zoom;
  }

  $('#btnSaveSettings')?.addEventListener('click', async () => {
    await sendMsg('PHIMBOT_SAVE_API_KEY', { apiKey: settingsApiKey?.value?.trim(), geminiKey: settingsGeminiKey?.value?.trim(), model: settingsModel?.value, apiProvider: settingsApiProvider?.value });
    const newLang = settingsLang?.value;
    if (newLang && newLang !== window.PhimI18n.getLanguage()) await window.PhimI18n.setLanguage(newLang);
    const zoom = document.querySelector('#settingsZoom')?.value || '1';
    await chrome.storage.local.set({ phimbot_zoom: zoom });
    document.body.style.zoom = zoom;
    showToast('✅ บันทึกตั้งค่าแล้ว!');
  });

  $('#btnTestApi')?.addEventListener('click', async () => {
    const btn = $('#btnTestApi');
    btn.disabled = true;
    btn.textContent = '⏳ กำลังทดสอบ...';
    try {
      await sendMsg('PHIMBOT_SAVE_API_KEY', { apiKey: settingsApiKey?.value?.trim(), geminiKey: settingsGeminiKey?.value?.trim(), model: settingsModel?.value, apiProvider: settingsApiProvider?.value });
      const res = await sendMsg('PHIMBOT_AI_GENERATE', { action: 'generate_caption', prompt: 'นี่คือข้อความทดสอบระบบ กรุณาตอบกลับแค่คำว่า "OK" เท่านั้น' });
      if (res && res.success) { showToast('✅ เชื่อมต่อ AI สำเร็จ! ระบบพร้อมใช้งาน'); }
      else { showToast('❌ ผิดพลาด: ' + (res?.error || 'ไม่สามารถเชื่อมต่อได้'), true); alert('เชื่อมต่อ AI ไม่สำเร็จ:\n' + (res?.error || 'ไม่ทราบสาเหตุ')); }
    } catch (e) { showToast('❌ ผิดพลาด: ' + e.message, true); }
    finally { btn.disabled = false; btn.textContent = '🧪 ทดสอบ API Key'; }
  });

  /* ═══ INIT ═══ */
  await loadSettings();
  await loadPickerProducts();
  refreshQueue();
  refreshProducts();

  const now = new Date();
  now.setMinutes(now.getMinutes() + 30);
  const sd = $('#scheduleDate'); const stEl = $('#scheduleTime');
  if (sd) sd.value = now.toISOString().split('T')[0];
  if (stEl) stEl.value = now.toTimeString().slice(0, 5);














/* ═══════════════════════════════════════════════════════════════
   SHOPEE TAB
   ═══════════════════════════════════════════════════════════════ */
(function initShopeeTab() {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);
  const showToast = (msg) => { const t = document.createElement('div'); t.className = 'toast show'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 3000); };
  const shopeeUrlInput = $('#shopeeUrlInput');
  const btnShopeeGo = $('#btnShopeeGo');
  const shopeeStatus = $('#shopeeStatus');
  const shopeeProductCard = $('#shopeeProductCard');
  let currentShopeeProduct = null;

  function showShopeeStatus(msg, type = 'info') {
    if (!shopeeStatus) return;
    shopeeStatus.className = 'status-msg ' + type;
    shopeeStatus.textContent = msg;
    shopeeStatus.classList.remove('hidden');
  }
  function hideShopeeStatus() { shopeeStatus?.classList.add('hidden'); }

  function formatPrice(p) {
    if (!p) return '';
    const num = parseFloat(String(p).replace(/,/g, ''));
    if (isNaN(num)) return String(p);
    if (num > 100000) return '฿' + (num / 100000).toLocaleString('th-TH', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    return '฿' + num.toLocaleString('th-TH');
  }

  function displayShopeeProduct(data) {
    currentShopeeProduct = data;
    if (!shopeeProductCard) return;
    shopeeProductCard.classList.remove('hidden');

    $('#shopeeProductName').textContent = data.title || 'ไม่มีชื่อ';
    $('#shopeeProductPrice').textContent = formatPrice(data.price);
    const origPrice = $('#shopeeProductOrigPrice');
    if (data.originalPrice && data.originalPrice !== data.price) {
      origPrice.textContent = formatPrice(data.originalPrice);
      origPrice.style.display = '';
    } else { origPrice.style.display = 'none'; }

    const discBadge = $('#shopeeProductDiscount');
    if (data.discount) {
      discBadge.textContent = '-' + data.discount + '%';
      discBadge.style.display = '';
    } else { discBadge.style.display = 'none'; }

    $('#shopeeProductRating').textContent = data.rating ? '\u2b50 ' + data.rating : '';
    $('#shopeeProductSold').textContent = data.sold ? 'ขายแล้ว ' + data.sold : '';

    // Main image
    const mainImg = $('#shopeeProductImg');
    if (data.images && data.images.length) {
      const imgSrc = typeof data.images[0] === 'string' ? data.images[0] : (data.images[0]?.url || '');
      mainImg.src = imgSrc.startsWith('//') ? 'https:' + imgSrc : imgSrc;
    } else { mainImg.src = ''; }

    // Gallery
    const gallery = $('#shopeeGallery');
    gallery.innerHTML = '';
    if (data.images && data.images.length > 1) {
      data.images.slice(0, 8).forEach((img, idx) => {
        const src = typeof img === 'string' ? img : (img?.url || '');
        const fullSrc = src.startsWith('//') ? 'https:' + src : src;
        const imgEl = document.createElement('img');
        imgEl.src = fullSrc;
        imgEl.style.cssText = 'width:56px; height:56px; object-fit:cover; border-radius:6px; cursor:pointer; border:2px solid transparent;';
        imgEl.addEventListener('click', () => { mainImg.src = fullSrc; });
        gallery.appendChild(imgEl);
      });
    }

    // Affiliate link
    const affEl = $('#shopeeAffLink');
    if (data.affiliateUrl) {
      affEl.innerHTML = '\ud83d\udd17 <a href="' + data.affiliateUrl + '" target="_blank" style="color:#1877f2;">' + data.affiliateUrl + '</a>';
    } else { affEl.textContent = ''; }
  }

  async function fetchShopeeProduct() {
    const url = shopeeUrlInput?.value?.trim();
    if (!url) { showShopeeStatus('กรุณาวาง URL สินค้า Shopee', 'warning'); return; }
    showShopeeStatus('กำลังดึงข้อมูล...', 'info');
    btnShopeeGo.disabled = true;
    btnShopeeGo.textContent = '\u23f3';

    try {
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'PHIMBOT_FETCH_SHOPEE', url }, (resp) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(resp);
        });
      });

      if (result?.ok) {
        hideShopeeStatus();
        displayShopeeProduct(result);
        loadShopeeHistory();
      } else {
        showShopeeStatus('❌ ' + (result?.reason || 'ดึงไม่สำเร็จ'), 'error');
      }
    } catch (err) {
      showShopeeStatus('❌ ' + err.message, 'error');
    }
    btnShopeeGo.disabled = false;
    btnShopeeGo.textContent = 'ดึง';
  }

  btnShopeeGo?.addEventListener('click', fetchShopeeProduct);
  shopeeUrlInput?.addEventListener('keydown', (e) => { if (e.key === 'Enter') fetchShopeeProduct(); });

  // Copy affiliate link
  $('#btnShopeeCopyLink')?.addEventListener('click', () => {
    if (currentShopeeProduct?.affiliateUrl) {
      navigator.clipboard.writeText(currentShopeeProduct.affiliateUrl);
      showToast('✅ คัดลอกแล้ว!');
    }
  });

  // AI Caption
  $('#btnShopeeAiCaption')?.addEventListener('click', async () => {
    if (!currentShopeeProduct) return;
    const btn = $('#btnShopeeAiCaption');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> AI...';
    const p = currentShopeeProduct;
    const prompt = 'สร้างแคปชั่นขายสินค้า Shopee ภาษาไทย 2-3 ประโยค ดึงดูดใจ ใส่อิโมจิ ใส่ 5 # ที่เกี่ยวข้อง\nชื่อสินค้า: ' + p.title + '\nราคา: ' + formatPrice(p.price) + (p.discount ? ' (ลด ' + p.discount + '%)' : '') + (p.sold ? '\nขายแล้ว: ' + p.sold : '') + '\nลิงก์: ' + (p.affiliateUrl || '');
    try {
      const resp = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'PHIMBOT_AI_REQUEST', action: 'generate_caption', prompt }, r => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(r);
        });
      });
      const captionText = resp?.caption || resp?.text || resp?.result || '';
      if (captionText) {
        $('#shopeeAiCaption')?.classList.remove('hidden');
        $('#shopeeCaptionResult').value = captionText;
      }
    } catch (e) { showToast('❌ AI: ' + e.message); }
    btn.disabled = false; btn.innerHTML = '📝 สร้างแคปชั่น AI';
  });

  // Use for Reels
  $('#btnShopeeUseReels')?.addEventListener('click', () => {
    if (!currentShopeeProduct) return;
    const p = currentShopeeProduct;
    const caption = ($('#shopeeCaptionResult')?.value || p.title) + '\n\n🛒 ' + (p.affiliateUrl || p.productUrl);
    const fbCaption = $('#fbReelsCaption');
    if (fbCaption) {
      fbCaption.value = caption;
      document.querySelector('[data-tab="fb-reels"]')?.click();
      showToast('✅ เติมแคปชั่นแล้ว!');
    }
  });

  // Load history
  async function loadShopeeHistory() {
    try {
      const stored = await chrome.storage.local.get('phimbot_shopee_history');
      const history = stored.phimbot_shopee_history || [];
      const container = $('#shopeeHistory');
      if (!container) return;
      if (!history.length) { container.textContent = 'ยังไม่มีประวัติ'; return; }
      container.innerHTML = history.slice(0, 5).map(h =>
        '<div style="padding:4px 0; border-bottom:1px solid #1a1a2e; cursor:pointer;" data-url="' + h.url + '">' +
        '<div style="color:#e0e0e0; font-size:11px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + (h.title || h.url) + '</div>' +
        '<div style="color:#ff6740; font-size:10px;">' + formatPrice(h.price) + '</div>' +
        '</div>'
      ).join('');
      container.querySelectorAll('[data-url]').forEach(el => {
        el.addEventListener('click', () => {
          shopeeUrlInput.value = el.dataset.url;
          fetchShopeeProduct();
        });
      });
    } catch (_) {}
  }
  // Shopee Affiliate Login Button
  $('#btnShopeeLogin')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://affiliate.shopee.co.th/offer/product_offer', active: true });
  });

  loadShopeeHistory();
})();


/* ═══════════════════════════════════════════════════════════════
   SHOPEE KEYWORD SCANNER UI
   ═══════════════════════════════════════════════════════════════ */
(function initShopeeScanner() {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);
  const showToast = (msg) => { const t = document.createElement('div'); t.className = 'toast show'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 3000); };
  let scanResults = window.shopeeScannedProducts = [];
  let currentSort = 'score';

  const scanStatus = $('#shopeeScanStatus');
  function showScanStatus(msg, type) {
    if (!scanStatus) return;
    scanStatus.className = 'status-msg ' + (type || 'info');
    scanStatus.textContent = msg;
    scanStatus.classList.remove('hidden');
  }

  function formatThb(n) {
    if (!n) return '';
    const num = Number(n);
    if (isNaN(num)) return String(n);
    return '฿' + num.toLocaleString('th-TH');
  }

  function sortResults(items, by) {
    const arr = [...items];
    switch (by) {
      case 'score': return arr.sort((a, b) => (b.trendScore || 0) - (a.trendScore || 0));
      case 'sold': return arr.sort((a, b) => (b.sold || 0) - (a.sold || 0));
      case 'revenue': return arr.sort((a, b) => (b.revenue || 0) - (a.revenue || 0));
      case 'rating': return arr.sort((a, b) => (b.rating || 0) - (a.rating || 0));
      case 'price': return arr.sort((a, b) => (a.price || 0) - (b.price || 0));
      default: return arr;
    }
  }

  function renderScanResults() {
    const container = $('#shopeeScanResults');
    const wrap = $('#shopeeScanResultsWrap');
    const countEl = $('#shopeeScanCount');
    const actionsEl = $('#shopeeScanActions');
    if (!container) return;

    const sorted = sortResults(scanResults, currentSort);
    wrap?.classList.remove('hidden');

    // Summary stats
    const mallCount = sorted.filter(i => i.isMall).length;
    const extraCount = sorted.filter(i => i.isExtraComm).length;
    const linkCount = sorted.filter(i => i.affiliateUrl && !i.affiliateUrl.includes('affiliate.shopee.co.th')).length;
    if (countEl) {
      countEl.innerHTML = 'พบ ' + sorted.length + ' สินค้า' +
        (mallCount ? ' | <span style="color:#ee4d2d;">Mall ' + mallCount + '</span>' : '') +
        (extraCount ? ' | <span style="color:#ff6740;">EXTRACOMM ' + extraCount + '</span>' : '') +
        (linkCount ? ' | <span style="color:#10b981;">มีลิงก์ ' + linkCount + '</span>' : '');
    }
    if (actionsEl && sorted.length) { actionsEl.classList.remove('hidden'); actionsEl.style.display = 'flex'; }

    container.innerHTML = sorted.map((item, idx) => {
      const scoreColor = item.trendScore >= 70 ? '#10b981' : item.trendScore >= 40 ? '#f59e0b' : '#ef4444';
      const hasLink = item.affiliateUrl && !item.affiliateUrl.includes('affiliate.shopee.co.th');

      // Badges row
      const badgeParts = [];
      if (hasLink) badgeParts.push('<span style="background:#10b981; color:#fff; padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600;">มีลิงก์แล้ว</span>');
      if (item.isExtraComm) badgeParts.push('<span style="background:#ff6740; color:#fff; padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600;">EXTRA COMM</span>');
      if (item.isMall) badgeParts.push('<span style="background:#ee4d2d; color:#fff; padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600;">Mall</span>');
      if (item.isPreferred) badgeParts.push('<span style="background:#1877f2; color:#fff; padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600;">แนะนำ</span>');
      const badgesRow = badgeParts.length ? '<div style="display:flex; gap:4px; flex-wrap:wrap; margin-bottom:6px;">' + badgeParts.join('') + '</div>' : '';

      // Sales text
      const soldText = item.sold ? 'ขายแล้ว ' + item.sold.toLocaleString() + ' ชิ้น' : '';

      // Commission text  
      const commText = item.commissionRate ? '<div style="color:#10b981; font-size:11px; margin-top:3px;">\u{1F4B0} อัตราค่าคอมมิชชั่น ' + item.commissionRate + '%</div>' : '';

      return '<div class="scan-item" style="background:#1a1a2e; border-radius:10px; padding:10px; margin-bottom:2px;" data-idx="' + idx + '">' +
        // Badges row
        badgesRow +
        // Content row
        '<div style="display:flex; gap:10px; align-items:flex-start;">' +
          '<input type="checkbox" class="scan-check" data-idx="' + idx + '" style="flex-shrink:0; width:16px; height:16px; accent-color:#f90; cursor:pointer; margin-top:4px;">' +
          '<img src="' + (item.imageUrl || '') + '" style="width:60px; height:60px; object-fit:cover; border-radius:8px; flex-shrink:0; background:#0d0d1a; cursor:pointer;" class="scan-img" data-idx="' + idx + '">' +
          '<div style="flex:1; min-width:0;">' +
            '<div style="font-size:12px; color:#e0e0e0; line-height:1.4; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">' + (item.title || '') + '</div>' +
            '<div style="margin-top:4px; display:flex; align-items:center; gap:6px;">' +
              '<span style="color:#ff6740; font-weight:bold; font-size:14px;">' + formatThb(item.price) + '</span>' +
              (soldText ? '<span style="font-size:10px; color:#888;">' + soldText + '</span>' : '') +
            '</div>' +
            commText +
            '<div style="margin-top:2px; font-size:10px; color:#666;">' +
              '<span style="color:' + scoreColor + '; font-weight:bold;">Score: ' + (item.trendScore || 0) + '</span>' +
            '</div>' +
          '</div>' +
        '</div>' +
        // Action buttons row
        '<div style="display:flex; gap:4px; margin-top:8px; justify-content:flex-end;">' +
          '<button class="btn btn-secondary btn-sm scan-open-btn" data-idx="' + idx + '" style="font-size:10px; padding:3px 8px;">เปิด</button>' +
          '<button class="btn btn-secondary btn-sm scan-copy-btn" data-idx="' + idx + '" style="font-size:10px; padding:3px 8px;">คัดลอก</button>' +
          '<button class="btn btn-primary btn-sm scan-use-btn" data-idx="' + idx + '" style="font-size:10px; padding:3px 8px;">ใช้Reels</button>' +
        '</div>' +
      '</div>';
    }).join('');

    // ─── Event Bindings ───
    const updateSelectedCount = () => {
      const checks = container.querySelectorAll('.scan-check:checked');
      const countSpan = $('#shopeeSelectedCount');
      if (countSpan) countSpan.textContent = checks.length + ' รายการ';
    };
    container.querySelectorAll('.scan-check').forEach(cb => cb.addEventListener('change', updateSelectedCount));

    const selectAllCb = $('#shopeeSelectAll');
    if (selectAllCb) {
      selectAllCb.onchange = () => {
        container.querySelectorAll('.scan-check').forEach(cb => { cb.checked = selectAllCb.checked; });
        updateSelectedCount();
      };
    }

    // Image click = toggle checkbox
    container.querySelectorAll('.scan-img').forEach(img => {
      img.addEventListener('click', () => {
        const cb = container.querySelector('.scan-check[data-idx="' + img.dataset.idx + '"]');
        if (cb) { cb.checked = !cb.checked; updateSelectedCount(); }
      });
    });

    // "เปิด" button - open offer page
    container.querySelectorAll('.scan-open-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = sortResults(scanResults, currentSort)[parseInt(btn.dataset.idx)];
        if (item?.offerUrl) chrome.tabs.create({ url: item.offerUrl, active: true });
      });
    });

    // "คัดลอก" button - copy affiliate link or offer URL
    container.querySelectorAll('.scan-copy-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = sortResults(scanResults, currentSort)[parseInt(btn.dataset.idx)];
        if (!item) return;
        const link = (item.affiliateUrl && !item.affiliateUrl.includes('affiliate.shopee.co.th')) ? item.affiliateUrl : item.offerUrl || '';
        if (link) { navigator.clipboard.writeText(link); showToast('\u2705 คัดลอกแล้ว!'); }
        else showToast('ยังไม่มีลิงก์ กดดึงลิงก์ก่อน');
      });
    });

    // "ใช้Reels" button - use for Reels
    container.querySelectorAll('.scan-use-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = sortResults(scanResults, currentSort)[parseInt(btn.dataset.idx)];
        if (!item) return;
        document.querySelector('[data-tab="fb-reels"]')?.click();
        window.dispatchEvent(new CustomEvent('phimbot-select-product', { detail: item }));
      });
    });
  }

  // ─── Get Links for selected items ───
  $('#btnShopeeGetLinks')?.addEventListener('click', async () => {
    const container = $('#shopeeScanResults');
    const checks = container?.querySelectorAll('.scan-check:checked') || [];
    if (!checks.length) { showToast('กรุณาเลือกสินค้าก่อน'); return; }
    const btn = $('#btnShopeeGetLinks');
    const sorted = sortResults(scanResults, currentSort);
    btn.disabled = true;
    let done = 0;
    const total = checks.length;
    btn.textContent = '\u{1F517} 0/' + total;

    for (const cb of checks) {
      const idx = parseInt(cb.dataset.idx);
      const item = sorted[idx];
      if (!item || !item.offerId) { done++; continue; }
      if (item.affiliateUrl && !item.affiliateUrl.includes('affiliate.shopee.co.th')) { done++; btn.textContent = '\u{1F517} ' + done + '/' + total; continue; }

      try {
        const result = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({
            type: 'PHIMBOT_GET_AFFILIATE_LINK',
            item: { offerId: item.offerId, title: item.title, offerUrl: item.offerUrl }
          }, r => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(r);
          });
        });
        if (result?.ok && result?.affiliateUrl) {
          item.affiliateUrl = result.affiliateUrl;
        }
      } catch (err) { console.warn('Get link failed:', err); }
      done++;
      btn.textContent = '\u{1F517} ' + done + '/' + total;
    }

    btn.disabled = false;
    btn.textContent = '\u{1F517} ดึงลิงก์ที่เลือก';
    showToast('\u2705 ดึงลิงก์เสร็จ ' + done + ' สินค้า');
    renderScanResults(); // Re-render to show badges
  });

  // ─── Use selected for Reels ───
  $('#btnShopeeUseReels')?.addEventListener('click', () => {
    const container = $('#shopeeScanResults');
    const checks = container?.querySelectorAll('.scan-check:checked') || [];
    if (!checks.length) { showToast('กรุณาเลือกสินค้าก่อน'); return; }
    const idx = parseInt([...checks][0].dataset.idx);
    const item = sortResults(scanResults, currentSort)[idx];
    if (item) {
      document.querySelector('[data-tab="fb-reels"]')?.click();
      window.dispatchEvent(new CustomEvent('phimbot-select-product', { detail: item }));
    }
  });

  // Sort chips
  document.querySelectorAll('.shopee-sort-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.shopee-sort-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentSort = chip.dataset.sort;
      renderScanResults();
    });
  });

  // Scan button
  $('#btnShopeeScan')?.addEventListener('click', async () => {
    const keyword = $('#shopeeScanKeyword')?.value?.trim();
    if (!keyword) { showScanStatus('กรุณาพิมพ์ keyword', 'warning'); return; }
    const pages = parseInt($('#shopeeScanPages')?.value) || 3;
    const sort = $('#shopeeScanSort')?.value || 'sold';
    const filters = {
      extraComm: $('#shopeeFilterExtraComm')?.checked || false,
      mall: $('#shopeeFilterMall')?.checked || false,
      preferred: $('#shopeeFilterPreferred')?.checked || false,
    };

    showScanStatus('กำลังเริ่มสแกน...', 'info');
    const btn = $('#btnShopeeScan');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังสแกน...';
    const startTime = Date.now();

    try {
      const result = await new Promise((resolve, reject) => {
        // Use Port for persistent connection (no timeout)
        const port = chrome.runtime.connect({ name: 'shopee-scanner' });
        let resolved = false;

        port.onMessage.addListener((msg) => {
          if (msg.type === 'status') {
            const elapsed = Math.round((Date.now() - startTime) / 1000);
            const step = msg.step === 'opening_tab' ? '📂 เปิดแท็บ...' :
              msg.step === 'waiting_for_page' ? '⏳ รอหน้าเว็บโหลด...' : '🔍 กำลังสแกน...';
            showScanStatus(step + ' (' + elapsed + 'วิ)', 'info');
          }
          if (msg.type === 'result') {
            resolved = true;
            port.disconnect();
            resolve(msg);
          }
        });

        port.onDisconnect.addListener(() => {
          if (!resolved) {
            const err = chrome.runtime.lastError?.message || 'port disconnected';
            reject(new Error(err));
          }
        });

        // Send scan command
        port.postMessage({
          action: 'start_scan',
          keyword,
          options: { pages, sort, filters }
        });

        // Safety timeout: 5 minutes
        setTimeout(() => {
          if (!resolved) {
            resolved = true;
            try { port.disconnect(); } catch(_) {}
            resolve({ ok: false, reason: 'หมดเวลา (5 นาที)', items: [] });
          }
        }, 5 * 60 * 1000);
      });

      if (result?.ok && result?.items?.length) {
        scanResults = window.shopeeScannedProducts = result.items || [];
        showScanStatus('✅ พบ ' + scanResults.length + ' สินค้า', 'success');
        renderScanResults();
      } else {
        showScanStatus('❌ ' + (result?.reason || 'ไม่พบสินค้า'), 'error');
      }
    } catch (err) {
      showScanStatus('❌ ' + err.message, 'error');
    }
    btn.disabled = false; btn.innerHTML = '🔥 สแกน';
  });

  // Enter key to scan
  $('#shopeeScanKeyword')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('#btnShopeeScan')?.click();
  });
})();

/* ═══════════════════════════════════════════════════════════════
   FB Reels - Shopee Product Picker
   ═══════════════════════════════════════════════════════════════ */
let fbReelsSelectedProduct = null;

(function initFbReelsProductPicker() {
  const $ = (sel) => document.querySelector(sel);
  const showToast = (msg) => {
    const t = document.getElementById('toast');
    if (t) { t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2500); }
  };

  // ─── Product Selection ───
  async function selectProduct(product) {
    console.log('[PhimBot-SP] selectProduct:', product?.offerId, 'affiliateUrl:', product?.affiliateUrl);
    fbReelsSelectedProduct = product;
    const card = document.getElementById('fbReelsProductCard');
    const picker = document.getElementById('fbReelsProductPicker');
    if (!card || !picker) { console.warn('[PhimBot-SP] card/picker not found'); return; }

    const imgEl = document.getElementById('fbReelsProductImg');
    const titleEl = document.getElementById('fbReelsProductTitle');
    const priceEl = document.getElementById('fbReelsProductPrice');
    if (imgEl) imgEl.src = product.imageUrl || product.images?.[0]?.url || product.images?.[0] || '';
    if (titleEl) titleEl.textContent = product.title || '';
    if (priceEl) priceEl.textContent = '฿' + (product.price || '0') + (product.commissionRate ? '  คอมฯ ' + product.commissionRate + '%' : '');
    
    card.classList.remove('hidden');
    picker.style.display = 'none';
    closeModal();

    // Helper: always get fresh reference
    const getLinkEl = () => document.getElementById('fbReelsProductLinkText');
    const hasRealLink = product.affiliateUrl && /^https:\/\/(s\.shopee\.co\.th|shope\.ee)\//i.test(product.affiliateUrl);
    console.log('[PhimBot-SP] hasRealLink:', hasRealLink, 'offerId:', product.offerId);

    if (hasRealLink) {
      const el = getLinkEl();
      if (el) { el.textContent = '🔗 ' + product.affiliateUrl; el.style.color = '#10b981'; }
      console.log('[PhimBot-SP] Using existing link:', product.affiliateUrl);
    } else if (product.offerId) {
      const el = getLinkEl();
      if (el) { el.textContent = '⏳ กำลังดึง affiliate link...'; el.style.color = '#f59e0b'; }
      console.log('[PhimBot-SP] Fetching link for offerId:', product.offerId);
      try {
        const linkResult = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({
            type: 'PHIMBOT_GET_AFFILIATE_LINK',
            item: { offerId: product.offerId, title: product.title, offerUrl: product.offerUrl }
          }, r => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(r);
          });
        });
        console.log('[PhimBot-SP] linkResult:', JSON.stringify(linkResult));
        const el2 = getLinkEl(); // Fresh reference after await
        if (linkResult?.ok && linkResult?.affiliateUrl) {
          product.affiliateUrl = linkResult.affiliateUrl;
          fbReelsSelectedProduct.affiliateUrl = linkResult.affiliateUrl;
          if (el2) { el2.textContent = '🔗 ' + linkResult.affiliateUrl; el2.style.color = '#10b981'; }
          showToast('✅ ได้ affiliate link แล้ว!');
          // Also update scanner results if exists
          if (window.shopeeScannedProducts) {
            const scanItem = window.shopeeScannedProducts.find(i => i.offerId === product.offerId);
            if (scanItem) scanItem.affiliateUrl = linkResult.affiliateUrl;
          }
        } else {
          if (el2) { el2.textContent = '❌ ดึง link ไม่ได้: ' + (linkResult?.reason || 'unknown'); el2.style.color = '#ef4444'; }
        }
      } catch (err) {
        console.error('[PhimBot-SP] Link fetch error:', err);
        const el3 = getLinkEl();
        if (el3) { el3.textContent = '❌ ' + err.message; el3.style.color = '#ef4444'; }
      }
    } else {
      const el = getLinkEl();
      if (el) { el.textContent = product.offerUrl ? '📎 ' + product.offerUrl : ''; el.style.color = '#888'; }
    }
  }

  function removeProduct() {
    fbReelsSelectedProduct = null;
    const card = $('#fbReelsProductCard');
    const picker = $('#fbReelsProductPicker');
    if (card) card.classList.add('hidden');
    if (picker) picker.style.display = '';
  }

  // ─── Modal ───
  function openModal() {
    const modal = $('#fbReelsProductModal');
    if (modal) { modal.classList.remove('hidden'); modal.style.display = 'flex'; }
    loadScannedProducts();
  }

  function closeModal() {
    const modal = $('#fbReelsProductModal');
    if (modal) { modal.classList.add('hidden'); modal.style.display = 'none'; }
  }

  // ─── Tab switching in modal ───
  document.querySelectorAll('.product-modal-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.product-modal-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const target = tab.getAttribute('data-pm-tab');
      const urlTab = $('#productModalUrlTab');
      const scannedTab = $('#productModalScannedTab');
      if (target === 'url') {
        if (urlTab) urlTab.classList.remove('hidden');
        if (scannedTab) scannedTab.classList.add('hidden');
      } else {
        if (urlTab) urlTab.classList.add('hidden');
        if (scannedTab) scannedTab.classList.remove('hidden');
        loadScannedProducts();
      }
    });
  });

  // ─── Fetch product from URL ───
  $('#btnProductModalFetch')?.addEventListener('click', async () => {
    const input = $('#productModalUrlInput');
    const url = input?.value?.trim();
    if (!url) { showToast('กรุณาวาง URL'); return; }
    const resultDiv = $('#productModalUrlResult');
    if (resultDiv) resultDiv.innerHTML = '<span class="spinner"></span> กำลังดึงข้อมูล...';

    try {
      const resp = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'PHIMBOT_FETCH_SHOPEE', url }, r => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(r);
        });
      });
      if (resp?.ok) {
        if (resultDiv) {
          resultDiv.innerHTML = '';
          const item = document.createElement('div');
          item.className = 'product-modal-item';
          item.innerHTML = '<img src="' + (resp.images?.[0]?.url || resp.images?.[0] || '') + '" />'
            + '<div style="flex:1;min-width:0;">'
            + '<div class="pm-title">' + (resp.title || '') + '</div>'
            + '<div class="pm-price">฿' + (resp.price || '0') + '</div>'
            + '</div>';
          item.addEventListener('click', () => {
            selectProduct({
              title: resp.title, price: resp.price, imageUrl: resp.images?.[0]?.url || resp.images?.[0] || '',
              affiliateUrl: resp.affiliateUrl || resp.productUrl || '',
              commission: resp.commission || '',
              commissionRate: 0,
            });
          });
          resultDiv.appendChild(item);
        }
      } else {
        if (resultDiv) resultDiv.innerHTML = '<span style="color:#f66;">\u274c ' + (resp?.reason || 'ไม่พบสินค้า') + '</span>';
      }
    } catch (err) {
      if (resultDiv) resultDiv.innerHTML = '<span style="color:#f66;">\u274c ' + err.message + '</span>';
    }
  });

  // ─── Load scanned products ───
  function loadScannedProducts() {
    const list = $('#productModalScannedList');
    if (!list) return;
    // Access scanResults from the scanner IIFE (global-ish)
    const products = Array.isArray(window.shopeeScannedProducts) ? window.shopeeScannedProducts : [];
    if (!products.length) {
      list.innerHTML = '<p style="text-align:center;opacity:.5;font-size:13px;">ยังไม่มีสินค้า ไปสแกนที่แท็บ Shopee ก่อน</p>';
      return;
    }
    list.innerHTML = '';
    products.forEach(p => {
      const item = document.createElement('div');
      item.className = 'product-modal-item';
      item.innerHTML = '<img src="' + (p.imageUrl || '') + '" />'
        + '<div style="flex:1;min-width:0;">'
        + '<div class="pm-title">' + (p.title || '') + '</div>'
        + '<div class="pm-price">฿' + (p.price || '0') + (p.commissionRate ? '  คอมฯ ' + p.commissionRate + '%' : '') + '</div>'
        + '<div class="pm-score">Score: ' + (p.trendScore || 0) + ' | ขายแล้ว ' + (p.sold || 0) + '</div>'
        + '</div>';
      item.addEventListener('click', () => {
        selectProduct({
          title: p.title, price: p.price, imageUrl: p.imageUrl,
          affiliateUrl: p.offerUrl || '',
          commissionRate: p.commissionRate || 0,
          commission: p.commissionRate ? p.commissionRate + '%' : '',
          sold: p.sold,
        });
      });
      list.appendChild(item);
    });
  }

  // ─── Event listeners ───
  $('#btnFbReelsPickProduct')?.addEventListener('click', openModal);
  $('#btnFbReelsRemoveProduct')?.addEventListener('click', removeProduct);
  $('#btnCloseProductModal')?.addEventListener('click', closeModal);

  // Close modal on overlay click
  $('#fbReelsProductModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'fbReelsProductModal') closeModal();
  });

  // Enter key in URL input
  $('#productModalUrlInput')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('#btnProductModalFetch')?.click();
  });
  // Listen for product selection from scanner tab
  window.addEventListener('phimbot-select-product', (e) => {
    if (e.detail) selectProduct(e.detail);
  });


})();












/* ═══════════════════════════════════════════════════════════════
   SHOPEE TAB
   ═══════════════════════════════════════════════════════════════ */
(function initShopeeTab() {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);
  const showToast = (msg) => { const t = document.createElement('div'); t.className = 'toast show'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 3000); };
  const shopeeUrlInput = $('#shopeeUrlInput');
  const btnShopeeGo = $('#btnShopeeGo');
  const shopeeStatus = $('#shopeeStatus');
  const shopeeProductCard = $('#shopeeProductCard');
  let currentShopeeProduct = null;

  function showShopeeStatus(msg, type = 'info') {
    if (!shopeeStatus) return;
    shopeeStatus.className = 'status-msg ' + type;
    shopeeStatus.textContent = msg;
    shopeeStatus.classList.remove('hidden');
  }
  function hideShopeeStatus() { shopeeStatus?.classList.add('hidden'); }

  function formatPrice(p) {
    if (!p) return '';
    const num = parseFloat(String(p).replace(/,/g, ''));
    if (isNaN(num)) return String(p);
    if (num > 100000) return '฿' + (num / 100000).toLocaleString('th-TH', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    return '฿' + num.toLocaleString('th-TH');
  }

  function displayShopeeProduct(data) {
    currentShopeeProduct = data;
    if (!shopeeProductCard) return;
    shopeeProductCard.classList.remove('hidden');

    $('#shopeeProductName').textContent = data.title || 'ไม่มีชื่อ';
    $('#shopeeProductPrice').textContent = formatPrice(data.price);
    const origPrice = $('#shopeeProductOrigPrice');
    if (data.originalPrice && data.originalPrice !== data.price) {
      origPrice.textContent = formatPrice(data.originalPrice);
      origPrice.style.display = '';
    } else { origPrice.style.display = 'none'; }

    const discBadge = $('#shopeeProductDiscount');
    if (data.discount) {
      discBadge.textContent = '-' + data.discount + '%';
      discBadge.style.display = '';
    } else { discBadge.style.display = 'none'; }

    $('#shopeeProductRating').textContent = data.rating ? '\u2b50 ' + data.rating : '';
    $('#shopeeProductSold').textContent = data.sold ? 'ขายแล้ว ' + data.sold : '';

    // Main image
    const mainImg = $('#shopeeProductImg');
    if (data.images && data.images.length) {
      const imgSrc = typeof data.images[0] === 'string' ? data.images[0] : (data.images[0]?.url || '');
      mainImg.src = imgSrc.startsWith('//') ? 'https:' + imgSrc : imgSrc;
    } else { mainImg.src = ''; }

    // Gallery
    const gallery = $('#shopeeGallery');
    gallery.innerHTML = '';
    if (data.images && data.images.length > 1) {
      data.images.slice(0, 8).forEach((img, idx) => {
        const src = typeof img === 'string' ? img : (img?.url || '');
        const fullSrc = src.startsWith('//') ? 'https:' + src : src;
        const imgEl = document.createElement('img');
        imgEl.src = fullSrc;
        imgEl.style.cssText = 'width:56px; height:56px; object-fit:cover; border-radius:6px; cursor:pointer; border:2px solid transparent;';
        imgEl.addEventListener('click', () => { mainImg.src = fullSrc; });
        gallery.appendChild(imgEl);
      });
    }

    // Affiliate link
    const affEl = $('#shopeeAffLink');
    if (data.affiliateUrl) {
      affEl.innerHTML = '\ud83d\udd17 <a href="' + data.affiliateUrl + '" target="_blank" style="color:#1877f2;">' + data.affiliateUrl + '</a>';
    } else { affEl.textContent = ''; }
  }

  async function fetchShopeeProduct() {
    const url = shopeeUrlInput?.value?.trim();
    if (!url) { showShopeeStatus('กรุณาวาง URL สินค้า Shopee', 'warning'); return; }
    showShopeeStatus('กำลังดึงข้อมูล...', 'info');
    btnShopeeGo.disabled = true;
    btnShopeeGo.textContent = '\u23f3';

    try {
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'PHIMBOT_FETCH_SHOPEE', url }, (resp) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(resp);
        });
      });

      if (result?.ok) {
        hideShopeeStatus();
        displayShopeeProduct(result);
        loadShopeeHistory();
      } else {
        showShopeeStatus('❌ ' + (result?.reason || 'ดึงไม่สำเร็จ'), 'error');
      }
    } catch (err) {
      showShopeeStatus('❌ ' + err.message, 'error');
    }
    btnShopeeGo.disabled = false;
    btnShopeeGo.textContent = 'ดึง';
  }

  btnShopeeGo?.addEventListener('click', fetchShopeeProduct);
  shopeeUrlInput?.addEventListener('keydown', (e) => { if (e.key === 'Enter') fetchShopeeProduct(); });

  // Copy affiliate link
  $('#btnShopeeCopyLink')?.addEventListener('click', () => {
    if (currentShopeeProduct?.affiliateUrl) {
      navigator.clipboard.writeText(currentShopeeProduct.affiliateUrl);
      showToast('✅ คัดลอกแล้ว!');
    }
  });

  // AI Caption
  $('#btnShopeeAiCaption')?.addEventListener('click', async () => {
    if (!currentShopeeProduct) return;
    const btn = $('#btnShopeeAiCaption');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> AI...';
    const p = currentShopeeProduct;
    const prompt = 'สร้างแคปชั่นขายสินค้า Shopee ภาษาไทย 2-3 ประโยค ดึงดูดใจ ใส่อิโมจิ ใส่ 5 # ที่เกี่ยวข้อง\nชื่อสินค้า: ' + p.title + '\n
  /* ─── TikTok Showcase API Fetch (Products Tab) ─────────────────────── */
  const btnFetchShowcaseApi = document.getElementById('btnFetchShowcaseApi');
  const btnScanProducts = document.getElementById('btnScanProducts');
  const btnClearProducts = document.getElementById('btnClearProducts');
  const productCount = document.getElementById('productCount');
  const productList = document.getElementById('productList');
  const productSearch = document.getElementById('productSearch');
  const scanStatus = document.getElementById('scanStatus');

  let showcaseProducts = [];

  function renderProductList(products) {
    if (!productList) return;
    if (!products || products.length === 0) {
      productList.innerHTML = '<div class="queue-empty">ยังไม่มีสินค้า กดดึงสินค้าจาก TikTok</div>';
      if (productCount) productCount.textContent = '0';
      return;
    }
    if (productCount) productCount.textContent = String(products.length);
    productList.innerHTML = products.map((p, i) => `
      <div class="product-card" style="display:flex;gap:10px;padding:10px;border-bottom:1px solid rgba(255,255,255,0.06);align-items:center;">
        <img src="${p.imageUrl || ''}" style="width:50px;height:50px;object-fit:cover;border-radius:6px;flex-shrink:0;background:#1a1a2e;" onerror="this.style.display='none'">
        <div style="flex:1;min-width:0;">
          <div style="font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name || 'ไม่มีชื่อ'}</div>
          <div style="font-size:11px;opacity:0.6;margin-top:2px;">ID: ${p.productId} ${p.statusLabel ? '| ' + p.statusLabel : ''}</div>
        </div>
        <div style="display:flex;gap:4px;flex-shrink:0;">
          <button class="btn btn-sm btn-primary" data-action="use" data-idx="${i}" title="ใช้สินค้านี้" style="font-size:11px;padding:4px 8px;">ใช้</button>
          <button class="btn btn-sm btn-outline" data-action="copy-id" data-idx="${i}" title="คัดลอก ID" style="font-size:11px;padding:4px 8px;">ID</button>
        </div>
      </div>
    `).join('');

    productList.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const idx = parseInt(btn.dataset.idx);
      const product = products[idx];
      if (!product) return;
      if (btn.dataset.action === 'use') {
        selectProduct(product);
        document.querySelector('[data-tab="post"]')?.click();
        showToast('เลือกสินค้า: ' + (product.name || '').substring(0, 30));
      } else if (btn.dataset.action === 'copy-id') {
        navigator.clipboard.writeText(product.productId).catch(() => {});
        showToast('คัดลอก ID: ' + product.productId);
      }
    });
  }

  async function refreshProducts() {
    const res = await sendMsg('PHIMBOT_GET_PRODUCTS');
    showcaseProducts = res?.products || [];
    renderProductList(showcaseProducts);
  }

  btnFetchShowcaseApi?.addEventListener('click', async () => {
    btnFetchShowcaseApi.disabled = true;
    btnFetchShowcaseApi.innerHTML = '<span class="spinner"></span> กำลังดึงสินค้า...';
    if (scanStatus) { scanStatus.textContent = '⏳ กำลังเรียก TikTok Showcase API...'; scanStatus.classList.remove('hidden'); }

    try {
      const res = await sendMsg('PHIMBOT_FETCH_SHOWCASE_API', { limit: 200, offset: 0 });
      if (res?.success) {
        showcaseProducts = res.products || [];
        renderProductList(showcaseProducts);
        if (scanStatus) { scanStatus.textContent = '✅ ดึงสินค้าสำเร็จ ' + showcaseProducts.length + '/' + (res.total || '?') + ' รายการ'; scanStatus.className = 'status-msg success'; }
        showToast('✅ ดึงสินค้าสำเร็จ ' + showcaseProducts.length + ' รายการ');
      } else {
        if (scanStatus) { scanStatus.textContent = '❌ ' + (res?.error || 'ดึงสินค้าไม่สำเร็จ'); scanStatus.className = 'status-msg error'; }
        showToast('❌ ' + (res?.error || 'ดึงสินค้าไม่สำเร็จ'));
      }
    } catch (err) {
      if (scanStatus) { scanStatus.textContent = '❌ ' + err.message; scanStatus.className = 'status-msg error'; }
    }
    btnFetchShowcaseApi.disabled = false;
    btnFetchShowcaseApi.innerHTML = '🚀 ดึงสินค้า (API)';
  });

  btnClearProducts?.addEventListener('click', async () => {
    showcaseProducts = [];
    await chrome.storage.local.set({ phimbot_products: [] });
    renderProductList([]);
    if (scanStatus) { scanStatus.textContent = ''; scanStatus.classList.add('hidden'); }
    showToast('ล้างรายการสินค้าแล้ว');
  });

  productSearch?.addEventListener('input', () => {
    const q = (productSearch.value || '').trim().toLowerCase();
    if (!q) { renderProductList(showcaseProducts); return; }
    const filtered = showcaseProducts.filter((p) => 
      (p.name || '').toLowerCase().includes(q) || (p.productId || '').includes(q)
    );
    renderProductList(filtered);
  });
\nราคา: ' + formatPrice(p.price) + (p.discount ? ' (ลด ' + p.discount + '%)' : '') + (p.sold ? '