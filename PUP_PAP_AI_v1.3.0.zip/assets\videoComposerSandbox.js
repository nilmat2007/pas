(() => {
  'use strict';

  let ffmpeg = null;
  let corePath = '';
  let activeJobId = '';
  let fetchSequence = 0;
  const pendingInputs = new Map();

  const post = (message, transfer = []) => window.parent.postMessage(message, '*', transfer);

  function requestInput(jobId, index) {
    const requestId = `${jobId}:${index}:${++fetchSequence}`;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        pendingInputs.delete(requestId);
        reject(new Error(`local_composer_input_timeout:${index + 1}`));
      }, 45000);
      pendingInputs.set(requestId, { resolve, reject, timeout });
      post({ type: 'OMNI_COMPOSER_INPUT_REQUEST', jobId, index, requestId });
    });
  }

  async function ensureFFmpeg(jobId) {
    if (ffmpeg?.isLoaded?.()) return ffmpeg;
    if (!globalThis.FFmpeg?.createFFmpeg) throw new Error('ffmpeg_runtime_missing');
    if (!corePath) throw new Error('ffmpeg_core_path_missing');
    ffmpeg = globalThis.FFmpeg.createFFmpeg({
      corePath,
      mainName: 'main',
      log: true,
      progress: ({ ratio }) => {
        const percent = Math.max(0, Math.min(100, Math.round(Number(ratio || 0) * 100)));
        post({ type: 'OMNI_COMPOSER_PROGRESS', jobId, phase: 'encoding', progress: 20 + Math.round(percent * 0.72) });
      },
    });
    post({ type: 'OMNI_COMPOSER_PROGRESS', jobId, phase: 'loading_ffmpeg', progress: 3 });
    await ffmpeg.load();
    return ffmpeg;
  }

  function safeUnlink(ff, name) {
    try { ff.FS('unlink', name); } catch (_) {}
  }

  async function compose(jobId, inputCount, options = {}) {
    if (activeJobId) throw new Error(`local_composer_busy:${activeJobId}`);
    activeJobId = jobId;
    const ff = await ensureFFmpeg(jobId);
    const width = Math.max(360, Math.min(1920, Number(options.width) || 720));
    const height = Math.max(360, Math.min(1920, Number(options.height) || 1280));
    const fps = Math.max(24, Math.min(60, Number(options.fps) || 30));
    const crf = Math.max(18, Math.min(30, Number(options.crf) || 23));
    const inputFiles = [];
    const mode = String(options.mode || 'concat');
    const outputFile = 'omni-storyboard.mp4';

    try {
      for (let index = 0; index < inputCount; index += 1) {
        const inputName = mode === 'caption_overlay' && index > 0
          ? `omni-caption-${index}.png`
          : `omni-input-${index}.mp4`;
        const buffer = await requestInput(jobId, index);
        ff.FS('writeFile', inputName, new Uint8Array(buffer));
        inputFiles.push(inputName);
        post({
          type: 'OMNI_COMPOSER_PROGRESS', jobId, phase: 'normalizing', sceneNumber: index + 1,
          sceneCount: inputCount, progress: 5 + Math.round(((index + 0.2) / inputCount) * 15),
        });
        post({
          type: 'OMNI_COMPOSER_PROGRESS', jobId, phase: 'normalizing', sceneNumber: index + 1,
          sceneCount: inputCount, progress: 5 + Math.round(((index + 1) / inputCount) * 15),
        });
      }

      const inputArgs = mode === 'caption_overlay'
        ? ['-i', inputFiles[0], ...inputFiles.slice(1).flatMap((name) => ['-loop', '1', '-i', name])]
        : inputFiles.flatMap((name) => ['-i', name]);
      const filters = [];
      if (mode === 'caption_overlay') {
        filters.push(`[0:v:0]scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:black,fps=${fps},format=yuv420p,setpts=PTS-STARTPTS[base]`);
        let previous = 'base';
        const ranges = Array.isArray(options.ranges) ? options.ranges : [];
        for (let index = 1; index < inputFiles.length; index += 1) {
          const range = ranges[index - 1] || {};
          const start = Math.max(0, Number(range.start) || 0);
          const end = Math.max(start + 0.1, Number(range.end) || start + 1.6);
          filters.push(`[${index}:v:0]scale=${width}:${height},format=rgba[cap${index}]`);
          const output = index === inputFiles.length - 1 ? 'outv' : `ov${index}`;
          filters.push(`[${previous}][cap${index}]overlay=0:0:enable='between(t\\,${start}\\,${end})'[${output}]`);
          previous = output;
        }
      } else {
        filters.push(...inputFiles.map((_, index) => (
          `[${index}:v:0]scale=${width}:${height}:force_original_aspect_ratio=decrease,`
          + `pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:black,fps=${fps},format=yuv420p,`
          + `setpts=PTS-STARTPTS[v${index}]`
        )));
        filters.push(`${inputFiles.map((_, index) => `[v${index}]`).join('')}concat=n=${inputCount}:v=1:a=0[outv]`);
      }

      // One FFmpeg invocation is deliberate. The single-threaded WASM core
      // exits after main(), so a multi-pass sequence is not reliable in MV3.
      // Audio from scene 1 is retained when available; B-roll remains visual.
      await ff.run(
        ...inputArgs,
        '-filter_complex', filters.join(';'),
        '-map', '[outv]',
        '-map', '0:a:0?',
        '-c:v', 'libx264',
        '-preset', 'ultrafast',
        '-crf', String(crf),
        '-pix_fmt', 'yuv420p',
        '-c:a', 'aac',
        '-b:a', '160k',
        '-movflags', '+faststart',
        ...(mode === 'caption_overlay' ? ['-shortest'] : []),
        outputFile,
      );

      const data = ff.FS('readFile', outputFile);
      const result = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      post({ type: 'OMNI_COMPOSER_COMPLETE', jobId, ok: true, buffer: result, mimeType: 'video/mp4' }, [result]);
    } catch (error) {
      post({ type: 'OMNI_COMPOSER_COMPLETE', jobId, ok: false, reason: String(error?.message || error) });
    } finally {
      [...inputFiles, outputFile]
        .forEach((name) => safeUnlink(ff, name));
      try { ffmpeg?.exit?.(); } catch (_) {}
      ffmpeg = null;
      activeJobId = '';
    }
  }

  window.addEventListener('message', (event) => {
    const message = event.data || {};
    if (message.type === 'OMNI_COMPOSER_INIT') {
      corePath = String(message.corePath || '');
      post({ type: 'OMNI_COMPOSER_READY' });
      return;
    }
    if (message.type === 'OMNI_COMPOSER_INPUT_RESULT') {
      const pending = pendingInputs.get(message.requestId);
      if (!pending) return;
      pendingInputs.delete(message.requestId);
      clearTimeout(pending.timeout);
      if (message.ok && message.buffer instanceof ArrayBuffer) pending.resolve(message.buffer);
      else pending.reject(new Error(message.reason || 'local_composer_input_missing'));
      return;
    }
    if (message.type === 'OMNI_COMPOSER_EXECUTE') {
      compose(String(message.jobId || ''), Number(message.inputCount || 0), message.options || {});
    }
  });
})();
