/**
 * PhimBot — Offscreen Video Composer Bridge
 * Bridges Background Service Worker and Sandboxed FFmpeg WASM iframe
 */
(() => {
  'use strict';

  const composerFrame = document.getElementById('videoComposerSandbox');
  let composerReady = false;
  let initSent = false;
  const activeJobBuffers = new Map();
  let activeJobPromiseHandlers = null;

  function initComposer() {
    if (!composerFrame || !composerFrame.contentWindow) return;
    try {
      const corePath = chrome.runtime.getURL('assets/vendor/ffmpeg/ffmpeg-core.js');
      composerFrame.contentWindow.postMessage({
        type: 'OMNI_COMPOSER_INIT',
        corePath,
      }, '*');
      initSent = true;
      console.log('🚀 [PhimBot Composer Offscreen] Sent OMNI_COMPOSER_INIT with corePath:', corePath);
    } catch (e) {
      console.error('❌ [PhimBot Composer Offscreen] Failed to send OMNI_COMPOSER_INIT:', e);
    }
  }

  if (composerFrame) {
    composerFrame.addEventListener('load', () => {
      initComposer();
    });
    // If iframe already loaded
    setTimeout(() => {
      if (!initSent) initComposer();
    }, 500);
  }

  function bufferToDataUrl(buffer, mimeType = 'video/mp4') {
    return new Promise((resolve, reject) => {
      const blob = new Blob([buffer], { type: mimeType });
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function toArrayBuffer(input) {
    if (input instanceof ArrayBuffer) return input;
    if (typeof input === 'string') {
      if (input.startsWith('data:') || input.startsWith('blob:')) {
        const resp = await fetch(input);
        return await resp.arrayBuffer();
      }
      if (input.startsWith('http:') || input.startsWith('https:')) {
        const resp = await fetch(input, { credentials: 'omit' });
        return await resp.arrayBuffer();
      }
    }
    throw new Error('invalid_video_input_format');
  }

  // Handle messages from sandbox iframe
  window.addEventListener('message', async (event) => {
    if (composerFrame && event.source !== composerFrame.contentWindow) return;
    const message = event.data || {};

    if (message.type === 'OMNI_COMPOSER_READY') {
      composerReady = true;
      console.log('✅ [PhimBot Composer Offscreen] Sandbox reported OMNI_COMPOSER_READY');
      return;
    }

    if (message.type === 'OMNI_COMPOSER_PROGRESS') {
      const { phase, progress, sceneNumber, sceneCount } = message;
      let msg = '';
      if (phase === 'loading_ffmpeg') {
        msg = '⚡ กำลังโหลดระบบตัดต่อ FFmpeg Engine...';
      } else if (phase === 'normalizing') {
        msg = `🎞️ กำลังปรับสัดส่วนวิดีโอฉาก ${sceneNumber || 1}/${sceneCount || '?'}`;
      } else if (phase === 'encoding') {
        msg = `🎬 กำลังรวมคลิปและเรนเดอร์วิดีโอ (${progress || 0}%)`;
      }
      if (msg) {
        chrome.runtime.sendMessage({
          type: 'PHIMBOT_FACTORY_STATUS',
          payload: { status: 'progress', message: msg }
        }).catch(() => {});
      }
      return;
    }

    if (message.type === 'OMNI_COMPOSER_INPUT_REQUEST') {
      const { jobId, index, requestId } = message;
      const buffers = activeJobBuffers.get(jobId);
      if (buffers && buffers[index]) {
        // Slice a copy to transfer safely
        const slice = buffers[index].slice(0);
        composerFrame.contentWindow.postMessage({
          type: 'OMNI_COMPOSER_INPUT_RESULT',
          requestId,
          ok: true,
          buffer: slice
        }, '*', [slice]);
      } else {
        composerFrame.contentWindow.postMessage({
          type: 'OMNI_COMPOSER_INPUT_RESULT',
          requestId,
          ok: false,
          reason: `buffer_missing_for_index_${index}`
        }, '*');
      }
      return;
    }

    if (message.type === 'OMNI_COMPOSER_COMPLETE') {
      const { jobId, ok, buffer, mimeType, reason } = message;
      console.log('📦 [PhimBot Composer Offscreen] Received OMNI_COMPOSER_COMPLETE:', { jobId, ok, reason });
      if (activeJobPromiseHandlers && activeJobPromiseHandlers.jobId === jobId) {
        const { resolve, reject } = activeJobPromiseHandlers;
        activeJobPromiseHandlers = null;
        activeJobBuffers.delete(jobId);

        if (ok && buffer instanceof ArrayBuffer) {
          try {
            const dataUrl = await bufferToDataUrl(buffer, mimeType || 'video/mp4');
            resolve({ ok: true, dataUrl, mimeType: mimeType || 'video/mp4' });
          } catch (convErr) {
            reject(new Error('buffer_conversion_failed: ' + convErr.message));
          }
        } else {
          reject(new Error(reason || 'composition_failed'));
        }
      }
      return;
    }
  });

  // Handle messages from background service worker
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.action === 'PHIMBOT_COMPOSER_PING') {
      sendResponse({ ok: true, composerReady });
      return false;
    }

    if (message?.action === 'PHIMBOT_COMPOSE_VIDEOS') {
      (async () => {
        const jobId = message.jobId || `job_${Date.now()}`;
        const videoSources = message.videos || [];
        const options = {
          width: 720,
          height: 1280,
          fps: 30,
          crf: 23,
          mode: 'concat',
          ...(message.options || {})
        };

        if (!videoSources.length) {
          sendResponse({ ok: false, reason: 'no_videos_provided' });
          return;
        }

        console.log(`🎬 [PhimBot Composer Offscreen] Starting compose for jobId=${jobId}, inputCount=${videoSources.length}`);

        // Wait for composer to be ready (up to 30s)
        if (!composerReady) {
          initComposer();
          await new Promise((res, rej) => {
            const start = Date.now();
            const interval = setInterval(() => {
              if (composerReady) {
                clearInterval(interval);
                res();
              } else if (Date.now() - start > 35000) {
                clearInterval(interval);
                rej(new Error('composer_sandbox_init_timeout'));
              }
            }, 300);
          });
        }

        // Convert video inputs to ArrayBuffers
        const buffers = [];
        for (let i = 0; i < videoSources.length; i++) {
          const buf = await toArrayBuffer(videoSources[i]);
          buffers.push(buf);
        }

        activeJobBuffers.set(jobId, buffers);

        const result = await new Promise((resolve, reject) => {
          activeJobPromiseHandlers = { resolve, reject, jobId };
          composerFrame.contentWindow.postMessage({
            type: 'OMNI_COMPOSER_EXECUTE',
            jobId,
            inputCount: buffers.length,
            options
          }, '*');
        });

        sendResponse(result);
      })().catch(err => {
        activeJobPromiseHandlers = null;
        console.error('❌ [PhimBot Composer Offscreen] Error in compose:', err);
        sendResponse({ ok: false, reason: err?.message || String(err) });
      });

      return true; // Keep message channel open for async sendResponse
    }

    return false;
  });

})();
