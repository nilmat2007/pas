/**
 * PhimBot AI Helper — OpenRouter Integration
 * Handles AI-powered caption generation, hashtag suggestions, and content improvement
 */
window.PhimAI = (function () {
  'use strict';

  const API_URL = 'https://openrouter.ai/api/v1/chat/completions';
  const TIMEOUT_MS = 30000;

  const POPULAR_MODELS = Object.freeze([
    { id: 'google/gemini-2.5-flash', name: 'Gemini 2.5 Flash (Fast & Cheap)' },
    { id: 'google/gemini-2.5-pro', name: 'Gemini 2.5 Pro' },
    { id: 'anthropic/claude-sonnet-4', name: 'Claude Sonnet 4' },
    { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini (Fast & Cheap)' },
    { id: 'openai/gpt-4o', name: 'GPT-4o' },
    { id: 'meta-llama/llama-3.1-8b-instruct', name: 'Llama 3.1 8B (Free)' },
  ]);

  /* ------------------------------------------------------------------ */
  /*  Config                                                            */
  /* ------------------------------------------------------------------ */

  async function getConfig() {
    const data = await chrome.storage.local.get(['openrouter_api_key', 'openrouter_model']);
    return {
      apiKey: data.openrouter_api_key || '',
      model: data.openrouter_model || 'google/gemini-2.5-flash',
    };
  }

  /* ------------------------------------------------------------------ */
  /*  Core API Call                                                     */
  /* ------------------------------------------------------------------ */

  async function callAPI(messages, options = {}) {
    const config = await getConfig();
    if (!config.apiKey) {
      throw new Error(_t('aiErrorNoKey', 'กรุณาใส่ OpenRouter API Key ในหน้าตั้งค่าก่อน'));
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), options.timeout || TIMEOUT_MS);

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.apiKey}`,
          'HTTP-Referer': 'chrome-extension://phimbot',
          'X-Title': 'PhimBot',
        },
        body: JSON.stringify({
          model: options.model || config.model,
          messages,
          max_tokens: options.maxTokens || 1024,
          temperature: options.temperature ?? 0.7,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errorBody = await response.text().catch(() => '');
        throw _mapHttpError(response.status, errorBody);
      }

      const json = await response.json();
      const text = json?.choices?.[0]?.message?.content;
      if (!text) {
        throw new Error(_t('aiErrorEmpty', 'AI ไม่ส่งข้อความกลับมา กรุณาลองใหม่'));
      }
      return text.trim();
    } catch (error) {
      if (error.name === 'AbortError') {
        throw new Error(_t('aiErrorTimeout', 'หมดเวลารอ AI ตอบกลับ (30 วินาที) กรุณาลองใหม่'));
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Generate Caption                                                  */
  /* ------------------------------------------------------------------ */

  async function generateCaption(productInfo) {
    const { name, description, price, category } = productInfo || {};

    const userContent = [
      name ? `ชื่อสินค้า: ${name}` : '',
      description ? `คำอธิบาย: ${description}` : '',
      price ? `ราคา: ${price}` : '',
      category ? `หมวดหมู่: ${category}` : '',
    ].filter(Boolean).join('\n');

    if (!userContent) {
      throw new Error(_t('aiErrorNoProduct', 'กรุณากรอกข้อมูลสินค้าก่อนสร้างแคปชั่น'));
    }

    return callAPI([
      {
        role: 'system',
        content:
          'คุณเป็นนักสร้างคอนเทนต์ TikTok มืออาชีพ สร้างแคปชั่นสั้นๆ กระชับ ดึงดูดใจ สำหรับขายสินค้า\n'
          + 'กฎ:\n'
          + '- ความยาวไม่เกิน 300 ตัวอักษร\n'
          + '- ใส่ emoji ให้น่าสนใจ\n'
          + '- ใช้ภาษาที่เข้าถึงง่าย โน้มน้าวใจ\n'
          + '- อย่าใส่แฮชแท็ก (จะเพิ่มทีหลัง)\n'
          + '- ตอบเฉพาะแคปชั่นเท่านั้น ไม่ต้องอธิบายเพิ่ม',
      },
      { role: 'user', content: `สร้างแคปชั่น TikTok ให้สินค้านี้:\n\n${userContent}` },
    ], { temperature: 0.8 });
  }

  /* ------------------------------------------------------------------ */
  /*  Suggest Hashtags                                                  */
  /* ------------------------------------------------------------------ */

  async function suggestHashtags(caption, count = 5) {
    if (!caption || !caption.trim()) {
      throw new Error(_t('aiErrorNoCaption', 'กรุณากรอกแคปชั่นก่อนแนะนำแฮชแท็ก'));
    }

    const safeCount = Math.max(1, Math.min(10, count));
    const result = await callAPI([
      {
        role: 'system',
        content:
          `คุณเป็นผู้เชี่ยวชาญ TikTok แนะนำแฮชแท็กยอดนิยมที่เกี่ยวข้องกับเนื้อหา\n`
          + `กฎ:\n`
          + `- แนะนำ ${safeCount} แฮชแท็ก\n`
          + `- ตอบแฮชแท็กบรรทัดละ 1 คำ\n`
          + `- ไม่ต้องใส่เครื่องหมาย #\n`
          + `- ห้ามมีคำอธิบาย ตอบแค่ชื่อแฮชแท็ก\n`
          + `- ผสมทั้งภาษาไทยและอังกฤษ\n`
          + `- เลือกแฮชแท็กที่มีคนใช้เยอะและเกี่ยวข้อง`,
      },
      { role: 'user', content: `แนะนำแฮชแท็ก TikTok สำหรับเนื้อหานี้:\n\n${caption}` },
    ], { temperature: 0.6 });

    return result
      .split('\n')
      .map((line) => line.replace(/^[#\-\d.\s]+/, '').trim())
      .filter((tag) => tag.length > 0 && tag.length <= 50)
      .slice(0, safeCount);
  }

  /* ------------------------------------------------------------------ */
  /*  Improve Content                                                   */
  /* ------------------------------------------------------------------ */

  const STYLE_PROMPTS = {
    engaging:
      'ปรับปรุงข้อความให้น่าสนใจ ดึงดูดใจ ใช้ emoji อย่างเหมาะสม ทำให้อยากอ่านต่อ',
    professional:
      'ปรับปรุงข้อความให้ดูเป็นมืออาชีพ น่าเชื่อถือ ใช้ภาษาสุภาพ เหมาะกับธุรกิจ',
    funny:
      'ปรับปรุงข้อความให้ตลก ขำๆ ใช้มุกที่เข้าใจง่าย ทำให้คนอ่านยิ้มได้',
    urgent:
      'ปรับปรุงข้อความให้เร่งด่วน สร้าง FOMO ทำให้รู้สึกว่าต้องรีบซื้อ ใช้คำว่า "ด่วน" "จำนวนจำกัด" "หมดแล้วหมดเลย"',
  };

  async function improveContent(text, style = 'engaging') {
    if (!text || !text.trim()) {
      throw new Error(_t('aiErrorNoText', 'กรุณากรอกข้อความก่อนปรับปรุง'));
    }

    const stylePrompt = STYLE_PROMPTS[style] || STYLE_PROMPTS.engaging;

    return callAPI([
      {
        role: 'system',
        content:
          `คุณเป็นนักเขียนคอนเทนต์มืออาชีพ\n`
          + `${stylePrompt}\n`
          + `กฎ:\n`
          + `- ความยาวไม่เกิน 300 ตัวอักษร\n`
          + `- ตอบเฉพาะข้อความที่ปรับปรุงแล้วเท่านั้น\n`
          + `- ไม่ต้องอธิบายว่าเปลี่ยนอะไร`,
      },
      { role: 'user', content: `ปรับปรุงข้อความนี้:\n\n${text}` },
    ], { temperature: 0.8 });
  }

  /* ------------------------------------------------------------------ */
  /*  Generate From Template                                            */
  /* ------------------------------------------------------------------ */

  async function generateFromTemplate(template, variables = {}) {
    if (!template || !template.trim()) {
      throw new Error(_t('aiErrorNoTemplate', 'กรุณากรอกเทมเพลตก่อน'));
    }

    let filled = template;
    for (const [key, value] of Object.entries(variables)) {
      filled = filled.replace(new RegExp(`\\{${key}\\}`, 'g'), String(value || ''));
    }

    return callAPI([
      {
        role: 'system',
        content:
          'คุณเป็นผู้ช่วยสร้างเนื้อหา ทำตามคำสั่งที่ได้รับอย่างตรงประเด็น\n'
          + 'ตอบเฉพาะเนื้อหาที่สร้างขึ้น ไม่ต้องอธิบายเพิ่ม',
      },
      { role: 'user', content: filled },
    ], { temperature: 0.7 });
  }

  /* ------------------------------------------------------------------ */
  /*  Internal Helpers                                                  */
  /* ------------------------------------------------------------------ */

  function _t(key, fallback) {
    try {
      if (window.PhimI18n?.t) return window.PhimI18n.t(key) || fallback;
    } catch (_) { /* i18n not loaded yet */ }
    return fallback;
  }

  function _mapHttpError(status, body) {
    const detail = (() => {
      try { return JSON.parse(body)?.error?.message || ''; } catch (_) { return ''; }
    })();

    switch (true) {
      case status === 401:
        return new Error(_t('aiError401', 'API Key ไม่ถูกต้อง กรุณาตรวจสอบในหน้าตั้งค่า'));
      case status === 402:
        return new Error(_t('aiError402', 'เครดิต OpenRouter หมด กรุณาเติมเงิน'));
      case status === 429:
        return new Error(_t('aiError429', 'ส่งคำขอถี่เกินไป กรุณารอสักครู่แล้วลองใหม่'));
      case status >= 500:
        return new Error(_t('aiError500', `เซิร์ฟเวอร์ OpenRouter มีปัญหา (${status}) กรุณาลองใหม่`));
      default:
        return new Error(`OpenRouter Error ${status}: ${detail || 'Unknown error'}`);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Public API                                                        */
  /* ------------------------------------------------------------------ */

  return Object.freeze({
    getConfig,
    callAPI,
    generateCaption,
    suggestHashtags,
    improveContent,
    generateFromTemplate,
    POPULAR_MODELS,
  });
})();
