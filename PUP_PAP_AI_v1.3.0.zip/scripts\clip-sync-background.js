// ============================================================
// clip-sync-background.js — ☁️ Cloud Sync (Service Worker): อัปโหลดคลิปขึ้น Supabase Relay
// รับ ASU_UPLOAD_CLIP_TO_RELAY → แปลงเป็นไบต์ → create → signed PUT → commit
// รองรับทั้ง Supabase โปรเจกต์เดิม และ Custom Supabase โปรเจกต์ใหม่ของผู้ใช้
// ============================================================
(function () {
  'use strict';

  const DEFAULT_SYNC_URL = 'https://guhdweujxgsbflkvgryb.supabase.co';
  const DEFAULT_SYNC_ANON = 'sb_publishable_Jk_pcsCymh1jJrmnBMJUhw_H_UqTpTx';
  const DEFAULT_SYNC_SECRET = 'sb_secret_k3Drdrjof8D9uI2NrJfiHA__g0NQ-MG';
  const SYNC_SETTINGS_KEY = 'asu-clip-sync-settings';
  const SYNC_LOG_KEY = 'asu-clip-sync-log';
  const MAX_SYNC_BYTES = 209715200; // 200MB

  async function getRelayCredentials(data) {
    let url = data && data.supabaseUrl ? String(data.supabaseUrl).trim() : '';
    let anon = data && data.supabaseAnonKey ? String(data.supabaseAnonKey).trim() : '';
    let secret = data && data.supabaseSecretKey ? String(data.supabaseSecretKey).trim() : '';

    if (!url || !anon) {
      try {
        const stored = await chrome.storage.local.get(SYNC_SETTINGS_KEY);
        const s = stored && stored[SYNC_SETTINGS_KEY];
        if (s) {
          if (!url && s.supabaseUrl) url = String(s.supabaseUrl).trim();
          if (!anon && s.supabaseAnonKey) anon = String(s.supabaseAnonKey).trim();
          if (!secret && s.supabaseSecretKey) secret = String(s.supabaseSecretKey).trim();
        }
      } catch (_) {}
    }

    if (!url || url.includes('guhdweujxgsbflkvgryb')) url = DEFAULT_SYNC_URL;
    if (!anon || anon.includes('Jk_pcsCymh1jJrmnBMJUhw')) anon = DEFAULT_SYNC_ANON;
    if (!secret) secret = DEFAULT_SYNC_SECRET;
    url = url.replace(/\/+$/, '');
    return {
      syncUrl: url,
      syncAnon: anon,
      syncSecret: secret,
      syncApi: url + '/functions/v1'
    };
  }

  async function syncUpdateLog(clientRef, patch) {
    let videoName = '';
    try {
      const stored = await chrome.storage.local.get(SYNC_LOG_KEY);
      const list = Array.isArray(stored && stored[SYNC_LOG_KEY]) ? stored[SYNC_LOG_KEY] : [];
      const idx = list.findIndex((e) => e && e.clientRef === clientRef);
      if (idx >= 0) {
        list[idx] = Object.assign({}, list[idx], patch);
        videoName = list[idx].videoName || '';
      }
      await chrome.storage.local.set({ [SYNC_LOG_KEY]: list.slice(0, 20) });
    } catch (_) {}

    // แจ้งผลจริง create→PUT→commit กลับไปที่ sidepanel/หน้า UI
    if (patch && (patch.status === 'sent' || patch.status === 'upload_failed')) {
      try {
        chrome.runtime.sendMessage({
          type: 'ASU_CLIP_SYNC_RESULT',
          clientRef: clientRef,
          videoName: videoName,
          status: patch.status,
          error: patch.error || ''
        }, () => { void chrome.runtime.lastError; });
      } catch (_) {}
    }
  }

  async function syncCallEdge(apiBase, anonKey, fn, body, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs || 30000);
    try {
      const res = await fetch(apiBase + '/' + fn, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': anonKey,
          'Authorization': 'Bearer ' + anonKey
        },
        body: JSON.stringify(body || {}),
        signal: controller.signal
      });
      const json = await res.json().catch(() => ({}));
      return json && typeof json === 'object' ? json : { ok: false, error: 'bad_response' };
    } finally {
      clearTimeout(timer);
    }
  }

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (!message || message.type !== 'ASU_UPLOAD_CLIP_TO_RELAY') return;

    (async () => {
      const data = message.data || {};
      const { syncUrl, syncAnon, syncApi } = await getRelayCredentials(data);

      // lazy init queue chain + sweep งานค้าง
      if (!self.__asuClipSync) {
        self.__asuClipSync = { chain: Promise.resolve() };
        try {
          const stored = await chrome.storage.local.get(SYNC_LOG_KEY);
          const list = Array.isArray(stored && stored[SYNC_LOG_KEY]) ? stored[SYNC_LOG_KEY] : [];
          let changed = false;
          for (const e of list) {
            if (e && e.status === 'uploading' && Date.now() - (e.at || 0) > 600000) {
              e.status = 'upload_failed';
              e.error = 'อัปโหลดถูกตัดกลางคัน (Service worker รีเซ็ต)';
              changed = true;
            }
          }
          if (changed) await chrome.storage.local.set({ [SYNC_LOG_KEY]: list });
        } catch (_) {}
      }

      try {
        // 1) อ่านข้อมูลไบต์วิดีโอ (รองรับทั้ง direct base64, dataUrl, storageUrl, storageKey)
        let bytes = null;
        let base64 = '';

        if (data.videoBase64 || data.dataUrl) {
          const raw = data.videoBase64 || data.dataUrl;
          if (typeof raw === 'string' && raw.indexOf('data:') === 0) {
            base64 = raw.slice(raw.indexOf(',') + 1);
          } else if (typeof raw === 'string') {
            base64 = raw;
          }
        } else if (data.storageUrl) {
          const storageUrl = String(data.storageUrl || '');
          if (storageUrl.indexOf('storage:') === 0) {
            const storageKey = storageUrl.slice(8);
            const stored = await chrome.storage.local.get(storageKey);
            const payload = stored && stored[storageKey];
            if (typeof payload === 'string' && payload.indexOf('data:') === 0) {
              base64 = payload.slice(payload.indexOf(',') + 1);
            } else if (payload && payload.base64) {
              base64 = payload.base64;
            }
          }
        } else if (data.storageKey) {
          const stored = await chrome.storage.local.get(data.storageKey);
          const payload = stored && stored[data.storageKey];
          if (typeof payload === 'string' && payload.indexOf('data:') === 0) {
            base64 = payload.slice(payload.indexOf(',') + 1);
          } else if (payload && payload.base64) {
            base64 = payload.base64;
          }
        }

        if (!base64) {
          sendResponse({ success: false, error: 'ไม่พบไฟล์วิดีโอ (clip data not found)' });
          return;
        }

        const bin = atob(base64);
        bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);

        if (bytes.length > MAX_SYNC_BYTES) {
          sendResponse({ success: false, error: 'คลิปใหญ่เกิน 200MB — ข้ามการส่งเข้ามือถือ' });
          return;
        }

        // 2) ตอบกลับ UI ทันทีว่าอ่านไบต์เสร็จเรียบร้อยแล้ว
        sendResponse({ success: true, captured: true, sizeBytes: bytes.length });

        // 3) บันทึก Log งานเริ่มต้น
        const entry = {
          clientRef: data.clientRef,
          videoName: data.videoName || '',
          sourceMode: data.sourceMode || '',
          status: 'uploading',
          at: Date.now()
        };
        try {
          const logStored = await chrome.storage.local.get(SYNC_LOG_KEY);
          const list = Array.isArray(logStored && logStored[SYNC_LOG_KEY]) ? logStored[SYNC_LOG_KEY] : [];
          list.unshift(entry);
          await chrome.storage.local.set({ [SYNC_LOG_KEY]: list.slice(0, 20) });
        } catch (_) {}

        // 4) เข้าคิวอัปโหลดทีละงาน (ป้องกันหน่วยความจำล้น)
        self.__asuClipSync.chain = self.__asuClipSync.chain.then(async () => {
          const autoStartVal = (data.meta && typeof data.meta.autoStart === 'boolean') ? data.meta.autoStart : true;
          const res = await doDirectCloudUpload({
            data,
            bytes,
            pairCode: data.pairCode,
            autoStart: autoStartVal,
            syncUrl,
            syncAnon,
            syncSecret: DEFAULT_SYNC_SECRET,
            clientRef: data.clientRef,
            videoName: data.videoName || ('clip_' + Date.now() + '.mp4')
          });
          if (!res.ok) {
            await syncUpdateLog(data.clientRef, { status: 'upload_failed', error: res.error });
          }
        }).catch(async (err) => {
          await syncUpdateLog(data.clientRef, { status: 'upload_failed', error: err && err.message || String(err) });
        });
      } catch (err) {
        try { sendResponse({ success: false, error: err && err.message || String(err) }); } catch (_) {}
      }
    })();

    return true; // Keep message channel open for async response
  });

  async function doDirectCloudUpload(opts) {
    const { data, bytes, pairCode, autoStart, syncUrl, syncAnon, syncSecret, clientRef, videoName } = opts;
    const safePair = encodeURIComponent(String(pairCode || '').trim());
    if (!safePair) {
      return { ok: false, error: 'รหัสจับคู่ไม่ถูกต้อง (ว่างเปล่า)' };
    }

    const safeJobId = 'job_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    const extMatch = String(videoName || '').match(/\.[a-zA-Z0-9]+$/);
    const ext = extMatch ? extMatch[0] : '.mp4';
    const objectPath = `${safePair}/${safeJobId}${ext}`;
    const storageUploadUrl = `${syncUrl}/storage/v1/object/clips/${objectPath}`;
    const publicDownloadUrl = `${syncUrl}/storage/v1/object/public/clips/${objectPath}`;

    // 1. Upload to Supabase Storage directly via POST
    try {
      const uploadRes = await fetch(storageUploadUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'video/mp4',
          'apikey': syncAnon,
          'Authorization': 'Bearer ' + syncAnon
        },
        body: bytes
      });

      if (!uploadRes.ok) {
        const errTxt = await uploadRes.text().catch(() => '');
        return { ok: false, error: 'อัปโหลดวิดีโอเข้า Storage ไม่สำเร็จ: HTTP ' + uploadRes.status + ' ' + errTxt };
      }
    } catch (netErr) {
      return { ok: false, error: 'เน็ตหลุดระหว่างอัปโหลดวิดีโอ: ' + (netErr && netErr.message || String(netErr)) };
    }

    // 2. Insert record into clip_jobs via PostgREST
    try {
      const restJobsUrl = `${syncUrl}/rest/v1/clip_jobs`;
      const jobPayload = {
        pair_code: String(pairCode).trim(),
        video_name: videoName,
        status: 'ready',
        meta: {
          jobId: safeJobId,
          downloadUrl: publicDownloadUrl,
          sizeBytes: bytes.length,
          sourceMode: (data && data.sourceMode) || 'shopee',
          productTitle: (data && data.productTitle) || '',
          productUrl: (data && data.productUrl) || '',
          caption: (data && data.caption) || '',
          hashtags: (data && data.hashtags) || '',
          autoStart: autoStart !== false
        }
      };

      const insertRes = await fetch(restJobsUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': syncAnon,
          'Authorization': 'Bearer ' + syncAnon,
          'Prefer': 'return=representation'
        },
        body: JSON.stringify(jobPayload)
      });

      if (!insertRes.ok) {
        const errTxt = await insertRes.text().catch(() => '');
        return { ok: false, error: 'สร้างงานบนคลาวด์ไม่สำเร็จ: HTTP ' + insertRes.status + ' ' + errTxt };
      }
    } catch (netErr2) {
      return { ok: false, error: 'บันทึกงานเข้าฐานข้อมูลไม่สำเร็จ: ' + (netErr2 && netErr2.message || String(netErr2)) };
    }

    await syncUpdateLog(clientRef, { status: 'sent', jobId: safeJobId, videoName });
    return { ok: true, jobId: safeJobId };
  }

  self.uploadToRelay = async function (data) {
    if (!data) return { ok: false, error: 'no_data' };
    const { syncUrl, syncAnon, syncSecret } = await getRelayCredentials(data);
    const stored = await chrome.storage.local.get(SYNC_SETTINGS_KEY);
    const settings = (stored && stored[SYNC_SETTINGS_KEY]) || {};
    const pairCode = (data && data.pairCode) || (settings && settings.pairCode);
    if (!pairCode) {
      return { ok: false, error: 'ยังไม่ได้ตั้งค่ารหัสจับคู่ Cloud Sync (กรุณากรอกในแท็บ "ตั้งค่า")' };
    }
    const autoStart = (data && typeof data.autoStart === 'boolean') ? data.autoStart : (settings && settings.autoStart !== false);

    let base64 = '';
    const raw = data.videoDataUrl || data.videoBase64 || data.dataUrl;
    if (typeof raw === 'string' && raw.indexOf('data:') === 0) {
      base64 = raw.slice(raw.indexOf(',') + 1);
    } else if (typeof raw === 'string') {
      base64 = raw;
    }

    if (!base64) return { ok: false, error: 'ไม่พบไฟล์วิดีโอ (No video data)' };
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);

    if (bytes.length > MAX_SYNC_BYTES) {
      return { ok: false, error: 'ไฟล์วิดีโอใหญ่เกิน 200MB' };
    }

    const clientRef = data.clientRef || ('shopee_' + Date.now());
    const videoName = data.videoName || ('shopee_' + Date.now() + '.mp4');

    return await doDirectCloudUpload({
      data,
      bytes,
      pairCode,
      autoStart,
      syncUrl,
      syncAnon,
      syncSecret,
      clientRef,
      videoName
    });
  };
})();
