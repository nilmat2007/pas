/**
 * PhimBot — Google Flow Automator (v4 - OmniPost Hub Engine)
 * Powered by OmniPost Hub v1.2.7 battle-tested automation modules.
 * Runs in ISOLATED world and communicates with MAIN world bridge via CustomEvents.
 */

(function initPhimBotFlowAutomator() {
  if (window.__PHIMBOT_FLOW_AUTOMATOR_LOADED__) return;
  window.__PHIMBOT_FLOW_AUTOMATOR_LOADED__ = true;

  console.log('[PhimBot] Google Flow Automator v4 (OmniPost Engine) loaded on:', location.href);

  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  function emit(type, message) {
    const time = new Date().toLocaleTimeString('th-TH');
    console.log(`[Flow ${time}] [${type}] ${message}`);
    try {
      chrome.runtime.sendMessage({
        type: 'PHIMBOT_FLOW_PROGRESS',
        payload: { step: type, message: `[${time}] ${message}` }
      });
    } catch (_) {}
  }

  // RPC to MAIN world bridge (flow-bridge-main.js)
  function callMain(action, payload = {}) {
    return new Promise((resolve, reject) => {
      const id = Date.now() + '_' + Math.random().toString(36).slice(2);
      const timeout = setTimeout(() => {
        window.removeEventListener('PHIMBOT_FLOW_MAIN_RESP_' + id, handler);
        reject(new Error(`callMain_timeout:${action}`));
      }, 120000);

      const handler = (e) => {
        clearTimeout(timeout);
        window.removeEventListener('PHIMBOT_FLOW_MAIN_RESP_' + id, handler);
        if (e.detail?.ok) {
          resolve(e.detail.data);
        } else {
          reject(new Error(e.detail?.error || `${action}_failed`));
        }
      };

      window.addEventListener('PHIMBOT_FLOW_MAIN_RESP_' + id, handler);
      window.dispatchEvent(new CustomEvent('PHIMBOT_FLOW_MAIN_EXEC', {
        detail: { id, action, payload }
      }));
    });
  }

  // Convert image URL to Data URL
  async function urlToDataUrl(url) {
    const resp = await fetch(url);
    const blob = await resp.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  /* ─── Step 1: Ensure Project ─── */
  async function ensureProject() {
    emit('project', 'รอ Google Flow โหลด...');
    await wait(2000);

    // Dismiss welcome popups
    for (const label of ['Get started', 'เริ่มต้น', 'close', 'ปิด', 'Got it', 'เข้าใจแล้ว', 'Dismiss', 'OK', 'Agree', 'ยอมรับ']) {
      const btns = Array.from(document.querySelectorAll('button')).filter(b => b.getBoundingClientRect().width > 0);
      const popup = btns.find(b => (b.textContent || '').trim().toLowerCase().includes(label.toLowerCase()));
      if (popup) { popup.click(); await wait(800); }
    }

    emit('project', 'ตรวจเช็ค Workspace...');
    try {
      await callMain('ENSURE_PROJECT');
      emit('project', '✓ Workspace พร้อมทำงาน');
    } catch (e) {
      emit('warn', `ตรวจโปรเจกต์: ${e.message} — ดำเนินการต่อ`);
    }
    await wait(2000);
  }

  /* ─── Step 2: Upload Reference Images ─── */
  async function prepareAndUploadReferences(productImages, charImages) {
    const references = [];

    // 1. Download product photos
    if (productImages && productImages.length > 0) {
      emit('upload', `📷 ดาวน์โหลดรูปสินค้า ${Math.min(productImages.length, 2)} รูป...`);
      for (let i = 0; i < Math.min(productImages.length, 2); i++) {
        try {
          const dataUrl = await urlToDataUrl(productImages[i]);
          references.push({ dataUrl, name: `product_${i + 1}.png` });
        } catch (e) {
          emit('warn', `ดาวน์โหลดรูปสินค้า ${i + 1} ล้มเหลว`);
        }
      }
    }

    // 2. Character model images
    if (charImages && charImages.length > 0) {
      emit('upload', `📷 เตรียมรูปตัวละคร ${Math.min(charImages.length, 1)} รูป...`);
      for (let i = 0; i < Math.min(charImages.length, 1); i++) {
        references.push({ dataUrl: charImages[i], name: `model_${i + 1}.png` });
      }
    }

    if (references.length === 0) {
      emit('info', 'ℹ️ ไม่มีรูปอ้างอิง — สร้างด้วย Prompt ข้อความล้วน');
      return;
    }

    emit('upload', `📷 แนบภาพอ้างอิง ${references.length} ภาพเข้า Prompt (OmniPost Engine)...`);
    try {
      const result = await callMain('ATTACH_REFERENCES', { references });
      emit('upload', `✅ แนบภาพอ้างอิงสำเร็จ (${result?.attachedReferenceCount || references.length} ภาพ)`);
    } catch (err) {
      emit('warn', `แนบภาพอ้างอิง: ${err.message} — ดำเนินการต่อ`);
    }
    await wait(2000);
  }

  /* ─── Step 3: Monitor Progress & Extract Result ─── */
  async function monitorAndExtract(kind, minWaitSec = 10, maxWaitSec = 300) {
    const start = Date.now();
    let lastLog = '';

    while ((Date.now() - start) / 1000 < maxWaitSec) {
      await wait(2000);
      const elapsed = Math.round((Date.now() - start) / 1000);

      // 1. Query progress from MAIN world bridge
      let currentProgress = '';
      try {
        const prog = await callMain('GET_PROGRESS');
        currentProgress = prog?.progress || '';
      } catch (_) {}

      // Fallback: check DOM text for %
      if (!currentProgress) {
        const matches = document.body.innerText.match(/(\d{1,3})\s*%/);
        if (matches) currentProgress = matches[1] + '%';
      }

      if (currentProgress && currentProgress !== lastLog) {
        lastLog = currentProgress;
        emit('poll', `${kind}: ${currentProgress} (${elapsed}s)`);
      }

      // Check if finished (100% or media ready)
      if (elapsed >= minWaitSec) {
        // Try export via flowMediaInterceptor in MAIN world
        try {
          const items = await callMain('EXPORT_MEDIA', { kind, limit: 1 });
          if (items && items.length > 0 && items[0].dataUrl) {
            emit('poll', `✅ ${kind} สำเร็จ! (${elapsed}s)`);
            return {
              dataUrl: items[0].dataUrl,
              url: items[0].url || '',
              success: true
            };
          }
        } catch (_) {}

        // Fallback: DOM query
        if (kind === 'video') {
          const video = document.querySelector('video');
          if (video && (video.currentSrc || video.src)) {
            emit('poll', `✅ ${kind} สำเร็จ (DOM)! (${elapsed}s)`);
            return {
              dataUrl: '',
              url: video.currentSrc || video.src,
              success: true
            };
          }
        } else {
          // For image, check if progress reached 100% and settled
          if (currentProgress === '100%' && elapsed >= 20) {
            emit('poll', `✅ ${kind} เสร็จสิ้น 100%! (${elapsed}s)`);
            return { dataUrl: '', url: '', success: true };
          }
        }
      }
    }

    emit('warn', `⚠️ ${kind} หมดเวลารอ (${maxWaitSec}s)`);
    return { dataUrl: '', url: '', success: false };
  }

  /* ─── Main Pipeline ─── */
  async function runFullPipeline(config) {
    const { scenes, imageModel, videoModel, duration, mode, productName, productImages, charImages } = config;
    const results = [];

    emit('pipeline', `🎬 เริ่มผลิต "${productName}" (${scenes.length} ฉาก) — OmniPost Engine`);

    // 1. New Project / Canvas
    await ensureProject();

    // 2. Per-scene: Image → Video
    for (let i = 0; i < scenes.length; i++) {
      const scene = scenes[i];
      emit('scene', `🎬 ฉาก ${i + 1}/${scenes.length}`);

      try {
        // ── 2A. Create Image ──
        emit('scene', `[${i + 1}] 🖼️ สลับโหมด Image...`);
        try {
          await callMain('ENSURE_IMAGE_MODE');
        } catch (me) {
          emit('warn', `Image mode: ${me.message}`);
        }
        await wait(1000);

        // Upload reference images on Scene 1
        if (i === 0) {
          await prepareAndUploadReferences(productImages, charImages);
        }

        // Fill Image Prompt
        emit('prompt', `[${i + 1}] 📝 พิมพ์ Prompt รูปภาพ...`);
        const imagePrompt = buildImagePrompt(scene, mode);
        await callMain('FILL_PROMPT', { text: imagePrompt });
        await wait(1000);

        // Generate Image
        emit('generate', `[${i + 1}] 🚀 เริ่มสร้างรูปภาพ...`);
        await callMain('CLICK_GENERATE');
        await wait(3000);

        // Wait for image generation
        emit('poll', `[${i + 1}] ⏳ รอรูปภาพสร้างเสร็จ...`);
        const imageRes = await monitorAndExtract('image', 10, 150);
        await wait(2000);

        // ── 2B. Create Video from Image ──
        emit('scene', `[${i + 1}] 🎥 สลับโหมด Video Frames...`);
        try {
          await callMain('ENSURE_VIDEO_SETTINGS', {
            videoModel: videoModel || 'Veo 3.1 - Lite',
            duration: duration || 8,
            aspect: '9:16'
          });
        } catch (ve) {
          emit('warn', `Video settings: ${ve.message}`);
        }
        await wait(1500);

        // Attach the freshly generated image as Start Frame
        emit('frame', `[${i + 1}] 🖼️ นำรูปที่เพิ่งสร้างมาเป็น Start Frame...`);
        try {
          await callMain('ATTACH_START_FRAME');
          emit('frame', `✓ Start Frame พร้อม`);
        } catch (fe) {
          emit('warn', `Start Frame: ${fe.message} (สร้างต่อ)`);
        }
        await wait(1000);

        // Fill Video Prompt
        emit('prompt', `[${i + 1}] 📝 พิมพ์ Prompt วิดีโอ...`);
        const videoPrompt = buildVideoPrompt(scene, mode);
        await callMain('FILL_PROMPT', { text: videoPrompt });
        await wait(1000);

        // Generate Video
        emit('generate', `[${i + 1}] 🚀 เริ่มสร้างวิดีโอ...`);
        await callMain('CLICK_GENERATE');
        await wait(3000);

        // Wait for video generation
        emit('poll', `[${i + 1}] ⏳ รอวิดีโอประมวลผล...`);
        const videoRes = await monitorAndExtract('video', 15, 300);

        results.push({
          sceneIdx: i,
          beat: scene.beat || `ฉาก ${i + 1}`,
          videoBase64: videoRes.dataUrl || '',
          videoUrl: videoRes.url || '',
          success: videoRes.success
        });

        emit('scene', `✅ ฉาก ${i + 1} เสร็จสิ้น!`);
      } catch (err) {
        emit('scene', `❌ ฉาก ${i + 1}: ${err.message}`);
        results.push({ sceneIdx: i, beat: scene.beat, success: false, error: err.message });
      }

      if (i < scenes.length - 1) {
        emit('wait', 'รอ 5 วินาทีก่อนเริ่มฉากถัดไป...');
        await wait(5000);
      }
    }

    emit('pipeline', `🎬 ผลิตเสร็จ ${results.filter(r => r.success).length}/${scenes.length} ฉาก`);
    return results;
  }

  /* ─── Prompt Builders ─── */
  function buildImagePrompt(scene, mode) {
    let prompt = 'สร้างภาพถ่ายเดี่ยวรูปเดียวเต็มกรอบภาพ ห้ามแบ่งช่อง ห้ามทำตารางกริด (single shot full-frame photograph, strictly one continuous scene, no collage, no split screen). ';
    if (scene.visual) prompt += scene.visual + '. ';
    if (scene.setting) prompt += `Setting: ${scene.setting}. `;
    if (mode === 'hands') {
      prompt += 'Close-up hands naturally interacting with or holding the product according to the uploaded reference photos, realistic contact shadows. ';
    } else {
      prompt += 'Thai influencer naturally holding and presenting the product according to the uploaded reference photos, clean authentic product packaging, realistic label print. ';
    }
    prompt += 'Both character and product clearly visible, natural indoor lighting, 9:16 vertical format, authentic smartphone camera UGC style. NO text overlays, NO watermarks.';
    return prompt;
  }

  function buildVideoPrompt(scene, mode) {
    let prompt = '';
    if (scene.voiceover) {
      prompt += `[SPOKEN AUDIO: THAI LANGUAGE ONLY] ผู้พูดรีวิวสินค้า ปากขยับตรงกับเสียงพูด บทพูดไทย: "${scene.voiceover}"\n\n`;
    }
    prompt += 'Seamlessly continue from the Start Frame with a static camera. ';
    if (scene.visual) prompt += scene.visual + ' ';
    prompt += 'NO text overlays, NO subtitles. All spoken audio must be Thai only. ';
    prompt += 'Natural movements, professional lighting, 9:16 vertical format.';
    return prompt;
  }

  /* ─── Chrome Message Listener ─── */
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.action === 'PHIMBOT_PING' || msg?.action === 'PHIMBOT_FLOW_CHECK_LOGIN') {
      const loggedIn = !!document.querySelector('img[aria-label*="Google" i], img[alt*="profile" i], img[alt*="avatar" i], [aria-label*="Account" i], [aria-label*="บัญชี" i]');
      sendResponse({ status: 'ready', loggedIn, url: location.href, engine: 'omnipost_v4' });
      return true;
    }

    if (msg?.action === 'PHIMBOT_FLOW_GENERATE') {
      sendResponse({ started: true });
      runFullPipeline(msg.payload)
        .then(results => {
          chrome.runtime.sendMessage({
            type: 'PHIMBOT_FLOW_RESULTS',
            payload: { productId: msg.payload.productId, results }
          });
        })
        .catch(err => {
          emit('error', `Pipeline Error: ${err.message}`);
          chrome.runtime.sendMessage({
            type: 'PHIMBOT_FLOW_ERROR',
            payload: { productId: msg.payload.productId, error: err.message }
          });
        });
      return true;
    }
  });

  // Listen for EXT_EXPORT_VIDEO from Flow Tool frame
  window.addEventListener('message', async (event) => {
    if (event.data && (event.data.type === 'EXT_EXPORT_VIDEO' || event.data.type === 'PHIMBOT_IMPORT_FLOW_VIDEO')) {
      const payload = event.data.payload || event.data.data;
      if (!payload) return;
      console.log('[PhimBot] 📥 Received video export from Google Flow Tool:', payload);
      try {
        // Handle raw base64 (Tool ส่งมาไม่มี prefix) → เพิ่ม data URL prefix ให้
        let videoBase64 = payload.videoBase64 || payload.dataUrl || '';
        if (videoBase64 && !videoBase64.startsWith('data:')) {
          videoBase64 = 'data:video/mp4;base64,' + videoBase64;
        }

        // Handle thumbnail เช่นกัน
        let thumbnail = payload.thumbnail || '';
        if (thumbnail && !thumbnail.startsWith('data:') && !thumbnail.startsWith('http') && !thumbnail.startsWith('blob:')) {
          thumbnail = 'data:image/jpeg;base64,' + thumbnail;
        }

        const item = {
          productId: payload.productId || payload.tiktokProductId || '',
          productName: payload.productName || payload.title || 'สินค้าจาก Google Flow',
          productUrl: payload.productUrl || payload.affiliateUrl || '',
          headline: payload.headline || payload.title || payload.caption || 'วิดีโอ AI ผลิตเสร็จ',
          videoUrl: payload.videoUrl || payload.url || '',
          videoBase64: videoBase64,
          thumbnail: thumbnail,
          caption: payload.caption || '',
          hashtags: payload.hashtags || '',
          platform: payload.platform || (payload.productUrl?.includes('shopee') ? 'shopee' : 'tiktok')
        };
        chrome.runtime.sendMessage({
          type: 'PHIMBOT_VAULT_SAVE',
          payload: item
        }, (res) => {
          if (res?.success) {
            emit('vault_save', `💾 บันทึกวิดีโอ [${item.platform.toUpperCase()}] "${item.productName}" ลงคลังสำเร็จ!`);
          }
        });
      } catch (err) {
        console.warn('[PhimBot] Failed to save exported video:', err);
      }
    }

    // Listen for pipeline errors from Tool
    if (event.data && event.data.type === 'EXT_PIPELINE_ERROR') {
      const errPayload = event.data.payload || {};
      console.warn('[PhimBot] ❌ Pipeline error from Tool:', errPayload.message, 'step:', errPayload.step);
      emit('error', `❌ Tool error [${errPayload.step || 'unknown'}]: ${errPayload.message || 'Unknown error'}`);
    }
  });

  emit('init', '✅ PhimBot Flow Automator v4 (OmniPost Engine) พร้อมทำงาน');
})();
