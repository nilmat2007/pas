﻿// flow-bridge-main.js
// Runs in Google Flow's MAIN world alongside OmniPost Flow assets
// Listens to CustomEvents from flow-automator.js (ISOLATED world)

(() => {
  if (window.__PHIMBOT_FLOW_BRIDGE_ACTIVE__) return;
  window.__PHIMBOT_FLOW_BRIDGE_ACTIVE__ = true;

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  window.addEventListener('PHIMBOT_FLOW_MAIN_EXEC', async (e) => {
    const { id, action, payload } = e.detail || {};
    if (!id) return;

    const respond = (ok, data, error) => {
      window.dispatchEvent(new CustomEvent('PHIMBOT_FLOW_MAIN_RESP_' + id, {
        detail: { ok, data, error }
      }));
    };

    try {
      if (action === 'ENSURE_PROJECT') {
        // If already in a project or composer is visible, we are 100% ready!
        if (location.href.includes('/project/') || document.querySelector('flow-prompt-box')) {
          for (let i = 0; i < 20; i++) {
            if (document.querySelector('flow-prompt-box')) break;
            await sleep(500);
          }
          respond(true, { projectUrl: location.href, ready: true });
          return;
        }

        // On home page: find New Project button
        const allDeep = (root = document, output = []) => {
          for (const el of root.querySelectorAll('*')) {
            output.push(el);
            if (el.shadowRoot) allDeep(el.shadowRoot, output);
          }
          return output;
        };

        let newBtn = null;
        for (const el of allDeep()) {
          const r = el.getBoundingClientRect ? el.getBoundingClientRect() : { width: 0 };
          if (r.width <= 10) continue;
          const text = ((el.innerText || el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
          if (text.includes('new project') || text.includes('โปรเจ็กต์ใหม่') || text.includes('โปรเจกต์ใหม่')) {
            newBtn = el.matches('button, a, [role="button"]') ? el : el.closest('button, a, [role="button"]');
            if (newBtn) break;
          }
        }

        if (newBtn) {
          newBtn.scrollIntoView({ block: 'center' });
          newBtn.focus?.();
          const r = newBtn.getBoundingClientRect();
          const opts = { bubbles: true, cancelable: true, composed: true, pointerType: 'mouse', button: 0, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
          newBtn.dispatchEvent(new PointerEvent('pointerdown', opts));
          newBtn.dispatchEvent(new MouseEvent('mousedown', opts));
          newBtn.dispatchEvent(new PointerEvent('pointerup', opts));
          newBtn.dispatchEvent(new MouseEvent('mouseup', opts));
          newBtn.click();

          // Wait for navigation to /project/
          let navOk = false;
          for (let i = 0; i < 40; i++) {
            await sleep(500);
            if (location.href.includes('/project/') || document.querySelector('flow-prompt-box')) {
              navOk = true;
              break;
            }
          }
          if (!navOk) throw new Error('failed_to_navigate_to_project');
        } else {
          // If no New Project button, check if prompt box is already available
          if (document.querySelector('flow-prompt-box')) {
            respond(true, { projectUrl: location.href, ready: true });
            return;
          }
          throw new Error('new_project_button_not_found');
        }

        respond(true, { projectUrl: location.href, ready: true });
      }

      else if (action === 'ENSURE_IMAGE_MODE') {
        const modeState = await globalThis.OmniPostFlowImageMode.ensure({ timeoutMs: 15000 });
        if (!modeState?.ok) throw new Error(modeState?.reason || 'failed_to_ensure_image_mode');
        await globalThis.OmniPostFlowImageMode.close();
        respond(true, modeState);
      }

      else if (action === 'ATTACH_REFERENCES') {
        const refs = Array.isArray(payload?.references) ? payload.references : [];
        if (refs.length === 0) {
          respond(true, { attachedReferenceCount: 0 });
          return;
        }
        const result = await globalThis.OmniPostFlowModernReference.attach(refs, {
          mode: 'ingredients',
          timeoutMs: 60000
        });
        if (!result?.ok) throw new Error(result?.reason || 'attach_references_failed');
        respond(true, result);
      }

      else if (action === 'FILL_PROMPT') {
        const result = await globalThis.OmniPostFlowModernReference.fillPrompt(payload.text || '');
        if (!result?.ok) throw new Error(result?.err || 'fill_prompt_failed');
        respond(true, result);
      }

      else if (action === 'CLICK_GENERATE') {
        const composer = document.querySelector('flow-prompt-box');
        let submit = composer?.querySelector('button[aria-label="Start generation"]');
        if (!submit) {
          submit = Array.from(document.querySelectorAll('button')).find(b => {
            const aria = (b.getAttribute('aria-label') || '').toLowerCase();
            return aria.includes('start generation') || aria.includes('สร้าง');
          });
        }
        if (!submit || submit.disabled) throw new Error('generate_button_not_ready');
        submit.click();
        respond(true, { clicked: true });
      }

      else if (action === 'ENSURE_VIDEO_SETTINGS') {
        const result = await globalThis.OmniPostFlowModernVideo.ensureSettings({
          model: payload.videoModel || 'veo_31_lite_lower_priority',
          modelLabel: payload.videoModel || 'Veo 3.1 - Lite',
          aspect: payload.aspect || '9:16',
          duration: payload.duration || 8,
          outputCount: 1,
        });
        if (!result?.ok) throw new Error('ensure_video_settings_failed');
        respond(true, result);
      }

      else if (action === 'ATTACH_START_FRAME') {
        const result = await globalThis.OmniPostFlowModernReference.attachLatestFromFlow({
          mode: 'frames',
          index: 0,
          timeoutMs: 25000
        });
        if (!result?.ok) throw new Error(result?.reason || 'attach_start_frame_failed');
        respond(true, result);
      }

      else if (action === 'EXPORT_MEDIA') {
        const items = await window.__OMNIPOST_FLOW_MEDIA__.exportLatest(payload || {});
        respond(true, items);
      }

      else if (action === 'GET_PROGRESS') {
        const progress = document.documentElement.getAttribute('data-omnipost-flow-progress');
        const progressAt = document.documentElement.getAttribute('data-omnipost-flow-progress-at');
        respond(true, { progress, progressAt });
      }

      else {
        throw new Error('unknown_action: ' + action);
      }
    } catch (err) {
      respond(false, null, err.message);
    }
  });
})();
