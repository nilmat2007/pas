/**
 * flow-video-interceptor.js
 * MAIN world script สำหรับ iframe ของ Tool (*.scf.usercontent.goog)
 * ดักจับ video blob ที่ Tool สร้าง แล้วส่งกลับให้ Extension ผ่าน postMessage
 * ทำงานโดยไม่ต้องพึ่ง Tool ส่ง EXT_EXPORT_VIDEO เอง
 */
(() => {
  if (window.__PHIMBOT_VIDEO_INTERCEPTOR__) return;
  window.__PHIMBOT_VIDEO_INTERCEPTOR__ = true;

  console.log('[PhimBot] 🎬 Video Interceptor loaded on:', location.href.slice(0, 80));

  // เก็บ video blobs ที่ดักจับได้
  if (!window.__FLOW_EXPORT_VIDEOS__) window.__FLOW_EXPORT_VIDEOS__ = [];

  // ═══════════ 1. ดักจับ URL.createObjectURL ═══════════
  const origCreateObjectURL = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (blob) {
    const url = origCreateObjectURL(blob);

    if (blob instanceof Blob && blob.type && blob.type.startsWith('video/')) {
      console.log('[PhimBot] 🎬 Video blob detected:', blob.type, 'size:', blob.size, 'url:', url);

      // แปลง blob เป็น base64 แล้วส่งกลับ Extension
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result; // data:video/mp4;base64,...
        console.log('[PhimBot] ✅ Video converted to base64, length:', base64.length);

        const exportPayload = {
          productId: window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.tiktokProductId || '',
          productName: window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.name || 'สินค้าจาก AI SALER PRO',
          productUrl: window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.productUrl || '',
          headline: 'วิดีโอ AI ผลิตเสร็จ',
          videoBase64: base64,
          videoUrl: url,
          thumbnail: '',
          caption: (window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.name || '') + ' รีวิวของดีบอกต่อ',
          hashtags: '#TikTokShop #รีวิว',
          platform: 'tiktok'
        };

        // Push to global array
        window.__FLOW_EXPORT_VIDEOS__.push(exportPayload);

        // ส่ง postMessage ทั้ง window และ parent
        const msg = { type: 'EXT_EXPORT_VIDEO', payload: exportPayload };
        window.postMessage(msg, '*');
        try { window.parent.postMessage(msg, '*'); } catch (_) {}

        console.log('[PhimBot] 📤 Video exported via postMessage! Total:', window.__FLOW_EXPORT_VIDEOS__.length);
      };
      reader.readAsDataURL(blob);
    }

    return url;
  };

  // ═══════════ 2. ดักจับ <a>.click() สำหรับ auto-download ═══════════
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.download && this.href && this.href.startsWith('blob:')) {
      console.log('[PhimBot] 📥 Download intercepted:', this.download, this.href);

      // ดึง blob จาก URL แล้วส่งกลับ
      fetch(this.href)
        .then(r => r.blob())
        .then(blob => {
          if (blob.type && blob.type.startsWith('video/')) {
            const reader = new FileReader();
            reader.onload = () => {
              const base64 = reader.result;
              console.log('[PhimBot] ✅ Downloaded video captured, length:', base64.length);

              const exportPayload = {
                productId: window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.tiktokProductId || '',
                productName: window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.name || 'สินค้าจาก AI SALER PRO',
                productUrl: window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.productUrl || '',
                headline: this.download || 'วิดีโอ AI ผลิตเสร็จ',
                videoBase64: base64,
                videoUrl: this.href,
                thumbnail: '',
                caption: (window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]?.name || '') + ' รีวิวของดีบอกต่อ',
                hashtags: '#TikTokShop #รีวิว',
                platform: 'tiktok'
              };

              if (!window.__FLOW_EXPORT_VIDEOS__) window.__FLOW_EXPORT_VIDEOS__ = [];
              window.__FLOW_EXPORT_VIDEOS__.push(exportPayload);

              const msg = { type: 'EXT_EXPORT_VIDEO', payload: exportPayload };
              window.postMessage(msg, '*');
              try { window.parent.postMessage(msg, '*'); } catch (_) {}

              console.log('[PhimBot] 📤 Downloaded video exported! Total:', window.__FLOW_EXPORT_VIDEOS__.length);
            };
            reader.readAsDataURL(blob);
          }
        })
        .catch(() => {});
    }

    // เรียก click() ปกติเพื่อให้ download ยังทำงาน
    return origClick.call(this);
  };

  // ═══════════ 3. Monitor สำหรับ video elements ใน DOM ═══════════
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.tagName === 'VIDEO' && node.src) {
          console.log('[PhimBot] 🎬 Video element added to DOM:', node.src.slice(0, 100));
        }
        // หา <a download> ที่ถูกเพิ่มเข้ามา
        if (node.tagName === 'A' && node.download && node.href?.startsWith('blob:')) {
          console.log('[PhimBot] 📥 Download link added:', node.download);
        }
      }
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  console.log('[PhimBot] 🎬 Video Interceptor ready — intercepting createObjectURL + download clicks');
})();
