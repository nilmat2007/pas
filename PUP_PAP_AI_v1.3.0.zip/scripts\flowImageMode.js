// Runs in Flow's isolated world; never submits a prompt or changes media.
(() => {
  const visible = (el) => {
    if (!el?.isConnected) return false;
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.display !== 'none'
      && style.visibility !== 'hidden' && style.opacity !== '0';
  };
  const deep = (selector, root = document) => {
    const result = [...root.querySelectorAll(selector)];
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) result.push(...deep(selector, el.shadowRoot));
    }
    return result;
  };
  const label = (el) => {
    const copy = el.cloneNode(true);
    copy.querySelectorAll('svg, i, mat-icon, [aria-hidden="true"]').forEach((icon) => icon.remove());
    return String(el.getAttribute('aria-label') || copy.textContent || el.getAttribute('title') || '')
      .replace(/\s+/g, ' ').trim().toLowerCase();
  };
  const controls = (root) => deep('button, [role="tab"], [role="radio"], [role="button"]', root).filter(visible);
  const modeOf = (el) => {
    const text = label(el);
    if (/^(image|images|รูป|ภาพ|รูปภาพ)$/.test(text) || /สร้างภาพ|โหมดภาพ/.test(text)) return 'image';
    if (/^(video|videos|วิดีโอ|วิดิโอ)$/.test(text)) return 'video';
    return null;
  };
  const selected = (el) => el && (
    ['aria-selected', 'aria-pressed', 'aria-checked', 'data-selected'].some((key) => el.getAttribute(key) === 'true')
    || /^(active|on|checked)$/.test(el.getAttribute('data-state') || '')
  );
  const enabled = (el) => el && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && !el.hasAttribute('data-disabled');
  function findPanel() {
    const panels = deep('flow-prompt-box-settings, .cdk-overlay-pane, [data-radix-popper-content-wrapper], [data-radix-menu-content], [data-slot="popover-content"], [data-state="open"], [role="dialog"], [role="menu"], .popover-content, .radix-popper').filter(visible);
    return panels.filter((panel) => {
      const modes = controls(panel).map(modeOf);
      return modes.includes('image') && modes.includes('video');
    }).sort((a, b) => a.getBoundingClientRect().height - b.getBoundingClientRect().height)[0] || null;
  }
  function findTrigger() {
    const editors = deep('textarea, [contenteditable="true"]').filter(visible);
    const candidates = controls(document).filter((el) => {
      if (!enabled(el) || el.closest('flow-prompt-box-settings, .cdk-overlay-pane, [data-radix-popper-content-wrapper], [role="menu"], [role="dialog"]')) return false;
      const text = label(el);
      if (/\b(send|submit|generate|upload|attach|agent)\b|ส่ง|อัปโหลด|อัพโหลด|แนบ/.test(text)) return false;
      const summary = /\b(video|image|nano banana|imagen)\b|วิดีโอ|วิดิโอ|รูปภาพ|ภาพ/.test(text)
        && /\bx\s*[1-4]\b|\b[1-4]x\b|\d+p\b|\d+\s*s\b|\d+\s*วิ|nano banana|imagen/.test(text);
      const settings = /^(settings|settings trigger|generation settings|ตั้งค่า|การตั้งค่า|ตั้งค่าการสร้าง)$/.test(text)
        || deep('i, mat-icon', el).some((icon) => /^(tune|instant_mix|crop_\w+)$/.test(icon.textContent.trim()));
      if (!summary && !settings) return false;
      const rect = el.getBoundingClientRect();
      return editors.some((editor) => {
        const e = editor.getBoundingClientRect();
        return rect.top >= e.top - 30 && rect.top < e.bottom + 120 && rect.right >= e.left && rect.left <= e.right + 80;
      });
    });
    return candidates.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right)[0] || null;
  }
  function imageIsActive(panel) {
    if (!panel) return false;
    const buttons = controls(panel);
    const image = buttons.find((el) => modeOf(el) === 'image');
    const video = buttons.find((el) => modeOf(el) === 'video');
    if (!image || !video || selected(video)) return false;
    // Some builds use plain segmented buttons. Require image-only settings,
    // not the presence of an Image label or the fact that click() returned.
    const labels = buttons.map(label);
    const videoSettings = labels.some((text) => /^(360p|720p|1080p)$/.test(text))
      && labels.some((text) => /^(4s|6s|8s|10s)$/.test(text));
    if (videoSettings) return false;
    if (selected(image)) return true;
    return labels.some((text) => /nano banana|imagen/.test(text))
      && labels.some((text) => /^(1:1|3:4|4:3|9:16|16:9)$/.test(text))
      && !labels.some((text) => /^(360p|720p|1080p|4s|6s|8s|10s)$/.test(text));
  }
  async function ensure({ timeoutMs = 15000 } = {}) {
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const deadline = Date.now() + Math.max(500, Math.min(30000, Number(timeoutMs) || 15000));
    let attempts = 0;
    let openings = 0;
    let stable = 0;
    let lastClick = 0;
    let trigger = null;
    let reason = 'config_popper_trigger_not_found';
    while (Date.now() < deadline) {
      const panel = findPanel();
      if (panel) {
        if (imageIsActive(panel)) {
          stable += 1;
          if (stable >= 2) return { ok: true, panel, trigger: findTrigger() || trigger, changed: attempts > 0 };
        } else {
          stable = 0;
          reason = 'failed_to_select_image_tab';
          const image = controls(panel).find((el) => modeOf(el) === 'image');
          if (enabled(image) && attempts < 3 && Date.now() - lastClick > 1200) {
            image.scrollIntoView({ block: 'nearest' });
            image.focus();
            image.click();
            attempts += 1;
            lastClick = Date.now();
          }
        }
      } else {
        stable = 0;
        trigger = findTrigger();
        if (trigger && openings < 4 && Date.now() - lastClick > 1200) {
          reason = 'popper_dialog_not_found';
          trigger.scrollIntoView({ block: 'nearest' });
          const rect = trigger.getBoundingClientRect();
          const init = { bubbles: true, cancelable: true, composed: true, pointerType: 'mouse', button: 0, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
          trigger.dispatchEvent(new PointerEvent('pointerdown', init));
          trigger.dispatchEvent(new PointerEvent('pointerup', init));
          await sleep(200);
          // Radix opens on pointerdown. A second click would close it again.
          if (!findPanel()) trigger.click();
          openings += 1;
          lastClick = Date.now();
        }
      }
      await sleep(200);
    }
    return { ok: false, reason };
  }
  async function close() {
    const panel = findPanel();
    if (!panel) return true;
    const target = panel.querySelector('button') || panel;
    target.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true, composed: true }));
    await new Promise((resolve) => setTimeout(resolve, 250));
    if (findPanel()) {
      findTrigger()?.click();
      await new Promise((resolve) => setTimeout(resolve, 300));
    }
    return !findPanel();
  }
  globalThis.OmniPostFlowImageMode = { ensure, close, findPanel, findTrigger, imageIsActive, label };
})();
