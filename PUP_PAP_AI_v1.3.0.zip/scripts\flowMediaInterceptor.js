// Google Flow MAIN-world media safety net. It keeps short-lived generated
// Blobs readable until OmniPost has validated and persisted them.
(() => {
  if (window.__OMNIPOST_FLOW_MEDIA__?.version >= 2) return;
  const MAX_ITEMS = 16;
  const MAX_TOTAL_BYTES = 384 * 1024 * 1024;
  const MAX_AGE_MS = 20 * 60 * 1000;
  const FLOW_PROGRESS_ATTR = 'data-omnipost-flow-progress';
  const FLOW_PROGRESS_AT_ATTR = 'data-omnipost-flow-progress-at';
  const FLOW_PROGRESS_SOURCE_ATTR = 'data-omnipost-flow-progress-source';
  const entries = [];
  const rememberedBlobs = new WeakSet();
  let totalCapturedBytes = 0;
  const nativeCreateObjectURL = URL.createObjectURL.bind(URL);
  const nativeRevokeObjectURL = URL.revokeObjectURL.bind(URL);
  const nativeFetch = window.fetch.bind(window);
  const pendingRevokeTimers = new Map();
  const kindOf = (blob) => String(blob?.type || '').startsWith('video/') ? 'video' : String(blob?.type || '').startsWith('image/') ? 'image' : '';
  const releaseRemovedEntry = (entry) => {
    if (!entry?.revokeRequested || !entry.url) return;
    const timer = pendingRevokeTimers.get(entry.url);
    if (timer) clearTimeout(timer);
    pendingRevokeTimers.delete(entry.url);
    try { nativeRevokeObjectURL(entry.url); } catch (_) {}
  };
  const prune = () => {
    const cutoff = Date.now() - MAX_AGE_MS;
    while (entries.length > 1 && (
      entries[0].capturedAt < cutoff
      || entries.length > MAX_ITEMS
      || totalCapturedBytes > MAX_TOTAL_BYTES
    )) {
      const removed = entries.shift();
      totalCapturedBytes = Math.max(0, totalCapturedBytes - Number(removed?.blob?.size || 0));
      releaseRemovedEntry(removed);
    }
  };
  const remember = (blob, source, url = '') => {
    const kind = kindOf(blob);
    if (!(blob instanceof Blob) || !kind || blob.size < 10 * 1024) return;
    if (rememberedBlobs.has(blob)) return;
    rememberedBlobs.add(blob);
    entries.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, blob, kind, source, url, capturedAt: Date.now() });
    totalCapturedBytes += blob.size;
    prune();
  };
  const toDataUrl = (blob) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error || new Error('flow_blob_read_failed'));
    reader.readAsDataURL(blob);
  });
  URL.createObjectURL = function (value) {
    const url = nativeCreateObjectURL(value);
    try { remember(value, 'createObjectURL', url); } catch (_) {}
    return url;
  };
  URL.revokeObjectURL = function (url) {
    const matchingEntry = entries.find((entry) => entry.url === url);
    if (matchingEntry) matchingEntry.revokeRequested = true;
    const previousTimer = pendingRevokeTimers.get(url);
    if (previousTimer) clearTimeout(previousTimer);
    const timer = setTimeout(() => {
      pendingRevokeTimers.delete(url);
      try { nativeRevokeObjectURL(url); } catch (_) {}
    }, MAX_AGE_MS);
    pendingRevokeTimers.set(url, timer);
  };
  window.fetch = async function (...args) {
    const response = await nativeFetch(...args);
    try {
      if (/^(image|video)\//i.test(String(response.headers?.get?.('content-type') || ''))) {
        response.clone().blob().then((blob) => remember(blob, 'fetch', String(response.url || args[0] || ''))).catch(() => {});
      }
    } catch (_) {}
    return response;
  };

  // Flow updates the visible render percentage independently from the
  // extension polling cycle. Observe it in MAIN world at document_start and
  // publish a short-lived bridge on <html>. Both the foreground and service
  // worker readers consume this same value, so a direct 0% -> 18% render
  // (without Queued) cannot be mistaken for an old Failed card.
  const isVisible = (element) => {
    if (!element?.getBoundingClientRect) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0
      && rect.bottom > 0 && rect.right > 0
      && rect.left < innerWidth && rect.top < innerHeight
      && style.display !== 'none' && style.visibility !== 'hidden'
      && Number(style.opacity || 1) > 0;
  };
  const percentFrom = (value) => {
    const match = String(value || '').match(/(?:^|[^\d])(\d{1,3})\s*%(?:[^\d]|$)/);
    if (!match) return null;
    const pct = Number.parseInt(match[1], 10);
    return Number.isFinite(pct) && pct >= 0 && pct <= 100 ? pct : null;
  };
  const belongsToCompactFailedCard = (element) => {
    let current = element;
    for (let depth = 0; current && current !== document.body && depth < 12; depth += 1) {
      const rect = current.getBoundingClientRect?.();
      if (rect && rect.width >= 120 && rect.width <= Math.min(720, innerWidth * 0.7)
        && rect.height >= 120 && rect.height <= Math.min(900, innerHeight * 0.94)) {
        const directText = Array.from(current.childNodes || [])
          .filter((node) => node.nodeType === Node.TEXT_NODE)
          .map((node) => String(node.textContent || '').trim())
          .filter(Boolean)
          .join(' ');
        const statusText = `${directText} ${current.getAttribute?.('aria-label') || ''}`.trim();
        if (/^(?:warning\s+)?(?:Failed|Generation failed|(?:การ)?สร้าง(?:รูปภาพ?|วิดีโอ|วิดิโอ|เสียง)?(?:ไม่สำเร็จ|ล้มเหลว|ไม่ได้)|ไม่สามารถสร้าง(?:รูปภาพ?|วิดีโอ|วิดิโอ|เสียง)?(?:ได้)?|เกิดข้อผิดพลาด|มีบางอย่างผิดพลาด)\b/i.test(statusText)) return true;
      }
      current = current.parentElement || current.getRootNode?.()?.host || null;
    }
    return false;
  };
  const progressFromElement = (element) => {
    if (!isVisible(element) || element.closest?.('#omnipost-root') || belongsToCompactFailedCard(element)) return null;
    const ariaNow = Number.parseFloat(String(element.getAttribute?.('aria-valuenow') || ''));
    if (Number.isFinite(ariaNow) && ariaNow >= 0 && ariaNow <= 100) return Math.round(ariaNow);
    const nativeValue = Number.parseFloat(String(element.value ?? element.getAttribute?.('value') ?? ''));
    if (element.matches?.('[role="progressbar"], progress, meter')
      && Number.isFinite(nativeValue) && nativeValue >= 0 && nativeValue <= 100) return Math.round(nativeValue);
    const directText = Array.from(element.childNodes || [])
      .filter((node) => node.nodeType === Node.TEXT_NODE)
      .map((node) => node.nodeValue || '')
      .join(' ');
    for (const value of [
      element.getAttribute?.('aria-valuetext'),
      element.getAttribute?.('aria-label'),
      element.getAttribute?.('title'),
      element.getAttribute?.('data-progress'),
      directText,
    ]) {
      const pct = percentFrom(value);
      if (pct != null) return pct;
    }
    return null;
  };
  const findVisibleFlowProgress = () => {
    // The current Flow build puts the live percentage in history-step-*.
    // Use the same source first, then semantic progress attributes, then a
    // visible bare text-node fallback used by some Flow releases.
    for (const item of document.querySelectorAll?.('div[id^="history-step-"]') || []) {
      if (!isVisible(item) || belongsToCompactFailedCard(item)) continue;
      const itemPct = percentFrom(item.textContent);
      if (itemPct != null) return { progress: itemPct, source: 'history' };
      for (const node of [item, ...item.querySelectorAll('[aria-valuenow], [aria-valuetext], [aria-label], [title], [role="progressbar"], progress, meter')]) {
        const pct = progressFromElement(node);
        if (pct != null) return { progress: pct, source: 'history-aria' };
      }
    }
    for (const element of document.querySelectorAll?.('[aria-valuenow], [aria-valuetext], [aria-label], [title], [role="progressbar"], progress, meter') || []) {
      const pct = progressFromElement(element);
      if (pct != null) return { progress: pct, source: 'aria' };
    }
    if (document.body) {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node = walker.nextNode();
      while (node) {
        const parent = node.parentElement;
        const pct = percentFrom(String(node.textContent || '').trim());
        if (parent && pct != null && isVisible(parent) && !parent.closest?.('#omnipost-root')
          && !belongsToCompactFailedCard(parent)) return { progress: pct, source: 'text' };
        node = walker.nextNode();
      }
    }
    return null;
  };
  let progressScanQueued = false;
  let progressScanTimer = null;
  let lastProgressScanAt = 0;
  const PROGRESS_SCAN_MIN_INTERVAL_MS = 500;
  const publishVisibleProgress = () => {
    progressScanQueued = false;
    lastProgressScanAt = Date.now();
    const snapshot = findVisibleFlowProgress();
    if (!snapshot || !document.documentElement) return;
    document.documentElement.setAttribute(FLOW_PROGRESS_ATTR, String(snapshot.progress));
    document.documentElement.setAttribute(FLOW_PROGRESS_AT_ATTR, String(Date.now()));
    document.documentElement.setAttribute(FLOW_PROGRESS_SOURCE_ATTR, snapshot.source);
  };
  const queueProgressScan = () => {
    if (progressScanQueued || progressScanTimer) return;
    const waitMs = Math.max(0, PROGRESS_SCAN_MIN_INTERVAL_MS - (Date.now() - lastProgressScanAt));
    if (waitMs > 0) {
      progressScanTimer = setTimeout(() => {
        progressScanTimer = null;
        queueProgressScan();
      }, waitMs);
      return;
    }
    progressScanQueued = true;
    requestAnimationFrame(publishVisibleProgress);
  };
  const startProgressObserver = () => {
    if (!document.documentElement) return;
    new MutationObserver(queueProgressScan).observe(document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['aria-valuenow', 'aria-valuetext', 'aria-label', 'title', 'value', 'style', 'class'],
    });
    // Keep the bridge lease fresh while Flow animates a percentage without a
    // DOM mutation that our observer can see.
    setInterval(publishVisibleProgress, 1000);
    queueProgressScan();
  };
  if (document.documentElement) startProgressObserver();
  else addEventListener('DOMContentLoaded', startProgressObserver, { once: true });

  window.__OMNIPOST_FLOW_MEDIA__ = Object.freeze({
    version: 2,
    checkpoint: () => ({ capturedAt: Date.now(), ids: entries.map((entry) => entry.id) }),
    exportLatest: async ({ kind = '', after = 0, excludeIds = [], limit = 4 } = {}) => {
      prune();
      const excluded = new Set(Array.isArray(excludeIds) ? excludeIds : []);
      const matches = entries.filter((entry) => (!kind || entry.kind === kind) && entry.capturedAt >= Number(after || 0) && !excluded.has(entry.id));
      const output = [];
      for (const entry of matches.slice(-Math.max(1, Number(limit || 4))).reverse()) {
        try { output.push({ id: entry.id, type: entry.blob.type, size: entry.blob.size, capturedAt: entry.capturedAt, source: entry.source, url: entry.url, dataUrl: await toDataUrl(entry.blob) }); } catch (_) {}
      }
      return output;
    },
  });
})();
