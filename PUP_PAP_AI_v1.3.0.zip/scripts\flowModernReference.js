(() => {
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
  const HUMAN_CLICK_LEAD_MS = 200;
  const ACTION_SETTLE_MS = 400;
  const visible = (el) => Boolean(el?.isConnected && el.getBoundingClientRect().width > 0 && el.getBoundingClientRect().height > 0);
  const normalize = (value) => String(value || '').replace(/\s+/g, ' ').trim();
  const label = (el) => normalize(el?.getAttribute?.('aria-label') || el?.getAttribute?.('mattooltip') || el?.getAttribute?.('title') || el?.textContent || '');
  const compact = (value) => normalize(value).toLowerCase();
  const FLOW_LABELS = {
    startFrame: [/^start$/i, /เฟรมเริ่ม|เริ่มต้น|เริ่ม/i],
    endFrame: [/^end$/i, /เฟรมจบ|สิ้นสุด|จบ/i],
    addIngredients: [/add ingredients/i, /add.*prompt box/i, /เพิ่ม.*ingredient/i, /เพิ่ม.*วัตถุดิบ/i, /เพิ่ม.*ส่วนประกอบ/i, /องค์ประกอบ/i, /เพิ่ม.*องค์ประกอบ/i, /เพิ่ม.*ภาพ/i, /เพิ่ม.*พรอมพ์/i, /เพิ่ม.*พรอมต์/i],
    uploadMedia: [/upload media/i, /upload image/i, /อัปโหลด.*สื่อ/i, /อัพโหลด.*สื่อ/i, /อัปโหลด.*รูป/i, /อัพโหลด.*รูป/i, /อัปโหลด/i, /อัพโหลด/i],
    addToPrompt: [/add to prompt/i, /เพิ่ม.*prompt/i, /เพิ่ม.*พรอมพ์/i, /เพิ่ม.*พรอมต์/i, /เพิ่มไปยังพรอมต์/i, /เพิ่มไปยังพรอมพ์/i, /เพิ่ม.*คำสั่ง/i],
    startGeneration: [/start generation/i, /generate/i, /เริ่ม.*สร้าง/i, /สร้าง.*ภาพ/i, /สร้าง.*วิดีโอ/i],
  };
  const matchesLabel = (text, key) => FLOW_LABELS[key].some((pattern) => pattern.test(compact(text)));
  const buttonAny = (root, key) => buttonLike(root, text => matchesLabel(text, key));
  const iconText = (el) => Array.from(el?.querySelectorAll?.('i, mat-icon, .material-icons, .google-symbols') || [])
    .map(icon => normalize(icon.textContent).toLowerCase())
    .filter(Boolean);
  const composer = () => Array.from(document.querySelectorAll('flow-prompt-box')).find(visible);
  const panel = () => {
    const popover = document.querySelector('.cdk-overlay-pane flow-add-menu-popover-content, flow-add-menu-popover-content');
    if (popover && visible(popover)) return popover;
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"][data-state="open"], [role="dialog"], [data-radix-popper-content-wrapper] [data-state="open"], [data-radix-menu-content][data-state="open"]')).filter(visible);
    if (dialogs.length) return dialogs[0];
    const cdk = Array.from(document.querySelectorAll('.cdk-overlay-pane:has(button)')).filter(visible);
    return cdk[0] || null;
  };
  const buttons = (root) => Array.from(root?.querySelectorAll('button, [role="button"], [role="option"], [role="gridcell"]') || []).filter(el => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
  const button = (root, name) => buttons(root).find(el => label(el) === name);
  const buttonLike = (root, matcher) => buttons(root).find(el => matcher(label(el), el));
  const ingredientMedia = () => Array.from(composer()?.querySelectorAll('flow-ingredient-bar img, flow-ingredient-bar canvas, flow-ingredient-bar video') || [])
    .filter(visible)
    .filter(el => !el.closest('flow-rich-text-editor, flow-add-menu-popover-content'));
  const countIngredients = () => ingredientMedia().length;
  const ingredientMediaReady = () => ingredientMedia().every(el => {
    if (el.tagName !== 'IMG') return true;
    const hasImageSource = Boolean(el.currentSrc || el.src);
    const loadedEnough = el.complete && Number(el.naturalWidth || 0) > 0;
    const sizedEnough = Number(el.width || el.getBoundingClientRect?.().width || 0) > 0
      && Number(el.height || el.getBoundingClientRect?.().height || 0) > 0;
    return loadedEnough || (hasImageSource && sizedEnough);
  });
  const countFrames = () => {
    const box = composer();
    if (!box) return 0;
    const imageFrames = Array.from(box.querySelectorAll('img, canvas, video'))
      .filter(el => {
        if (el.closest('flow-ingredient-bar, flow-rich-text-editor, flow-add-menu-popover-content') || !visible(el)) return false;
        if (el.tagName !== 'IMG') return true;
        const hasImageSource = Boolean(el.currentSrc || el.src);
        const loadedEnough = el.complete && Number(el.naturalWidth || 0) > 20;
        const sizedEnough = Number(el.width || el.getBoundingClientRect?.().width || 0) > 20
          && Number(el.height || el.getBoundingClientRect?.().height || 0) > 20;
        return loadedEnough || (hasImageSource && sizedEnough);
      });
    if (imageFrames.length) return imageFrames.length;
    const filledFrameChips = buttons(box).filter(btn => /start|end|เฟรม|เริ่ม|จบ/i.test(label(btn))
      && !btn.classList.contains('empty-chip')
      && (btn.querySelector('img, canvas, video') || /change|replace|remove|เปลี่ยน|ลบ/i.test(label(btn))));
    return filledFrameChips.length;
  };
  const count = (mode = 'ingredients') => mode === 'frames' ? countFrames() : countIngredients();
  const showClickRipple = (el) => {
    if (!el || typeof el.getBoundingClientRect !== 'function') return;
    try {
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) return;
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const ripple = document.createElement('div');
      ripple.setAttribute('data-omnipost-click-ripple', 'gold');
      ripple.style.cssText = `position:fixed;left:${cx}px;top:${cy}px;width:0;height:0;border-radius:50%;background:rgba(234,179,8,0.45);transform:translate(-50%,-50%);pointer-events:none;z-index:999999;transition:all 0.6s ease-out;box-shadow:0 0 12px 4px rgba(234,179,8,0.25);`;
      document.body.appendChild(ripple);
      globalThis.__omniGoldClickCount = Number(globalThis.__omniGoldClickCount || 0) + 1;
      requestAnimationFrame(() => {
        ripple.style.width = '60px';
        ripple.style.height = '60px';
        ripple.style.opacity = '0';
      });
      setTimeout(() => { try { ripple.remove(); } catch (_) {} }, 800);
    } catch (_) {}
  };
  const click = async (el) => {
    if (!el) return;
    el.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'instant' });
    el.focus?.({ preventScroll: true });
    showClickRipple(el);
    const rect = el.getBoundingClientRect?.();
    const eventInit = rect ? {
      bubbles: true,
      cancelable: true,
      composed: true,
      pointerType: 'mouse',
      button: 0,
      buttons: 1,
      clientX: rect.left + rect.width / 2,
      clientY: rect.top + rect.height / 2,
    } : { bubbles: true, cancelable: true, composed: true };
    try { el.dispatchEvent(new PointerEvent('pointerdown', eventInit)); } catch (_) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', eventInit)); } catch (_) {}
    await sleep(80);
    try { el.dispatchEvent(new PointerEvent('pointerup', { ...eventInit, buttons: 0 })); } catch (_) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', { ...eventInit, buttons: 0 })); } catch (_) {}
    await sleep(HUMAN_CLICK_LEAD_MS);
    el.click();
    await sleep(ACTION_SETTLE_MS);
  };
  async function waitFor(get, timeout) {
    const end = Date.now() + timeout;
    do {
      const value = get();
      if (value) return value;
      await sleep(150);
    } while (Date.now() < end);
    return null;
  }
  async function scrollToTop(root) {
    const scroller = root?.querySelector?.('[data-testid="virtuoso-scroller"]')
      || Array.from(root?.querySelectorAll?.('div, [role="listbox"], [role="list"], aside') || [])
          .find(el => el.scrollHeight > el.clientHeight + 50 && visible(el));
    if (!scroller) return;
    for (let i = 0; i < 3; i += 1) {
      scroller.scrollTop = 0;
      await sleep(200);
    }
  }
  const isItemReady = (el) => {
    const img = el?.matches?.('img') ? el : el?.querySelector?.('img');
    if (!img || !visible(img)) return false;
    if (img.tagName === 'IMG' && !img.complete) return false;
    if (Number(img.naturalWidth || 0) <= 20 || Number(img.naturalHeight || 0) <= 20) return false;
    if (/\b\d{1,3}\s?%\b|progress_activity|autorenew|hourglass/i.test(label(el))) return false;
    return true;
  };
  const findFrameTarget = (index = 0) => {
    const key = Number(index || 0) <= 0 ? 'startFrame' : 'endFrame';
    const wanted = Number(index || 0) <= 0 ? /^(start|เฟรมเริ่ม|เริ่มต้น|เริ่ม)$/i : /^(end|เฟรมจบ|สิ้นสุด|จบ)$/i;
    const loose = Number(index || 0) <= 0 ? /start|เฟรมเริ่ม|เริ่มต้น|เริ่ม/i : /end|เฟรมจบ|สิ้นสุด|จบ/i;
    const box = composer();
    return Array.from(box?.querySelectorAll('button.empty-chip') || []).find(el => visible(el) && wanted.test(label(el).toLowerCase()))
      || buttonAny(box, key)
      || buttons(box).find(el => wanted.test(label(el)))
      || buttons(box).find(el => loose.test(label(el)))
      || buttons(box).find(el => {
        const text = label(el).toLowerCase();
        const icons = iconText(el);
        return el.matches?.('[aria-haspopup="dialog"], button[aria-haspopup="dialog"]')
          && (icons.includes('add_2') || icons.includes('add') || /create|start|add|สร้าง|เพิ่ม/.test(text));
      })
      || null;
  };
  const findIngredientTarget = () => buttonAny(composer(), 'addIngredients')
    || button(composer(), 'Add ingredients to the prompt box')
    || buttonLike(composer(), (text, el) => /add ingredients|เพิ่ม.*ingredient|เพิ่ม.*องค์ประกอบ|องค์ประกอบ|เพิ่ม.*ภาพ|add/i.test(text.toLowerCase())
      && (el.matches?.('button.add-menu-trigger, [aria-haspopup="dialog"], button[aria-haspopup="dialog"], [aria-haspopup="true"], button[aria-haspopup="true"]') || iconText(el).includes('add_2') || iconText(el).includes('add')));
  const findUploadButton = (root) => buttonAny(root, 'uploadMedia')
    || button(root, 'Upload media')
    || buttonLike(root, (text, el) => /upload media|upload image|อัปโหลดรูป|อัปโหลด|upload/i.test(text.toLowerCase())
      || iconText(el).includes('upload'));
  const UPLOAD_READY_STABLE_MS = 2500;
  const uploadIsBusy = (root) => {
    const scope = root && root.isConnected ? root : panel();
    if (!scope) return false;
    const text = normalize(scope.textContent);
    if (/(?:^|\s)(?:[0-9]|[1-9][0-9])\s?%(?:\s|$)/.test(text)) return true;
    if (/uploading|processing upload|preparing media|กำลังอัปโหลด|กำลังอัพโหลด|กำลังประมวลผล/i.test(text)) return true;
    const progress = Array.from(scope.querySelectorAll([
      '[role="progressbar"]',
      'mat-progress-spinner',
      'mat-spinner',
      '.mat-mdc-progress-spinner',
      '[class*="progress-spinner"]',
      '[class*="loading-spinner"]',
      '[class*="upload-progress"]',
      '[data-testid*="progress"]',
      '[data-testid*="loading"]',
    ].join(','))).find((el) => {
      if (!visible(el)) return false;
      const value = Number(el.getAttribute?.('aria-valuenow'));
      return !Number.isFinite(value) || value < 100;
    });
    if (progress) return true;
    return Array.from(scope.querySelectorAll('i, mat-icon, .material-icons, .google-symbols'))
      .some((el) => visible(el) && /progress_activity|autorenew|hourglass|sync/i.test(normalize(el.textContent)));
  };
  const mediaImageReady = (target) => {
    const img = target?.matches?.('img') ? target : target?.querySelector?.('img');
    if (!img) return true; // Some Flow list rows expose only the uploaded filename until selected.
    const src = String(img.currentSrc || img.src || '');
    return visible(img)
      && Boolean(src)
      && !/spinner|progress|loading|transparent|placeholder/i.test(`${src} ${img.alt || ''} ${img.className || ''}`)
      && img.complete
      && Number(img.naturalWidth || 0) > 20
      && Number(img.naturalHeight || 0) > 20;
  };
  async function waitForStableUploadReady(getTarget, timeoutMs, { requireAddButton = false } = {}) {
    const deadline = Date.now() + Math.max(1000, Number(timeoutMs || 0));
    const requiredStableMs = Math.max(50, Number(globalThis.__omniUploadReadyStableMs || UPLOAD_READY_STABLE_MS));
    let stableSince = 0;
    let stableSignature = '';
    while (Date.now() < deadline) {
      const scope = panel();
      const target = getTarget?.();
      const add = requireAddButton ? findAddToPromptButton(scope || document) : null;
      const ready = Boolean(scope && target && visible(target) && mediaImageReady(target)
        && !uploadIsBusy(scope)
        && (!requireAddButton || (add && visible(add) && !add.disabled && add.getAttribute('aria-disabled') !== 'true')));
      if (ready) {
        const img = target.matches?.('img') ? target : target.querySelector?.('img');
        const signature = [
          String(img?.currentSrc || img?.src || ''),
          Number(img?.naturalWidth || 0),
          Number(img?.naturalHeight || 0),
          requireAddButton ? label(add) : '',
        ].join('|');
        if (signature !== stableSignature) {
          stableSignature = signature;
          stableSince = Date.now();
        } else if (Date.now() - stableSince >= requiredStableMs) {
          try { await img?.decode?.(); } catch (_) { stableSince = 0; }
          if (stableSince && !uploadIsBusy(panel()) && target.isConnected) return { target, add };
        }
      } else {
        stableSince = 0;
        stableSignature = '';
      }
      await sleep(200);
    }
    return null;
  }
  const findAddToPromptButton = (root = document) => {
    const scopes = [root, panel(), document].filter(Boolean);
    for (const scope of scopes) {
      const exactFlowButton = Array.from(scope.querySelectorAll('button.detail-add-to-prompt-btn, button[class*="add-to-prompt"]'))
        .find(el => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
      if (exactFlowButton) return exactFlowButton;
      const candidates = Array.from(scope.querySelectorAll('button, [role="button"]'))
        .filter(visible)
        .filter(el => !el.disabled && el.getAttribute('aria-disabled') !== 'true' && !el.hasAttribute('data-disabled'));
      const btn = candidates.find(el => {
        const t = label(el).toLowerCase();
        const txt = (el.textContent || '').trim().toLowerCase();
        const aria = (el.getAttribute('aria-label') || '').toLowerCase();
        return matchesLabel(t, 'addToPrompt')
          || matchesLabel(txt, 'addToPrompt')
          || matchesLabel(aria, 'addToPrompt');
      });
      if (btn) return btn;
    }
    const previewAction = findPrimaryPreviewActionButton(root);
    if (previewAction) return previewAction;
    return buttonAny(root, 'addToPrompt') || button(root, 'Add to prompt') || buttonLike(root, text => /add to prompt|เพิ่ม.*prompt|เพิ่ม/i.test(text.toLowerCase()));
  };
  function findPrimaryPreviewActionButton(root = document) {
    const scope = root && root.isConnected ? root : panel() || document;
    const scopeRect = scope.getBoundingClientRect?.() || { left: 0, top: 0, width: window.innerWidth || 1, height: window.innerHeight || 1 };
    const candidates = Array.from(scope.querySelectorAll('button, [role="button"]'))
      .filter(visible)
      .filter(el => !el.disabled && el.getAttribute('aria-disabled') !== 'true')
      .map(el => {
        const rect = el.getBoundingClientRect();
        const text = `${label(el)} ${el.textContent || ''}`.toLowerCase();
        const rightHalf = rect.left >= scopeRect.left + (scopeRect.width * 0.42);
        const lowerArea = rect.top >= scopeRect.top + (scopeRect.height * 0.62);
        const wide = rect.width >= Math.max(180, scopeRect.width * 0.32);
        const semantic = matchesLabel(text, 'addToPrompt');
        const reject = /upload media|upload image|อัปโหลด|อัพโหลด|cancel|close|ยกเลิก|ปิด/i.test(text);
        return { el, rect, score: (semantic ? 100 : 0) + (rightHalf ? 25 : 0) + (lowerArea ? 25 : 0) + (wide ? 20 : 0) - (reject ? 200 : 0) };
      })
      .filter(entry => entry.score >= 60)
      .sort((a, b) => b.score - a.score || b.rect.bottom - a.rect.bottom);
    return candidates[0]?.el || null;
  }
  function findStartGenerationButton(root = document) {
    const scope = root && root.isConnected ? root : composer() || document;
    const candidates = Array.from(scope.querySelectorAll('button, [role="button"]'))
      .filter(visible)
      .filter(el => !el.disabled && el.getAttribute('aria-disabled') !== 'true')
      .map(el => {
        const text = `${label(el)} ${el.textContent || ''}`.toLowerCase();
        const icons = iconText(el).join(' ');
        const cls = String(el.className || '').toLowerCase();
        const rect = el.getBoundingClientRect();
        const semantic = matchesLabel(text, 'startGeneration');
        const arrow = /arrow_forward|send|north_east/.test(icons);
        const flowGenerate = /generate-icon-button/.test(cls);
        const reject = /add|เพิ่มองค์ประกอบ|ล้างพรอมต์|clear|agent|settings|ตั้งค่า|menu/i.test(text)
          || /add-menu-trigger|settings-trigger|clear-button|agent-mode/.test(cls);
        return {
          el,
          rect,
          score: (semantic ? 100 : 0) + (arrow ? 80 : 0) + (flowGenerate ? 120 : 0) + (rect.right > window.innerWidth * 0.45 ? 12 : 0) - (reject ? 180 : 0),
        };
      })
      .filter(entry => entry.score >= 80)
      .sort((a, b) => b.score - a.score || b.rect.right - a.rect.right);
    return candidates[0]?.el || null;
  }
  const isDialogOpen = (root) => Boolean(root?.isConnected && visible(root));
  async function waitForDialogClosed(root, timeout = 3000) {
    return Boolean(await waitFor(() => !isDialogOpen(root), timeout));
  }
  function selectableMediaItems(root) {
    const scope = root && root.isConnected ? root : panel();
    if (!scope) return [];
    const scopeRect = scope.getBoundingClientRect?.() || { left: 0, width: window.innerWidth || 1 };
    const itemDescriptor = (el, img = null) => [
      img?.currentSrc || img?.src || '',
      img?.alt || '',
      img?.title || '',
      img?.getAttribute?.('aria-label') || '',
      label(el),
      el?.textContent || '',
    ].join(' ').toLowerCase();
    const isUploadedReferenceItem = (el, img = null) => /omnipost-ref-|zzz-omnipost-ref-|preview of|char[_-]|character|product[_-]|uploaded image|uploaded media|upload media|reference[_ -]?(image|photo|media)?|product[_ -]?(primary|angle|reference)|สินค้าอ้างอิง|รูปอ้างอิง|อัปโหลด|อัพโหลด/i
      .test(itemDescriptor(el, img));
    const isAssetListArea = (el, img = null) => {
      const rect = (el?.matches?.('img') ? img || el : el)?.getBoundingClientRect?.();
      if (!rect) return false;
      if (el?.closest?.('[role="listbox"], [role="list"], aside')) return true;
      const relativeLeft = rect.left - scopeRect.left;
      const largePreview = rect.width >= 96 && rect.height >= 96 && relativeLeft > scopeRect.width * 0.24;
      if (largePreview) return false;
      return relativeLeft <= scopeRect.width * 0.34;
    };
    const rowFor = (el) => {
      const img = el.matches?.('img') ? el : el.querySelector?.('img');
      let current = el;
      for (let depth = 0; current && current !== scope && depth < 6; depth += 1) {
        if (current.matches?.('[data-index], [role="option"], [role="gridcell"], [role="button"], button, li')) return current;
        const rect = current.getBoundingClientRect?.();
        const text = label(current);
        if (rect && rect.width >= 80 && rect.width <= Math.max(120, scopeRect.width * 0.42)
          && rect.height >= 24 && rect.height <= 96
          && (text || current.querySelector?.('img'))
          && isAssetListArea(current, img)) return current;
        current = current.parentElement;
      }
      return el;
    };
    const candidates = Array.from(scope.querySelectorAll('img, [data-index], [role="option"], [role="gridcell"], [role="button"], button, div'))
      .filter(el => !el.closest('flow-prompt-box, flow-prompt-box-settings'))
      .filter(el => !/upload media|upload image|อัปโหลด|อัพโหลด|add to prompt|เพิ่มไปยังพรอมต์|เพิ่มไปยังพรอมพ์/i.test(label(el).toLowerCase()))
      .filter(el => {
        const img = el.matches?.('img') ? el : el.querySelector?.('img');
        if (!img || !visible(img)) return false;
        const src = String(img.currentSrc || img.src || '');
        const marker = `${src} ${img.alt || ''} ${img.className || ''}`.toLowerCase();
        const rect = img.getBoundingClientRect?.() || { width: 0, height: 0 };
        const width = Number(img.naturalWidth || img.width || rect.width || 0);
        const height = Number(img.naturalHeight || img.height || rect.height || 0);
        return Boolean(src)
          && width >= 20
          && height >= 20
          && isAssetListArea(el, img)
          && !/avatar|profile|icon|logo|sprite|emoji|favicon/i.test(marker)
          && !isUploadedReferenceItem(el, img)
          && !/\b\d{1,3}\s?%\b|progress_activity|autorenew|hourglass/i.test(label(el));
      })
      .map(rowFor)
      .filter(visible)
      .filter(el => !isUploadedReferenceItem(el, el.matches?.('img') ? el : el.querySelector?.('img')))
      .filter((el, index, list) => el && list.indexOf(el) === index);
    return candidates.sort((a, b) => {
      const ai = Number.parseInt(a.getAttribute?.('data-index') || '', 10);
      const bi = Number.parseInt(b.getAttribute?.('data-index') || '', 10);
      if (Number.isFinite(ai) && Number.isFinite(bi) && ai !== bi) return ai - bi;
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      return ar.top - br.top || ar.left - br.left;
    });
  }
  function getTopReadyItem(dialog, targetUrl = '') {
    const refPattern = /omnipost-ref-|zzz-omnipost-ref-|preview of|char[_-]|character|product[_-]|reference|uploaded|upload media|upload image|ingredient|สินค้าอ้างอิง|รูปอ้างอิง|อัปโหลด|อัพโหลด/i;
    const isRef = (el) => refPattern.test([
      el?.textContent || '',
      el?.querySelector?.('img')?.alt || '',
      el?.querySelector?.('img')?.src || '',
    ].join(' '));
    const getSelectableRow = (el) =>
      el?.closest?.('[data-testid="virtuoso-item-list"] [data-index]')
      || el?.closest?.('[data-index]')
      || el?.closest?.('[role="option"]')
      || el?.closest?.('[role="gridcell"]')
      || el?.closest?.('[role="button"]')
      || el?.closest?.('figure')
      || el;
    const searchIn = (scope) => {
      if (!scope) return null;

      // 1. If targetUrl provided, search for exact URL match first!
      if (targetUrl) {
        const cleanTarget = String(targetUrl).split('?')[0].split('#')[0];
        const allImgs = Array.from(scope.querySelectorAll('img')).filter(visible);
        const matchedImg = allImgs.find(img => {
          const s = String(img.currentSrc || img.src || '');
          return s && (s === targetUrl || (cleanTarget.length > 20 && s.includes(cleanTarget)));
        });
        if (matchedImg) {
          const row = getSelectableRow(matchedImg);
          if (row && visible(row) && isItemReady(row)) return row;
        }
      }

      // 2. Search for items explicitly marked as Generated image
      const generatedImgs = Array.from(scope.querySelectorAll('img')).filter(img => {
        if (!visible(img)) return false;
        const alt = String(img.alt || '').toLowerCase();
        return /generated image|^generated\b/i.test(alt) && !isRef(img);
      });
      if (generatedImgs.length > 0) {
        const row = getSelectableRow(generatedImgs[0]);
        if (row && visible(row) && !isRef(row) && isItemReady(row)) return row;
      }

      // 3. Virtuoso items excluding references
      const virtuosoItems = Array.from(scope.querySelectorAll('[data-testid="virtuoso-item-list"] [data-index]'));
      const indexedItems = (virtuosoItems.length > 0 ? virtuosoItems : Array.from(scope.querySelectorAll('[data-index]')))
        .filter(visible)
        .filter(el => !isRef(el));
      if (indexedItems.length > 0) {
        return indexedItems
          .sort((a, b) => {
            const ai = parseInt(a.getAttribute('data-index'), 10);
            const bi = parseInt(b.getAttribute('data-index'), 10);
            const sa = Number.isFinite(ai) ? ai : Number.MAX_SAFE_INTEGER;
            const sb = Number.isFinite(bi) ? bi : Number.MAX_SAFE_INTEGER;
            if (sa !== sb) return sa - sb;
            const ar = a.getBoundingClientRect();
            const br = b.getBoundingClientRect();
            return ar.top - br.top || ar.left - br.left;
          })
          .find(isItemReady) || null;
      }

      // 4. All candidate rows excluding references
      const allItems = Array.from(scope.querySelectorAll('[role="option"], [role="gridcell"], [role="button"], img, div'))
        .filter(el => !el.closest('flow-prompt-box, flow-prompt-box-settings'))
        .filter(el => {
          const img = el.matches?.('img') ? el : el.querySelector?.('img');
          return img && visible(img);
        })
        .map(el => getSelectableRow(el))
        .filter(Boolean)
        .filter(visible)
        .filter(el => !isRef(el))
        .filter((el, i, list) => list.indexOf(el) === i);
      return allItems
        .sort((a, b) => {
          const ar = a.getBoundingClientRect();
          const br = b.getBoundingClientRect();
          return ar.top - br.top || ar.left - br.left;
        })
        .find(isItemReady) || null;
    };
    const scope = dialog && dialog.isConnected ? dialog : document;
    const result = searchIn(scope);
    if (result) return result;
    if (scope !== document) return searchIn(document);
    return null;
  }
  async function attachLatestFromFlow({ mode = 'frames', index = 0, timeoutMs = 15000, targetUrl = '' } = {}) {
    const attachMode = mode === 'frames' ? 'frames' : 'ingredients';
    const before = count(attachMode);
    const picker = await open({ mode: attachMode, index });
    if (!picker) return { ok: false, reason: 'modern_recent_media_menu_not_found', attachedReferenceCount: 0 };
    await scrollToTop(picker);
    await scrollToTop(document);
    await sleep(1500);
    const item = await waitFor(() => getTopReadyItem(picker, targetUrl), timeoutMs);
    if (!item) return { ok: false, reason: 'modern_recent_media_not_found', attachedReferenceCount: 0 };
    await sleep(1000);
    const stableItem = getTopReadyItem(picker, targetUrl) || item;
    try { stableItem.scrollIntoView({ behavior: 'instant', block: 'nearest', inline: 'nearest' }); } catch (_) {}
    await sleep(200);
    if (!stableItem.isConnected) return { ok: false, reason: 'modern_recent_item_disconnected', attachedReferenceCount: 0 };
    const clickTarget = stableItem.querySelector?.('[role="option"]')
      || stableItem.closest?.('[role="option"]')
      || stableItem.querySelector?.('img')
      || stableItem;
    clickTarget.click();
    await sleep(600);
    if (await waitForDialogClosed(picker, 1500)) {
      return { ok: true, selectedFromRecent: true, attachedReferenceCount: 1 };
    }
    const add = await waitFor(() => findAddToPromptButton(panel() || picker || document), 4000);
    if (add) {
      await click(add);
      await sleep(800);
      await waitForDialogClosed(picker, 7000);
      return { ok: true, selectedFromRecent: true, attachedReferenceCount: 1 };
    }
    return { ok: false, reason: 'modern_recent_add_to_prompt_failed', attachedReferenceCount: 0 };
  }
  async function handleAgreeDialog() {
    const agree = Array.from(document.querySelectorAll('button, [role="button"]'))
      .filter(visible)
      .find(el => /^(agree|accept|got it|ยอมรับ|ตกลง|เข้าใจแล้ว)$/i.test(label(el)));
    if (agree) await click(agree);
  }
  async function clearIngredients() {
    const box = composer();
    if (!box) return;
    for (let attempt = 0; attempt < 8; attempt++) {
      const chips = Array.from(box.querySelectorAll('flow-ingredient-bar button, flow-ingredient-bar [role="button"]'))
        .filter(b => visible(b) && (/remove|delete|close|clear|ลบ|ปิด/i.test(label(b)) || iconText(b).includes('close')));
      if (chips.length === 0) break;
      for (const btn of chips) {
        await click(btn);
        await sleep(200);
      }
    }
  }
  async function open({ mode = 'ingredients', index = 0 } = {}) {
    const existing = panel();
    if (existing && visible(existing)) return existing;
    const trigger = mode === 'frames'
      ? findFrameTarget(index)
      : findIngredientTarget();
    if (!trigger) return null;
    await click(trigger);
    await sleep(800);
    await handleAgreeDialog();
    return waitFor(panel, 7000);
  }
  async function chooseFile(upload, file) {
    // Angular creates a detached file input. Capture it in MAIN world before
    // the native picker opens, then restore the prototypes on every exit.
    const proto = HTMLInputElement.prototype;
    const originalClick = proto.click;
    const originalPicker = proto.showPicker;
    let input;
    const intercept = (original) => function(...args) {
      if (this.type === 'file') { input = this; return; }
      return original?.apply(this, args);
    };
    const originalOpenFilePicker = window.showOpenFilePicker;
    const blockNativeFileClick = (event) => {
      if (event.target?.tagName === 'INPUT' && event.target?.type === 'file') {
        input = event.target;
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    };
    try {
      proto.click = intercept(originalClick);
      if (originalPicker) proto.showPicker = intercept(originalPicker);
      if (originalOpenFilePicker) window.showOpenFilePicker = async () => [];
      document.addEventListener('click', blockNativeFileClick, true);
      upload.click();
      await sleep(500);
      if (!input) {
        input = document.querySelector('input[type="file"]:not([data-omnipost-intercepted])');
      }
      if (!input) throw new Error('modern_file_input_not_captured');
    } finally {
      proto.click = originalClick;
      if (originalPicker) proto.showPicker = originalPicker;
      if (originalOpenFilePicker) window.showOpenFilePicker = originalOpenFilePicker;
      document.removeEventListener('click', blockNativeFileClick, true);
    }
    try { input.value = ''; } catch (_) {}
    const transfer = new DataTransfer();
    transfer.items.add(file);
    try {
      input.files = transfer.files;
    } catch (_) {
      Object.defineProperty(input, 'files', { configurable: true, value: transfer.files });
    }
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
  }
  async function attach(references, { timeoutMs = 60000, mode = 'ingredients', preferRecent = false, forceUpload = false, targetUrl = '' } = {}) {
    if (globalThis.__omniModernReferenceBusy) return { ok: false, reason: 'reference_upload_already_running' };
    globalThis.__omniModernReferenceBusy = true;
    const attachMode = mode === 'frames' ? 'frames' : 'ingredients';
    let attachedReferenceCount = 0;
    try {
      if (!composer()) throw new Error('modern_composer_not_found');
      // If there are leftover ingredients in the bar, clear them cleanly!
      if (attachMode === 'ingredients' && countIngredients() > 0) {
        await clearIngredients();
        await sleep(400);
      }
      if (attachMode === 'frames' && count(attachMode) > 0) {
        throw new Error('modern_existing_references_clear_before_retry');
      }
      if (!forceUpload && (attachMode === 'frames' || preferRecent)) {
        const recent = await attachLatestFromFlow({ mode: attachMode, index: 0, timeoutMs: Math.min(20000, timeoutMs), targetUrl }).catch((error) => ({ ok: false, reason: error?.message || 'modern_recent_attach_failed' }));
        if (recent?.ok) return {
          ok: true,
          requestedReferenceCount: references.length,
          attachedReferenceCount: 1,
          selectedFromRecent: true,
        };
      }
      for (const [index, ref] of references.entries()) {
        if (!/^data:image\/[\w.+-]+;base64,/i.test(ref.dataUrl || '')) throw new Error('reference_files_not_ready');
        const [header, encoded] = ref.dataUrl.split(',');
        const type = header.slice(5, header.indexOf(';'));
        const ext = type.split('/')[1].replace(/[^a-z0-9]/gi, '') || 'png';
        const name = `zzz-omnipost-ref-${crypto.randomUUID()}-${index + 1}.${ext}`;
        const bytes = Uint8Array.from(atob(encoded), char => char.charCodeAt(0));
        const file = new File([bytes], name, { type });

        // Ensure any previous dialog is fully closed before opening the next
        const staleDialog = panel();
        if (staleDialog) {
          await waitForDialogClosed(staleDialog, 4000);
          await sleep(600);
        }

        const picker = await open({ mode: attachMode, index });
        if (!picker) throw new Error('modern_upload_menu_not_found');
        
        let upload = findUploadButton(picker) || findUploadButton(panel() || document);
        if (!upload) {
          await sleep(1000);
          upload = findUploadButton(picker) || findUploadButton(panel() || document);
        }

        if (!upload) {
          if (attachMode === 'frames') {
            const recent = await attachLatestFromFlow({ mode: attachMode, index, timeoutMs: Math.min(20000, timeoutMs), targetUrl }).catch(() => null);
            if (recent?.ok) {
              attachedReferenceCount += 1;
              continue;
            }
          }
          throw new Error(`modern_upload_button_not_found_ref_${index + 1}`);
        }

        const initialImageSrcs = new Set(Array.from(picker.querySelectorAll('img'))
          .map(img => String(img.currentSrc || img.src || ''))
          .filter(Boolean));
        await chooseFile(upload, file);

        // Match this upload's unique filename or newly appeared image
        const uploadedSelectionTarget = await waitFor(() => {
          const current = panel() || picker;
          if (!current) return null;
          const uploadedImage = Array.from(current.querySelectorAll('img')).find(img => {
            const alt = normalize(img.alt);
            const src = String(img.currentSrc || img.src || '');
            const isExactNamedUpload = alt.includes(name);
            const isNewReadyPreview = src && !initialImageSrcs.has(src)
              && !/spinner|progress|loading/i.test(`${alt} ${src}`);
            return (isExactNamedUpload || isNewReadyPreview)
              && img.complete
              && img.naturalWidth > 20
              && img.naturalHeight > 20
              && visible(img);
          });
          if (uploadedImage) {
            const option = uploadedImage.closest('[role="option"], [data-index], [role="gridcell"], button, [role="button"]');
            return option || uploadedImage;
          }
          const leaf = Array.from(current.querySelectorAll('[data-index], [role="option"], [role="gridcell"], [role="button"], button, span, div')).find(el => visible(el)
            && (normalize(el.textContent).includes(name) || Array.from(el.querySelectorAll('img')).some(img => normalize(img.alt).includes(name)))
            && !Array.from(el.children).some(child => (child.textContent || '').trim() === name));
          return leaf?.closest?.('[role="option"], [data-index], [role="gridcell"]') || leaf || null;
        }, Math.max(1000, Math.min(120000, timeoutMs)));
        if (!uploadedSelectionTarget) throw new Error(`reference_upload_${index + 1}_not_confirmed`);

        const stableUploaded = await waitForStableUploadReady(
          () => uploadedSelectionTarget?.isConnected ? uploadedSelectionTarget : null,
          Math.max(10000, Math.min(120000, timeoutMs)),
        );
        if (!stableUploaded) throw new Error(`reference_upload_${index + 1}_not_ready`);
        await click(stableUploaded.target);
        await sleep(600);

        const activePicker = panel() || picker;
        if (await waitForDialogClosed(activePicker, 600)) {
          if (!await waitFor(() => count(attachMode) >= index + 1
            && (attachMode === 'frames' || ingredientMediaReady()), 8000)) {
            throw new Error(`add_reference_${index + 1}_to_prompt_failed`);
          }
          attachedReferenceCount += 1;
          await sleep(600);
          continue;
        }

        const stablePreview = await waitForStableUploadReady(
          () => {
            const current = panel();
            if (!current) return null;
            const named = Array.from(current.querySelectorAll('img')).find((img) =>
              normalize(img.alt).includes(name) && visible(img));
            if (named) return named;
            const newImage = Array.from(current.querySelectorAll('img')).find((img) => {
              const src = String(img.currentSrc || img.src || '');
              return src && !initialImageSrcs.has(src) && visible(img);
            });
            return newImage || uploadedSelectionTarget;
          },
          Math.max(10000, Math.min(120000, timeoutMs)),
          { requireAddButton: true },
        );
        if (!stablePreview?.add) throw new Error(`add_reference_${index + 1}_button_not_ready`);
        await click(stablePreview.add);
        await sleep(800);

        if (!await waitForDialogClosed(activePicker, 7000)) {
          const retryAdd = findAddToPromptButton(panel() || activePicker);
          if (retryAdd) await click(retryAdd);
        }
        if (!await waitForDialogClosed(activePicker, 4000)) {
          throw new Error(`add_reference_${index + 1}_dialog_not_closed`);
        }
        if (!await waitFor(() => count(attachMode) >= index + 1
          && (attachMode === 'frames' || ingredientMediaReady()), 8000)) {
          throw new Error(`add_reference_${index + 1}_to_prompt_failed`);
        }
        attachedReferenceCount += 1;
        await sleep(800);
      }
      return { ok: true, requestedReferenceCount: references.length, attachedReferenceCount };
    } catch (error) {
      return { ok: false, reason: error.message, requestedReferenceCount: references.length, attachedReferenceCount };
    } finally {
      globalThis.__omniModernReferenceBusy = false;
    }
  }
  async function fillPrompt(text) {
    const editor = composer()?.querySelector('flow-rich-text-editor .ProseMirror[contenteditable="true"]');
    if (!visible(editor) || !String(text || '').trim()) return { ok: false, err: 'modern_prompt_not_ready' };
    const beforeIngredients = countIngredients();
    const beforeFrames = countFrames();
    editor.focus();
    showClickRipple(editor);
    const range = document.createRange();
    range.selectNodeContents(editor);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('insertText', false, text);
    await sleep(300);
    const normalize = value => String(value).replace(/\s+/g, ' ').trim();
    if (normalize(editor.innerText) !== normalize(text) || countIngredients() !== beforeIngredients || countFrames() !== beforeFrames) return { ok: false, err: 'modern_prompt_verification_failed' };
    if (!await waitFor(() => findStartGenerationButton(composer()) || buttonAny(composer(), 'startGeneration') || button(composer(), 'Start generation'), 5000)) return { ok: false, err: 'modern_generate_not_ready' };
    return { ok: true, method: 'prosemirror_native_input' };
  }
  globalThis.OmniPostFlowModernReference = { attach, attachLatestFromFlow, fillPrompt, count, countFrames, countIngredients, findStartGenerationButton };
})();
