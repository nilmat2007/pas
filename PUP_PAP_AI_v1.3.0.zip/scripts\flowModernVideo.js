(() => {
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
  const HUMAN_CLICK_LEAD_MS = 200;
  const SETTING_SETTLE_MS = 400;
  const PANEL_SETTLE_MS = 500;
  const MENU_SETTLE_MS = 400;
  const visible = (el) => Boolean(el?.isConnected && el.getBoundingClientRect().width > 0 && el.getBoundingClientRect().height > 0);
  const enabled = (el) => el && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && !el.hasAttribute('data-disabled');
  const normalize = (value) => String(value || '').replace(/\s+/g, ' ').trim();
  const label = (el) => {
    const copy = el?.cloneNode?.(true);
    copy?.querySelectorAll?.('svg, i, mat-icon, [aria-hidden="true"]').forEach(icon => icon.remove());
    return normalize(el?.getAttribute?.('aria-label') || el?.getAttribute?.('mattooltip') || copy?.textContent || el?.textContent || el?.getAttribute?.('title') || '');
  };
  const composer = () => Array.from(document.querySelectorAll('flow-prompt-box')).find(visible);
  const deep = (selector, root = document) => {
    const found = Array.from(root.querySelectorAll(selector));
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) found.push(...deep(selector, el.shadowRoot));
    }
    return found;
  };
  const controls = (root = document) => deep('button, [role="radio"], [role="tab"], [role="button"], [aria-haspopup="menu"]', root).filter(visible);
  const selected = (el) => ['aria-selected', 'aria-pressed', 'aria-checked', 'data-selected'].some(key => el?.getAttribute?.(key) === 'true')
    || /^(active|on|checked)$/.test(el?.getAttribute?.('data-state') || '')
    || Boolean(el?.closest('mat-button-toggle')?.classList.contains('mat-button-toggle-checked'))
    || Boolean(el?.classList?.contains('mat-button-toggle-checked'));
  const compact = (value) => normalize(value).toLowerCase().replace(/[\[\]()_\-]+/g, ' ').replace(/\s+/g, ' ').trim();
  const FLOW_LABELS = {
    settings: [/^settings$/i, /settings trigger/i, /generation settings/i, /ตั้งค่า/i, /การตั้งค่า/i, /ตั้งค่าการสร้าง/i],
    video: [/^video$/i, /^videos$/i, /วิดีโอ/i, /วิดิโอ/i],
    image: [/^image$/i, /^images$/i, /รูปภาพ/i, /^ภาพ$/i, /^รูป$/i],
    frames: [/frame/i, /frames/i, /เฟรม/i, /ภาพเริ่ม.*ภาพจบ/i, /เริ่ม.*จบ/i, /เริ่ม.*สิ้นสุด/i, /สิ้นสุด.*เริ่ม/i],
    ingredients: [/ingredient/i, /ingredients/i, /วัตถุดิบ/i, /ส่วนประกอบ/i, /องค์ประกอบ/i, /ภาพอ้างอิง/i],
  };
  const matchesLabel = (text, key) => FLOW_LABELS[key].some((pattern) => pattern.test(compact(text)));
  const showClickRipple = (el) => {
    const rect = el?.getBoundingClientRect?.();
    if (!rect || rect.width <= 0 || rect.height <= 0) return;
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const ripple = document.createElement('div');
    ripple.setAttribute('data-omnipost-click-ripple', 'gold');
    ripple.style.cssText = `position:fixed;left:${cx}px;top:${cy}px;width:0;height:0;border-radius:50%;background:rgba(234,179,8,0.45);transform:translate(-50%,-50%);pointer-events:none;z-index:999999;transition:all 0.6s ease-out;box-shadow:0 0 12px 4px rgba(234,179,8,0.25);`;
    document.body.appendChild(ripple);
    globalThis.__omniGoldClickCount = Number(globalThis.__omniGoldClickCount || 0) + 1;
    requestAnimationFrame(() => {
      ripple.style.width = '60px';
      ripple.style.height = '60px';
      ripple.style.opacity = '0';
    });
    setTimeout(() => { try { ripple.remove(); } catch (_) {} }, 800);
  };
  const click = async (el) => {
    if (!el) return;
    el.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'instant' });
    el.focus?.();
    showClickRipple(el);
    const rect = el.getBoundingClientRect();
    const eventInit = { bubbles: true, cancelable: true, composed: true, pointerType: 'mouse', button: 0, buttons: 1, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
    el.dispatchEvent(new PointerEvent('pointerdown', eventInit));
    el.dispatchEvent(new MouseEvent('mousedown', eventInit));
    await sleep(60);
    el.dispatchEvent(new PointerEvent('pointerup', { ...eventInit, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('mouseup', { ...eventInit, buttons: 0 }));
    await sleep(HUMAN_CLICK_LEAD_MS);
    el.click();
    await sleep(SETTING_SETTLE_MS);
  };
  async function waitFor(get, timeout = 10000) {
    const end = Date.now() + timeout;
    do {
      const value = await get();
      if (value) return value;
      await sleep(150);
    } while (Date.now() < end);
    return null;
  }
  const findPanel = () => {
    // 1. Exact Google Flow Angular settings component (matching Kubdee's getOpenConfigPopper)
    const flowSettings = Array.from(document.querySelectorAll('.cdk-overlay-pane flow-prompt-box-settings, flow-prompt-box-settings'))
      .find(visible);
    if (flowSettings) return flowSettings;

    // 2. Open popover / dialog containers
    const candidates = Array.from(document.querySelectorAll([
      '.cdk-overlay-pane:has(button)',
      '[data-radix-menu-content][data-state="open"]',
      '[role="menu"][data-state="open"]',
      '[data-radix-popper-content-wrapper] [data-state="open"]',
      '[role="dialog"][data-state="open"]',
      '[role="dialog"]',
    ].join(','))).filter(visible);

    for (const panel of candidates) {
      const text = (panel.textContent || '').toLowerCase();
      if ((text.includes('image') || text.includes('ภาพ')) && (text.includes('video') || text.includes('วิดีโอ'))) {
        return panel;
      }
    }
    return candidates[0] || null;
  };
  const findSettingsTrigger = () => {
    // Prefer the exact Angular trigger used by Google Flow. Kubdee v4.9.6
    // resolves this before any heuristic search, which avoids accidentally
    // choosing another summary/button near the composer.
    const exactMaterialTrigger = deep('button[aria-label="Settings trigger"], button.settings-trigger-button[cdkoverlayorigin]')
      .find(btn => visible(btn) && enabled(btn));
    if (exactMaterialTrigger) return exactMaterialTrigger;
    const box = composer();
    const editor = box?.querySelector('textarea, [contenteditable="true"]');
    const editorRect = editor?.getBoundingClientRect?.();
    return controls(box || document)
      .filter(btn => enabled(btn) && !btn.closest('flow-prompt-box-settings, flow-add-menu-popover-content'))
      .filter(btn => {
        const text = label(btn).toLowerCase();
        const rawText = (btn.textContent || '').toLowerCase();
        const isSummary = /\b(video|image|nano banana|veo|omni|imagen)\b|วิดีโอ|วิดิโอ|รูปภาพ|ภาพ/.test(text)
          && (/\d+\s*s|\d+\s*วิ|\d+\s*วินาที|\d+p|x\s*[1-4]|\b[1-4]x\b|9:16|16:9|1:1/.test(text) || /\b(nano banana|veo|omni)\b/.test(rawText));
        const isSettings = matchesLabel(text, 'settings')
          || Array.from(btn.querySelectorAll('i, mat-icon, .google-symbols, .material-symbols-outlined, span')).some(icon => /^(tune|instant_mix|crop_\w+|settings)$/.test(normalize(icon.textContent).toLowerCase()));
        if (!isSummary && !isSettings) return false;
        if (!editorRect) return true;
        const rect = btn.getBoundingClientRect();
        return rect.top >= editorRect.top - 60 && rect.top < editorRect.bottom + 180;
      })
      .sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right)[0] || null;
  };
  async function openSettings() {
    const current = findPanel();
    if (current) return current;
    const trigger = await waitFor(findSettingsTrigger, 15000);
    if (!trigger) return null;
    await click(trigger);
    const panel = await waitFor(findPanel, 8000);
    if (panel) await sleep(PANEL_SETTLE_MS);
    return panel;
  }
  async function closeSettingsPanel() {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const panel = findPanel();
      if (!panel) return true;
      const trigger = findSettingsTrigger();
      if (trigger && attempt === 0) {
        await click(trigger);
        await sleep(350);
        if (!findPanel()) return true;
      }
      // Google Flow renders the settings sheet in Angular CDK. On builds
      // where clicking the trigger again is ignored, clicking the active
      // backdrop is the reliable close path used by Kubdee v4.9.6.
      const backdrop = deep('.cdk-overlay-backdrop.cdk-overlay-backdrop-showing')
        .find(visible);
      if (backdrop) {
        try {
          showClickRipple(backdrop);
          backdrop.click();
        } catch (_) {}
        await sleep(350);
        if (!findPanel()) return true;
      }
      const keyInit = { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true, composed: true };
      const target = document.activeElement && document.activeElement !== document.body
        ? document.activeElement
        : (panel.querySelector('button, [role="button"], [tabindex]') || panel);
      for (const node of [target, panel, document.body, document, window]) {
        try { node.dispatchEvent(new KeyboardEvent('keydown', keyInit)); } catch (_) {}
        try { node.dispatchEvent(new KeyboardEvent('keyup', keyInit)); } catch (_) {}
      }
      await sleep(220);
      if (!findPanel()) return true;
      try { document.body.click(); } catch (_) {}
      await sleep(220);
      if (!findPanel()) return true;
      const box = composer();
      const editor = box?.querySelector('textarea, [contenteditable="true"]');
      const rect = editor?.getBoundingClientRect?.() || box?.getBoundingClientRect?.();
      if (rect) {
        const x = Math.max(8, Math.min(window.innerWidth - 8, rect.left + 10));
        const y = Math.max(8, Math.min(window.innerHeight - 8, rect.bottom + 8));
        const outside = document.elementFromPoint(x, y) || document.body;
        const pointerInit = { bubbles: true, cancelable: true, composed: true, pointerType: 'mouse', button: 0, buttons: 1, clientX: x, clientY: y };
        try { outside.dispatchEvent(new PointerEvent('pointerdown', pointerInit)); } catch (_) {}
        try { outside.dispatchEvent(new MouseEvent('mousedown', pointerInit)); } catch (_) {}
        try { outside.dispatchEvent(new PointerEvent('pointerup', { ...pointerInit, buttons: 0 })); } catch (_) {}
        try { outside.dispatchEvent(new MouseEvent('mouseup', { ...pointerInit, buttons: 0 })); } catch (_) {}
        try { outside.click?.(); } catch (_) {}
        await sleep(260);
        if (!findPanel()) return true;
      }
      if (trigger && attempt >= 2) {
        await click(trigger);
        await sleep(350);
        if (!findPanel()) return true;
      }
    }
    return !findPanel();
  }
  async function chooseByText(panel, matcher, { required = false } = {}) {
    const target = controls(panel).find(btn => enabled(btn) && matcher(label(btn), btn));
    if (!target) {
      if (required) throw new Error('modern_video_setting_not_found');
      return false;
    }
    if (!selected(target)) {
      await click(target);
      await sleep(SETTING_SETTLE_MS);
      await waitFor(() => selected(target) || !visible(target), 2500);
    }
    return true;
  }
  const modelTargets = (payload) => {
    const raw = compact(`${payload.modelLabel || ''} ${payload.model || ''}`);
    if (!raw) return [];
    if (/veo\s*3\.?1|veo\s*31|veo_?31/i.test(raw)) {
      if (/lower\s*priority|lower_priority|low\s*priority/i.test(raw)) {
        return [['veo', '3.1', 'lite', 'lower', 'priority'], ['veo', '31', 'lite', 'lower', 'priority']];
      }
      if (/fast/i.test(raw)) return [['veo', '3.1', 'fast'], ['veo', '31', 'fast']];
      if (/quality/i.test(raw)) return [['veo', '3.1', 'quality'], ['veo', '31', 'quality']];
      if (/lite/i.test(raw)) return [['veo', '3.1', 'lite'], ['veo', '31', 'lite']];
    }
    if (/omni.*flash|omni_flash/i.test(raw)) return [['omni', 'flash']];
    return [raw.split(/\s+/).filter(Boolean)];
  };
  const modelScore = (text, targetGroups) => {
    const value = compact(text).replace(/\b3\s+1\b/g, '3.1');
    let best = 0;
    for (const tokens of targetGroups) {
      const normalizedTokens = tokens.map(token => compact(token)).filter(Boolean);
      const hasAll = normalizedTokens.every(token => value.includes(token));
      if (!hasAll) continue;
      let score = 10 + normalizedTokens.length;
      const wantsLower = normalizedTokens.includes('lower') && normalizedTokens.includes('priority');
      if (wantsLower) score += value.includes('lower') && value.includes('priority') ? 50 : -100;
      if (!wantsLower && value.includes('lower') && value.includes('priority')) score -= 25;
      if (value.replace(/\s+/g, '') === normalizedTokens.join('').replace(/\s+/g, '')) score += 20;
      best = Math.max(best, score);
    }
    return best;
  };
  const modelMatches = (text, targetGroups) => modelScore(text, targetGroups) > 0;
  const isModelDropdown = (btn) => {
    if (!enabled(btn) || !btn.matches?.('button[aria-haspopup="menu"], [aria-haspopup="menu"]')) return false;
    const text = compact(`${label(btn)} ${btn.textContent || ''} ${btn.getAttribute?.('aria-label') || ''}`);
    // aria-haspopup already distinguishes the trigger from ordinary labels.
    // Do not require Flow's arrow icon: Angular may render it in a sibling or
    // shadow root even though this is still the real model menu trigger.
    return /veo|omni|model|select model|nano|imagen|โมเดล|กลุ่มผลิตภัณฑ์|เลือกกลุ่มผลิตภัณฑ์/.test(text);
  };
  async function chooseModel(panel, payload) {
    const targets = modelTargets(payload);
    if (!targets.length) return true;
    const dropdown = controls(panel).find(isModelDropdown);
    if (!dropdown) return false;
    // A positive score already means every required token matched. The old
    // >= 50 threshold was only reachable by the special Lower Priority bonus,
    // so a correctly selected "Omni 1.1 Flash" was reported as not selected.
    if (modelMatches(`${label(dropdown)} ${dropdown.textContent || ''}`, targets)) return true;
    await click(dropdown);
    await sleep(MENU_SETTLE_MS);
    const target = await waitFor(() => deep('[role="menuitem"], [role="option"], button')
      .filter(item => visible(item) && enabled(item))
      .map(item => ({ item, score: modelScore(label(item) || item.textContent, targets) }))
      .filter(entry => entry.score > 0)
      .sort((a, b) => b.score - a.score)[0]?.item, 5000);
    if (target) {
      await click(target.querySelector?.('button') || target);
      await sleep(PANEL_SETTLE_MS);
      return Boolean(await waitFor(() => {
        const currentDropdown = controls(findPanel() || panel).find(isModelDropdown) || dropdown;
        return modelMatches(`${label(currentDropdown)} ${currentDropdown?.textContent || ''}`, targets);
      }, 3000));
    }
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true, composed: true }));
    return false;
  }
  async function ensureSettings(payload = {}) {
    let panel = await openSettings();
    if (!panel) throw new Error('modern_video_settings_not_found');

    // Video Mode Tab: Match by text "VIDEO", "วิดีโอ", aria attributes, or icons (play_circle, videocam)
    const isVideoTab = (text, btn) => {
      const t = String(text || '').toLowerCase();
      const txt = (btn?.textContent || '').toLowerCase();
      const aria = (btn?.getAttribute('aria-label') || btn?.getAttribute('aria-controls') || '').toLowerCase();
      const icons = Array.from(btn?.querySelectorAll('i, mat-icon, .google-symbols, .material-symbols-outlined, span') || []).map(i => (i.textContent || '').trim().toLowerCase()).join(' ');
      return matchesLabel(t, 'video') || matchesLabel(txt, 'video') || matchesLabel(aria, 'video')
        || ['play_circle', 'videocam', 'movie'].some(ic => icons.includes(ic));
    };
    await chooseByText(panel, isVideoTab, { required: true });
    panel = findPanel() || panel;
    await sleep(PANEL_SETTLE_MS);

    const mode = String(payload.referenceMode || '').toLowerCase();
    const rawModel = compact(`${payload.modelLabel || ''} ${payload.model || ''}`);
    const isOmniFlash = /omni.*flash|omni_flash/i.test(rawModel);
    // Kubdee's modern Flow path uses Frames for Veo image-to-video and keeps
    // Ingredients only for Omni Flash or an explicit forced override.
    const wantsIngredients = mode === 'ingredients'
      || (mode !== 'frames' && mode !== 'frames_start_end' && isOmniFlash);
    const isFramesOrIngredients = (text, btn) => {
      const t = String(text || '').toLowerCase();
      const txt = (btn?.textContent || '').toLowerCase();
      const aria = (btn?.getAttribute('aria-label') || btn?.getAttribute('aria-controls') || '').toLowerCase();
      const key = wantsIngredients ? 'ingredients' : 'frames';
      return matchesLabel(t, key) || matchesLabel(txt, key) || matchesLabel(aria, key);
    };
    await chooseByText(panel, isFramesOrIngredients);
    panel = findPanel() || panel;
    await sleep(PANEL_SETTLE_MS);

    // Keep the proven v1.2.7 order: choose the requested model immediately
    // after Frames/Ingredients, before the remaining video settings.
    if (!await chooseModel(panel, payload)) throw new Error('modern_video_model_not_selected');
    panel = findPanel() || panel;
    await sleep(PANEL_SETTLE_MS);

    const aspect = String(payload.aspect || payload.aspectLabel || '9:16').toLowerCase();
    const targetAspect = aspect.includes('16:9') || aspect.includes('landscape') ? '16:9'
      : aspect.includes('1:1') || aspect.includes('square') ? '1:1'
        : '9:16';
    const isAspect = (text, btn) => {
      const t = String(text || '').toLowerCase();
      const txt = (btn?.textContent || '').toLowerCase();
      const icons = Array.from(btn?.querySelectorAll('i, mat-icon, .material-icons, .google-symbols, .material-symbols-outlined, span') || []).map(i => (i.textContent || '').trim().toLowerCase()).join(' ');
      const iconTarget = targetAspect.replace(':', '_');
      const html = (btn?.innerHTML || '').toLowerCase();
      return t.includes(targetAspect) || txt.includes(targetAspect) || icons.includes(iconTarget) || html.includes(`crop_${iconTarget}`);
    };
    await chooseByText(panel, isAspect);
    panel = findPanel() || panel;
    await sleep(SETTING_SETTLE_MS);

    if (payload.resolution) {
      const targetResolution = normalize(payload.resolution).toLowerCase();
      await chooseByText(panel, text => text.toLowerCase() === targetResolution);
      panel = findPanel() || panel;
      await sleep(SETTING_SETTLE_MS);
    }

    const durationSec = Number(payload.duration || 8);
    const isDuration = (text, btn) => {
      const t = String(text || '').toLowerCase();
      const txt = (btn?.textContent || '').toLowerCase();
      return t.includes(`${durationSec}s`)
        || txt.includes(`${durationSec}s`)
        || t.includes(`${durationSec} วิ`)
        || txt.includes(`${durationSec} วิ`)
        || t.includes(`${durationSec} วินาที`)
        || txt.includes(`${durationSec} วินาที`)
        || t.includes(`${durationSec}วินาที`)
        || txt.includes(`${durationSec}วินาที`)
        || t.trim() === String(durationSec)
        || txt.trim() === String(durationSec);
    };
    await chooseByText(panel, isDuration);
    panel = findPanel() || panel;
    await sleep(SETTING_SETTLE_MS);

    const countNum = Math.max(1, Math.min(4, Number(payload.outputCount || 1)));
    const isCount = (text, btn) => {
      const t = String(text || '').toLowerCase();
      const txt = (btn?.textContent || '').toLowerCase();
      return t.includes(`x${countNum}`) || txt.includes(`x${countNum}`) || t.trim() === String(countNum) || txt.trim() === String(countNum);
    };
    await chooseByText(panel, isCount);
    panel = findPanel() || panel;
    await sleep(SETTING_SETTLE_MS);

    // Some Flow builds can reset the model while another setting changes.
    // Re-check at the end and only click the model menu again when it no
    // longer matches, so the normal Motion 5 path stays identical to v1.2.7.
    const requestedModelTargets = modelTargets(payload);
    const currentModelDropdown = controls(panel).find(isModelDropdown);
    const requestedModelStillSelected = requestedModelTargets.length === 0
      || (currentModelDropdown && modelMatches(
        `${label(currentModelDropdown)} ${currentModelDropdown.textContent || ''}`,
        requestedModelTargets
      ));
    if (!requestedModelStillSelected) {
      if (!await chooseModel(panel, payload)) throw new Error('modern_video_model_not_selected');
      panel = findPanel() || panel;
      await sleep(PANEL_SETTLE_MS);
    }

    const closed = await closeSettingsPanel();
    if (!closed) {
      const trigger = findSettingsTrigger();
      const rect = trigger?.getBoundingClientRect?.();
      const error = new Error('modern_video_settings_not_closed');
      if (rect && rect.width > 0 && rect.height > 0) {
        error.closePoint = {
          x: Math.round(rect.left + rect.width / 2),
          y: Math.round(rect.top + rect.height / 2),
        };
      }
      throw error;
    }
    return { ok: true };
  }
  async function continueAfterSettings(payload = {}) {
    const references = (Array.isArray(payload.referenceImages) ? payload.referenceImages : [])
      .filter(ref => /^data:image\/[\w.+-]+;base64,/i.test(ref?.dataUrl || ''));
    if (!references.length && !payload.preferRecentFlowImage) return { ok: false, reason: 'modern_video_reference_files_not_ready' };
    try {
      const rawModel = compact(`${payload.modelLabel || ''} ${payload.model || ''}`);
      const requestedMode = String(payload.referenceMode || '').toLowerCase();
      const modernReferenceMode = requestedMode === 'ingredients'
        ? 'ingredients'
        : (requestedMode === 'frames' || requestedMode === 'frames_start_end'
          ? 'frames'
          : (/omni.*flash|omni_flash/i.test(rawModel) || payload.forceModernIngredients === true ? 'ingredients' : 'frames'));
      const attachment = await globalThis.OmniPostFlowModernReference.attach(references, {
        mode: modernReferenceMode,
        preferRecent: modernReferenceMode === 'frames' || payload.preferRecentFlowImage === true,
        forceUpload: payload.forceUploadReferenceImage === true,
        targetUrl: payload.targetImageUrl || payload.targetUrl || '',
      });
      if (!attachment.ok) return attachment;
      const prompt = await globalThis.OmniPostFlowModernReference.fillPrompt(payload.prompt);
      if (!prompt.ok) return { ok: false, reason: prompt.err || 'modern_video_prompt_failed', attachedReferenceCount: attachment.attachedReferenceCount };
      return {
        ok: true,
        attachedReferenceCount: attachment.attachedReferenceCount,
        requestedReferenceCount: references.length,
        promptMethod: prompt.method,
      };
    } catch (error) {
      return { ok: false, reason: error.message, closePoint: error.closePoint || null };
    }
  }
  async function run(payload = {}) {
    if (location.hostname !== 'flow.google.com') return { ok: false, reason: 'modern_flow_composer_not_found' };
    const composerReady = await waitFor(composer, 15000);
    if (!composerReady) return { ok: false, reason: 'modern_flow_composer_not_found' };
    if (!globalThis.OmniPostFlowModernReference) return { ok: false, reason: 'modern_reference_helper_missing' };
    try {
      await ensureSettings(payload);
    } catch (error) {
      return { ok: false, reason: error.message, closePoint: error.closePoint || null };
    }
    return continueAfterSettings(payload);
  }
  globalThis.OmniPostFlowModernVideo = { run, continueAfterSettings, ensureSettings, closeSettingsPanel, findPanel, findSettingsTrigger };
})();
