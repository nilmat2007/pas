// Shared same-project recovery for image and video generation.
(() => {
  async function run({ kind, waitOnce, inspect, guard, retryNative, confirm, accepted,
    finish, log, sleep, stopped = () => false, random = Math.random }) {
    let last = null;
    const label = kind === 'video' ? 'วิดีโอ' : 'รูปภาพ';
    const checkStop = () => { if (stopped()) throw new Error('stopped'); };
    for (let retry = 0; retry <= 3; retry++) {
      checkStop();
      last = await waitOnce(retry + 1);
      checkStop();
      const complete = last?.ok && (kind === 'video'
        ? last.video || last.videos?.length : last.images?.length);
      if (complete) { await finish(true, last); return last; }
      const state = await inspect(last);
      if (state.active) {
        const pending = { ok: false, reason: `${kind}_generation_wait_timeout_no_resubmit` };
        log('warn', `[Google Flow] ${label}ยังมีงานประมวลผลอยู่ เก็บโปรเจกต์เดิมไว้ ไม่ส่งงานซ้ำ`);
        await finish(false, pending);
        return pending;
      }
      if (!state.confirmed) {
        const pending = { ok: false, reason: `${kind}_generation_wait_timeout_no_resubmit` };
        log('warn', '[Google Flow] ยังยืนยัน Failed ไม่ได้ จึงไม่กด Retry');
        await finish(false, pending);
        return pending;
      }
      if (retry === 3) {
        last = { ok: false, skipProduct: true, reason: `flow_native_retry_exhausted:${last?.reason || 'failed'}` };
        break;
      }
      const waitMs = 5000 + Math.floor(random() * 5000);
      log('warn', `[Google Flow] ${label} Failed (${last?.reason || state.snapshot?.failedReason || ''}) รอ ${(waitMs / 1000).toFixed(1)} วินาที แล้วกด Retry ลูกศรวงกลม ${retry + 1}/3`);
      const safe = await guard(state, waitMs);
      checkStop();
      if (!safe.safe) {
        // Allow one result read after a state transition, without resubmission.
        last = await waitOnce(retry + 1);
        const completed = last?.ok && (kind === 'video' ? last.video || last.videos?.length : last.images?.length);
        const result = completed ? last : { ok: false, reason: `${kind}_generation_wait_timeout_no_resubmit` };
        await finish(Boolean(completed), result);
        return result;
      }
      const before = await inspect(last);
      if (before.active || !before.confirmed) {
        const result = { ok: false, reason: `${kind}_generation_wait_timeout_no_resubmit` };
        await finish(false, result);
        return result;
      }
      checkStop();
      const result = await retryNative(retry + 1, before);
      checkStop();
      if (!result?.ok) {
        last = { ok: false, reason: result?.reason || 'flow_native_retry_failed' };
        log('err', `[Google Flow] กด Retry ไม่สำเร็จ (${last.reason})`);
        break;
      }
      const confirmation = await confirm(before);
      checkStop();
      if (!confirmation?.accepted) {
        last = { ok: false, reason: `${kind}_generation_wait_timeout_no_resubmit:retry_acceptance_unverified` };
        log('warn', '[Google Flow] กดส่งแล้วแต่ยังยืนยันการรับงานไม่ได้ เก็บโปรเจกต์เดิมไว้ตรวจสอบ');
        break;
      }
      await accepted(retry + 1);
      log('info', `[Google Flow] Flow รับ Retry ${retry + 1}/3 แล้ว กำลังรอไฟล์${label}`);
      await sleep(2000 + Math.floor(random() * 2000));
    }
    const result = { ok: false, skipProduct: last?.skipProduct === true, reason: last?.reason || `${kind}_generation_no_result_after_retries` };
    if (result.skipProduct) log('warn', `[Google Flow] Retry ครบ 3 ครั้งแล้วยัง Failed ข้ามสินค้านี้ไปสินค้าถัดไป`);
    log('err', `[Google Flow] ${label}ไม่สำเร็จหลังจบการกู้คืนในโปรเจกต์เดิม (${result.reason})`);
    await finish(false, result);
    return result;
  }
  globalThis.OmniPostFlowRecovery = Object.freeze({ run });
})();
