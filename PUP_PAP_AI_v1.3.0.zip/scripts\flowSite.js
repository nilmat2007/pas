// Shared routing for the popup and service worker.
// Google Flow now uses the modern site only.
(() => {
  const storageKey = 'flowWebsite';
  const homes = Object.freeze({
    modern: 'https://flow.google.com/',
  });
  const normalize = () => 'modern';
  function siteOf(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== 'https:' || url.port) return null;
      if (url.hostname === 'flow.google.com') return 'modern';
    } catch (_) {}
    return null;
  }
  async function getSelected() {
    return 'modern';
  }
  async function getHomeUrl() {
    return homes.modern;
  }
  async function getHomeForTab(tabId) {
    const tab = await chrome.tabs.get(Number(tabId)).catch(() => null);
    const site = siteOf(tab?.url);
    return site ? homes[site] : homes.modern;
  }
  globalThis.OmniPostFlowSite = Object.freeze({
    storageKey, homes, normalize, siteOf, getSelected, getHomeUrl, getHomeForTab,
    isFlowUrl: (value) => siteOf(value) !== null,
    matchesSite: (value, site) => siteOf(value) === normalize(site),
  });
})();
