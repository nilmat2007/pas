/**
 * PhimBot i18n — Internationalization Module
 * Supports Thai and English with dynamic language switching
 */
window.PhimI18n = (function () {
  'use strict';

  let currentLang = 'th';
  let messages = {};
  let fallbackMessages = {};

  /**
   * Load messages for a specific language from _locales/{lang}/messages.json
   */
  async function loadMessages(lang) {
    try {
      const url = chrome.runtime.getURL(`_locales/${lang}/messages.json`);
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      console.warn(`[PhimI18n] Failed to load ${lang}:`, error);
      return {};
    }
  }

  /**
   * Initialize — load saved language or default to Thai
   */
  async function init() {
    try {
      const data = await chrome.storage.local.get('phimbot_language');
      currentLang = data.phimbot_language || 'th';
    } catch (_) {
      currentLang = 'th';
    }

    // Always load Thai as fallback
    fallbackMessages = await loadMessages('th');
    messages = currentLang === 'th' ? fallbackMessages : await loadMessages(currentLang);
  }

  /**
   * Get translated string by key
   * @param {string} key — message key
   * @param {...string} substitutions — replacement values for $1, $2, etc.
   * @returns {string}
   */
  function t(key, ...substitutions) {
    const entry = messages[key] || fallbackMessages[key];
    if (!entry) return key;

    let text = entry.message || key;

    // Replace placeholders like $COUNT$ → $1 → actual value
    if (entry.placeholders && substitutions.length > 0) {
      const placeholderNames = Object.keys(entry.placeholders);
      for (let i = 0; i < placeholderNames.length; i++) {
        const placeholder = entry.placeholders[placeholderNames[i]];
        const contentRef = placeholder.content; // e.g. "$1"
        const index = parseInt(contentRef.replace('$', ''), 10) - 1;
        if (index >= 0 && index < substitutions.length) {
          text = text.replace(`$${placeholderNames[i].toUpperCase()}$`, substitutions[index]);
        }
      }
    }

    // Direct $1, $2 replacement
    substitutions.forEach((sub, i) => {
      text = text.replace(`$${i + 1}`, sub);
    });

    return text;
  }

  /**
   * Switch language and persist choice
   */
  async function setLanguage(lang) {
    currentLang = lang;
    messages = lang === 'th' ? fallbackMessages : await loadMessages(lang);
    if (Object.keys(messages).length === 0) {
      messages = fallbackMessages;
      currentLang = 'th';
    }
    try {
      await chrome.storage.local.set({ phimbot_language: currentLang });
    } catch (_) { /* storage not available */ }
    applyToDOM();
  }

  /**
   * Get current language code
   */
  function getLanguage() {
    return currentLang;
  }

  /**
   * Apply translations to all DOM elements with [data-i18n] attribute
   * Optional: data-i18n-attr="placeholder" to set attribute instead of textContent
   */
  function applyToDOM() {
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      const attr = el.getAttribute('data-i18n-attr');
      const translated = t(key);

      if (attr) {
        el.setAttribute(attr, translated);
      } else {
        el.textContent = translated;
      }
    });
  }

  return { init, t, setLanguage, getLanguage, loadMessages, applyToDOM };
})();
