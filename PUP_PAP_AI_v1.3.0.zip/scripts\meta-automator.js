/**
 * PhimBot — Meta AI Automator v4
 * ────────────────────────────────────────────────────────────────
 * Fixed in v4:
 *   - typeText uses Lexical-compatible InputEvent (beforeinput + input)
 *   - attachImages: file input → clipboard paste → drag-drop (3 fallbacks)
 *   - submitMessage: send button + Enter only (no brute-force button scan)
 *   - MutationObserver: debounced, only checks <video> nodes (no body.innerText)
 *   - Video capture: safe blob fetch with timeout, size check before convert
 *   - Error detection: checks Meta AI error messages and reports back
 *   - processPrompt: sends completion result via chrome.runtime.sendMessage
 */

(function initPhimBotMetaAutomator() {
  if (window.__PHIMBOT_META_AUTOMATOR_LOADED__) return;
  window.__PHIMBOT_META_AUTOMATOR_LOADED__ = true;
  window.__META_AI_EXPORT_VIDEOS__ = window.__META_AI_EXPORT_VIDEOS__ || [];

  const log = (msg, ...args) => console.log(`[PhimBot Meta] ${msg}`, ...args);
  const capturedVideoSrcs = new Set();
  // ═══ Baseline: video srcs ที่มีอยู่ก่อนส่ง prompt → ข้ามไม่ capture ═══
  const baselineVideoSrcs = new Set();
  let activePromptTimestamp = 0;  // timestamp ตอนรับ prompt → ผูกกับ video ที่ capture

  log('🤖 Meta AI Automator v4.1 loaded on:', location.href);

  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  // ═══════════════════════════════════════════════════════════════
  //  UTILITIES
  // ═══════════════════════════════════════════════════════════════

  /** Convert base64 data URL → File object */
  function base64ToFile(base64, filename) {
    try {
      const arr = base64.split(',');
      const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/png';
      const bstr = atob(arr[1]);
      const u8arr = new Uint8Array(bstr.length);
      for (let i = 0; i < bstr.length; i++) u8arr[i] = bstr.charCodeAt(i);
      return new File([u8arr], filename, { type: mime });
    } catch (e) {
      log('❌ base64ToFile error:', e);
      return null;
    }
  }

  /** If src is a URL (not data:), fetch and convert to data URL in this context */
  async function ensureBase64(src, label) {
    if (!src) { log(`⚠️ ${label}: ว่างเปล่า`); return null; }
    if (src.startsWith('data:')) {
      log(`✅ ${label}: เป็น base64 แล้ว (${(src.length / 1024).toFixed(0)} KB)`);
      return src;
    }
    log(`⚠️ ${label}: เป็น URL ดิบ → ลอง fetch...`);
    try {
      const resp = await fetch(src);
      if (!resp.ok) { log(`❌ ${label}: fetch failed HTTP ${resp.status}`); return null; }
      const blob = await resp.blob();
      return await new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => { log(`✅ ${label}: แปลง base64 สำเร็จ (${(reader.result.length / 1024).toFixed(0)} KB)`); resolve(reader.result); };
        reader.onerror = () => { log(`❌ ${label}: FileReader error`); resolve(null); };
        reader.readAsDataURL(blob);
      });
    } catch (e) {
      log(`❌ ${label}: fetch error: ${e.message}`);
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  //  FIND INPUT
  // ═══════════════════════════════════════════════════════════════

  function isVisible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && el.offsetParent !== null;
  }

  function findInput() {
    // Priority: Lexical editor → contenteditable textbox → textarea
    for (const sel of [
      'div[contenteditable="true"][data-lexical-editor]',
      'div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"]',
    ]) {
      for (const el of document.querySelectorAll(sel)) {
        if (isVisible(el) && el.getBoundingClientRect().height > 10) return el;
      }
    }
    const ta = document.querySelector('textarea');
    if (ta && isVisible(ta)) return ta;
    return null;
  }

  // ═══════════════════════════════════════════════════════════════
  //  FIND SEND BUTTON
  // ═══════════════════════════════════════════════════════════════

  function findSendButton() {
    // 1. aria-label match
    for (const sel of [
      'button[aria-label*="Send" i]',
      'button[aria-label*="Submit" i]',
      'button[aria-label*="ส่ง"]',
      'div[role="button"][aria-label*="Send" i]',
    ]) {
      const btn = document.querySelector(sel);
      if (btn && isVisible(btn)) return btn;
    }

    // 2. SVG button near bottom of screen with colored background (Meta AI send button pattern)
    const allBtns = [...document.querySelectorAll('button')].filter(isVisible);
    for (const btn of allBtns) {
      if (!btn.querySelector('svg')) continue;
      const r = btn.getBoundingClientRect();
      if (r.bottom < window.innerHeight * 0.6 || r.width > 55 || r.height > 55) continue;
      const bg = getComputedStyle(btn).backgroundColor;
      if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent' && bg !== 'rgb(255, 255, 255)') {
        return btn;
      }
    }

    return null;
  }

  // ═══════════════════════════════════════════════════════════════
  //  TYPE TEXT (Lexical-compatible)
  // ═══════════════════════════════════════════════════════════════

  function typeText(input, text) {
    input.focus();

    if (input.isContentEditable) {
      // Clear existing content
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(input);
      sel.removeAllRanges();
      sel.addRange(range);

      // Method 1: Lexical-compatible beforeinput + input events
      try {
        input.dispatchEvent(new InputEvent('beforeinput', {
          bubbles: true, cancelable: true, inputType: 'deleteContentBackward'
        }));
        // Clear
        input.textContent = '';
        input.dispatchEvent(new InputEvent('input', {
          bubbles: true, inputType: 'deleteContentBackward'
        }));
      } catch (_) {}

      // Re-focus and type
      input.focus();

      // Try execCommand first (works with many editors)
      if (document.execCommand('insertText', false, text)) {
        log('⌨️ Typed via execCommand');
        return;
      }

      // Method 2: Set textContent + fire Lexical-compatible input event
      input.textContent = text;
      try {
        input.dispatchEvent(new InputEvent('beforeinput', {
          bubbles: true, cancelable: true, inputType: 'insertText', data: text
        }));
        input.dispatchEvent(new InputEvent('input', {
          bubbles: true, inputType: 'insertText', data: text
        }));
        log('⌨️ Typed via textContent + InputEvent');
      } catch (_) {
        input.dispatchEvent(new Event('input', { bubbles: true }));
        log('⌨️ Typed via textContent + basic Event');
      }
    } else {
      // textarea / input
      const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(input, text); else input.value = text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      log('⌨️ Typed via value setter');
    }
  }

  /** Verify the input contains text (Lexical may take a moment to sync) */
  async function verifyTyped(input, expectedMinLen = 50) {
    for (let i = 0; i < 5; i++) {
      await wait(300);
      const text = input.isContentEditable
        ? (input.textContent || '').trim()
        : (input.value || '').trim();
      if (text.length >= expectedMinLen) return true;
    }
    return false;
  }

  // ═══════════════════════════════════════════════════════════════
  //  ATTACH IMAGES (3 fallback methods)
  // ═══════════════════════════════════════════════════════════════

  async function attachImages(images) {
    if (!images.length) return false;
    log(`🖼️ Attaching ${images.length} images...`);

    // Create File objects
    const files = [];
    for (const img of images) {
      const file = base64ToFile(img.base64, img.name);
      if (file) {
        files.push(file);
        log(`  ✅ File: ${img.name} (${(file.size / 1024).toFixed(0)} KB)`);
      } else {
        log(`  ❌ Failed to create: ${img.name}`);
      }
    }
    if (files.length === 0) { log('❌ No valid files'); return false; }

    // ─── Method 1: File Input ───
    const attached = await tryFileInput(files);
    if (attached) return true;

    // ─── Method 2: Clipboard Paste ───
    const pasted = await tryClipboardPaste(files[0]);
    if (pasted) return true;

    // ─── Method 3: Drag & Drop ───
    const dropped = await tryDragDrop(files);
    if (dropped) return true;

    log('❌ ไม่สามารถแนบรูปได้ทุกวิธี');
    return false;
  }

  /** Method 1: Find file input and set files */
  async function tryFileInput(files) {
    log('🔍 Method 1: File Input...');

    let fileInput = findFileInput();

    // ถ้าไม่เจอ → หาปุ่ม + แล้วคลิก
    if (!fileInput) {
      log('  🔍 ไม่เจอ file input → หาปุ่ม +...');
      const plusBtn = findPlusButton();
      if (plusBtn) {
        log('  🔍 พบปุ่ม +:', plusBtn.getAttribute('aria-label') || '(no label)');
        plusBtn.click();
        await wait(1200);
        fileInput = findFileInput();
      } else {
        log('  ⚠️ ไม่เจอปุ่ม +');
      }
    }

    if (!fileInput) { log('  ❌ ไม่เจอ file input'); return false; }
    log('  ✅ พบ file input:', fileInput.accept || '(no accept)');

    const dt = new DataTransfer();
    for (const f of files) dt.items.add(f);
    fileInput.files = dt.files;
    fileInput.dispatchEvent(new Event('change', { bubbles: true }));
    fileInput.dispatchEvent(new Event('input', { bubbles: true }));
    log(`  ✅ Set ${dt.files.length} files`);

    await wait(2500);
    const hasPreview = checkImagePreview();
    if (hasPreview) log('  ✅ Image preview detected — แนบรูปสำเร็จ');
    else log('  ⚠️ ไม่พบ preview — อาจไม่ได้แนบจริง');
    return true; // return true เพราะ set file สำเร็จ ถึงแม้ preview อาจไม่เจอ
  }

  /** Method 2: Clipboard paste */
  async function tryClipboardPaste(file) {
    log('🔍 Method 2: Clipboard Paste...');
    const input = findInput();
    if (!input) { log('  ❌ ไม่เจอ input'); return false; }

    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const pasteEvent = new ClipboardEvent('paste', {
        bubbles: true, cancelable: true, clipboardData: dt
      });
      input.focus();
      input.dispatchEvent(pasteEvent);
      log('  ✅ Clipboard paste dispatched');
      await wait(2500);
      return checkImagePreview();
    } catch (e) {
      log('  ❌ Paste error:', e.message);
      return false;
    }
  }

  /** Method 3: Drag & drop */
  async function tryDragDrop(files) {
    log('🔍 Method 3: Drag & Drop...');
    const input = findInput();
    if (!input) { log('  ❌ ไม่เจอ input'); return false; }

    try {
      const dt = new DataTransfer();
      for (const f of files) dt.items.add(f);
      const rect = input.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const opts = { bubbles: true, cancelable: true, dataTransfer: dt, clientX: cx, clientY: cy };

      input.dispatchEvent(new DragEvent('dragenter', opts));
      input.dispatchEvent(new DragEvent('dragover', opts));
      input.dispatchEvent(new DragEvent('drop', opts));
      log('  ✅ Drop event dispatched');
      await wait(2500);
      return checkImagePreview();
    } catch (e) {
      log('  ❌ Drop error:', e.message);
      return false;
    }
  }

  function findFileInput() {
    return document.querySelector('input[type="file"][accept*="image"]')
        || document.querySelector('input[type="file"][accept*="video"]')
        || document.querySelector('input[type="file"]');
  }

  function findPlusButton() {
    // By aria-label
    const selectors = [
      'button[aria-label*="attach" i]', 'button[aria-label*="upload" i]',
      'button[aria-label*="add" i]', 'button[aria-label*="เพิ่ม"]',
      'button[aria-label*="แนบ"]',
      'div[role="button"][aria-label*="attach" i]',
      'div[role="button"][aria-label*="upload" i]',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && isVisible(el)) return el;
    }

    // By position: small button near bottom-left (near the chat input)
    const candidates = [...document.querySelectorAll('button, div[role="button"]')].filter(b => {
      if (!isVisible(b)) return false;
      const r = b.getBoundingClientRect();
      return r.bottom > window.innerHeight * 0.7 && r.left < 200 && r.width < 60 && r.height < 60;
    });
    return candidates[0] || null;
  }

  function checkImagePreview() {
    const previews = document.querySelectorAll(
      'img[src*="blob:"], img[src*="data:image"], div[class*="preview"], div[class*="thumbnail"], div[class*="attachment"]'
    );
    return previews.length > 0;
  }

  // ═══════════════════════════════════════════════════════════════
  //  SUBMIT MESSAGE (send button + Enter key, with retry)
  // ═══════════════════════════════════════════════════════════════

  async function submitMessage(input) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      log(`🚀 Submit attempt ${attempt}/3...`);

      // Try 1: Send button click
      const sendBtn = findSendButton();
      if (sendBtn) {
        log('  🔘 Found send button, clicking...');
        sendBtn.click();
        await wait(1500);
        if (isInputCleared(input)) {
          log('  ✅ Message sent via send button');
          return true;
        }
        log('  ⚠️ Send button clicked but input not cleared');
      }

      // Try 2: Enter key
      log('  ⌨️ Trying Enter key...');
      input.focus();
      for (const eventType of ['keydown', 'keypress', 'keyup']) {
        input.dispatchEvent(new KeyboardEvent(eventType, {
          key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
          bubbles: true, cancelable: true
        }));
      }
      await wait(1500);
      if (isInputCleared(input)) {
        log('  ✅ Message sent via Enter');
        return true;
      }

      if (attempt < 3) {
        log('  ⏳ Waiting before retry...');
        await wait(2000);
      }
    }

    log('❌ ส่ง prompt ไม่สำเร็จหลัง 3 ครั้ง');
    return false;
  }

  function isInputCleared(input) {
    const text = input.isContentEditable
      ? (input.textContent || '').trim()
      : (input.value || '').trim();
    return text.length < 20;
  }

  // ═══════════════════════════════════════════════════════════════
  //  PROCESS PROMPT (main pipeline)
  // ═══════════════════════════════════════════════════════════════

  async function processPrompt(payload) {
    const { prompt, characterImageBase64, productImageBase64, productName } = payload;

    log('═══════════════════════════════════════════');
    log('📝 Processing prompt for:', productName);

    // ─── Step 0: Find chat input ───
    let input = null;
    for (let i = 0; i < 20; i++) {
      input = findInput();
      if (input) break;
      await wait(500);
    }
    if (!input) {
      log('❌ ไม่เจอ chat input หลังรอ 10 วินาที');
      reportResult(productName, false, 'chat input not found');
      return;
    }
    log('✅ Found input:', input.tagName, input.getAttribute('data-lexical-editor') ? 'Lexical' : 'standard');

    // ─── Step 1: Type prompt ───
    log('⌨️ Step 1: Typing prompt...');
    typeText(input, prompt);

    const typed = await verifyTyped(input);
    if (!typed) {
      log('⚠️ Prompt ไม่ถูก type — ลองใหม่...');
      typeText(input, prompt);
      await wait(500);
    }
    log('✅ Prompt typed');

    // ─── Step 2: Prepare & attach images ───
    log('🖼️ Step 2: Preparing images...');
    const images = [];

    const prodImg = await ensureBase64(productImageBase64, 'รูปสินค้า');
    if (prodImg) images.push({ base64: prodImg, name: 'product.png' });

    const charImg = await ensureBase64(characterImageBase64, 'รูปตัวละคร');
    if (charImg) images.push({ base64: charImg, name: 'reference.png' });

    log(`🖼️ รูปที่พร้อมแนบ: ${images.length} รูป`);

    if (images.length > 0) {
      const attached = await attachImages(images);
      if (!attached) {
        log('⚠️ แนบรูปไม่สำเร็จ — จะส่งแค่ text prompt');
      }

      // Re-find input (DOM อาจเปลี่ยนหลังแนบรูป)
      input = findInput() || input;

      // ตรวจว่า prompt ยังอยู่ไหม
      const currentText = input.isContentEditable ? (input.textContent || '') : (input.value || '');
      if (currentText.trim().length < 50) {
        log('⚠️ Prompt หายหลังแนบรูป — พิมพ์ใหม่...');
        typeText(input, prompt);
        await wait(800);
      }
    }

    // ─── Step 3: Submit ───
    log('🚀 Step 3: Submitting...');
    const success = await submitMessage(input);

    if (success) {
      log('🎉 ส่ง prompt สำเร็จ:', productName);
      reportResult(productName, true, '');
    } else {
      log('❌ ส่ง prompt ไม่สำเร็จ:', productName);
      reportResult(productName, false, 'submit failed');
    }
  }

  /** Report result back to background/factory */
  function reportResult(productName, success, error) {
    chrome.runtime.sendMessage({
      type: 'META_AI_PROMPT_RESULT',
      payload: { productName, success, error, timestamp: Date.now() }
    }).catch(() => {});
  }

  // ═══════════════════════════════════════════════════════════════
  //  VIDEO CAPTURE (debounced MutationObserver)
  // ═══════════════════════════════════════════════════════════════

  let scanTimer = null;

  function scanForVideos() {
    // ═══ Guard: ไม่มี prompt ที่กำลังรอ → ไม่ scan ═══
    if (!activePromptTimestamp) return;

    document.querySelectorAll('video').forEach(async (video) => {
      const src = video.src || video.currentSrc || video.querySelector('source')?.src || '';
      if (!src || (!src.startsWith('http') && !src.startsWith('blob:'))) return;

      // ═══ Skip คลิปที่มีอยู่ก่อน prompt (baseline) ═══
      if (baselineVideoSrcs.has(src)) return;

      // ═══ Skip คลิปที่ capture แล้ว ═══
      if (capturedVideoSrcs.has(src)) return;

      capturedVideoSrcs.add(src);
      log('🎥 Found NEW video (post-prompt):', src.slice(0, 80));

      try {
        // รอ video โหลดเสร็จ
        if (video.readyState < 2) {
          await Promise.race([
            new Promise(resolve => video.addEventListener('loadeddata', resolve, { once: true })),
            wait(15000)
          ]);
        }

        // Fetch video data
        log('📥 Fetching video data...');
        const resp = await fetch(src);
        if (!resp.ok) { log('❌ Video fetch failed:', resp.status); return; }
        const blob = await resp.blob();

        // ตรวจ size
        if (blob.size < 10000) {
          log('⚠️ Video blob too small:', blob.size, '— skip');
          capturedVideoSrcs.delete(src); // อนุญาต retry
          return;
        }

        log(`📦 Video blob: ${(blob.size / 1024 / 1024).toFixed(1)} MB — converting to base64...`);

        const base64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = () => reject(reader.error);
          reader.readAsDataURL(blob);
        });

        // ═══ Generate thumbnail from video frame ═══
        let thumbnail = '';
        try {
          const blobUrl = URL.createObjectURL(blob);
          thumbnail = await new Promise((resolve) => {
            const v = document.createElement('video');
            v.muted = true;
            v.preload = 'auto';
            v.crossOrigin = 'anonymous';
            const cleanup = () => { try { URL.revokeObjectURL(blobUrl); v.remove(); } catch(_){} };
            const timeoutId = setTimeout(() => { cleanup(); resolve(''); }, 8000);
            v.addEventListener('loadeddata', () => {
              v.currentTime = Math.min(0.5, v.duration * 0.1 || 0.5);
            }, { once: true });
            v.addEventListener('seeked', () => {
              clearTimeout(timeoutId);
              try {
                const canvas = document.createElement('canvas');
                const scale = 120 / Math.max(v.videoWidth, v.videoHeight, 1);
                canvas.width = Math.round(v.videoWidth * scale);
                canvas.height = Math.round(v.videoHeight * scale);
                canvas.getContext('2d').drawImage(v, 0, 0, canvas.width, canvas.height);
                resolve(canvas.toDataURL('image/jpeg', 0.6));
              } catch(_) { resolve(''); }
              cleanup();
            }, { once: true });
            v.addEventListener('error', () => { clearTimeout(timeoutId); cleanup(); resolve(''); }, { once: true });
            v.src = blobUrl;
          });
          if (thumbnail) log('🖼️ Thumbnail generated:', (thumbnail.length / 1024).toFixed(1), 'KB');
        } catch (thumbErr) {
          log('⚠️ Thumbnail generation failed:', thumbErr.message);
        }

        const videoData = { src, base64, timestamp: Date.now(), size: blob.size, promptTimestamp: activePromptTimestamp, thumbnail };
        window.__META_AI_EXPORT_VIDEOS__.push(videoData);
        log(`✅ Video captured #${window.__META_AI_EXPORT_VIDEOS__.length} (${(blob.size / 1024 / 1024).toFixed(1)} MB)`);

        chrome.runtime.sendMessage({
          type: 'META_AI_VIDEO_CAPTURED',
          payload: { src, timestamp: videoData.timestamp, size: blob.size }
        }).catch(() => {});

      } catch (err) {
        log('❌ Video capture error:', err.message || err);
        capturedVideoSrcs.delete(src); // อนุญาต retry
      }
    });
  }

  // Debounced observer: scan max once per 2 seconds
  const observer = new MutationObserver(() => {
    if (scanTimer) return;
    scanTimer = setTimeout(() => {
      scanTimer = null;
      scanForVideos();
    }, 2000);
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // ═══ Initial baseline: snapshot ทุก video ที่มีอยู่แล้ว → ไม่ capture ═══
  setTimeout(() => {
    document.querySelectorAll('video').forEach(video => {
      const src = video.src || video.currentSrc || video.querySelector('source')?.src || '';
      if (src && (src.startsWith('http') || src.startsWith('blob:'))) {
        baselineVideoSrcs.add(src);
      }
    });
    log(`📸 Baseline snapshot: ${baselineVideoSrcs.size} existing videos marked (will be skipped)`);
  }, 2000);

  // ═══════════════════════════════════════════════════════════════
  //  ERROR DETECTION — check Meta AI responses for errors
  // ═══════════════════════════════════════════════════════════════

  const ERROR_PATTERNS = [
    "i can't generate", "i can't create", "i'm unable to",
    "unable to generate", "cannot generate", "cannot create",
    "i'm not able to", "ไม่สามารถสร้าง", "สร้างวิดีโอไม่ได้",
    "content policy", "violates", "against our policies"
  ];

  let errorCheckTimer = null;

  function checkForErrors() {
    // ตรวจเฉพาะ last assistant message (ไม่ scan ทั้ง body)
    const messages = document.querySelectorAll(
      '[class*="message"], [class*="response"], [class*="assistant"], [data-testid*="message"]'
    );
    if (messages.length === 0) return null;

    const lastMsg = messages[messages.length - 1];
    const text = (lastMsg.textContent || '').toLowerCase();

    for (const pattern of ERROR_PATTERNS) {
      if (text.includes(pattern)) {
        return lastMsg.textContent.slice(0, 200);
      }
    }
    return null;
  }

  // ═══════════════════════════════════════════════════════════════
  //  MESSAGE LISTENER
  // ═══════════════════════════════════════════════════════════════

  let _isBusy = false;
  let _lastPromptHash = '';
  let _lastPromptTime = 0;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === 'META_AI_SEND_PROMPT') {
      const promptHash = (msg.payload?.prompt || '').slice(0, 100);
      const now = Date.now();

      // Dedup: ข้าม prompt ซ้ำภายใน 3 วินาที
      if (promptHash === _lastPromptHash && (now - _lastPromptTime) < 3000) {
        log('⚠️ Duplicate prompt (within 3s), skip');
        sendResponse({ started: false, reason: 'duplicate' });
        return true;
      }

      // Busy guard
      if (_isBusy) {
        log('⚠️ Still processing previous prompt, skip');
        sendResponse({ started: false, reason: 'busy' });
        return true;
      }

      _lastPromptHash = promptHash;
      _lastPromptTime = now;
      _isBusy = true;

      // ═══ CRITICAL: Snapshot ทุก video ที่มีอยู่ → baseline ═══
      // ป้องกันการดึงคลิปเก่ามา capture
      document.querySelectorAll('video').forEach(video => {
        const src = video.src || video.currentSrc || video.querySelector('source')?.src || '';
        if (src && (src.startsWith('http') || src.startsWith('blob:'))) {
          baselineVideoSrcs.add(src);
        }
      });
      log(`📸 Pre-prompt baseline updated: ${baselineVideoSrcs.size} videos marked as old`);

      // Clear exported videos จากรอบก่อนหน้า
      window.__META_AI_EXPORT_VIDEOS__ = [];
      activePromptTimestamp = now;
      log(`⏱️ activePromptTimestamp set: ${now}`);

      log('📨 Received META_AI_SEND_PROMPT for:', msg.payload?.productName || 'unknown');

      processPrompt(msg.payload)
        .catch(err => {
          log('❌ processPrompt error:', err);
          reportResult(msg.payload?.productName || 'unknown', false, err.message || String(err));
        })
        .finally(() => { _isBusy = false; });

      sendResponse({ started: true });
    }

    if (msg?.type === 'META_AI_CHECK_STATUS') {
      const errorText = checkForErrors();
      const videoCount = window.__META_AI_EXPORT_VIDEOS__?.length || 0;
      sendResponse({
        busy: _isBusy,
        videoCount,
        error: errorText,
        capturedCount: capturedVideoSrcs.size
      });
    }

    return true;
  });

})();
