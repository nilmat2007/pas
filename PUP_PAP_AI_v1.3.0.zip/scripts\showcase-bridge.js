/**
 * PhimBot — Showcase Sync Bridge for Ai SALER PRO
 * 
 * Content Script ที่ทำหน้าที่เป็นสะพานเชื่อมระหว่าง Ai SALER PRO Tool กับ PhimBot
 * ดึงข้อมูลสินค้า TikTok Showcase ได้ 3 วิธี:
 *   1. API แบบ (เร็วที่สุด, ใช้ cookies TikTok)
 *   2. DOM Scraping (fallback, ดึงจากหน้าเว็บ)
 *   3. จาก PhimBot Storage (ข้อมูลที่ scan ไว้ก่อนหน้า)
 */

console.log("🚀 PhimBot Showcase Bridge Active on TikTok");

// ─── วิธีที่ 1: ดึงผ่าน TikTok API โดยตรง (เร็วสุด) ───
async function fetchShowcaseViaAPI(limit = 50) {
  const allProducts = [];
  let offset = 0;
  let hasMore = true;

  while (hasMore && allProducts.length < limit) {
    try {
      const batchSize = Math.min(50, limit - allProducts.length);
      const res = await fetch(
        `https://shop.tiktok.com/api/v1/streamer_desktop/showcase_product/list?offset=${offset}&count=${batchSize}`,
        { credentials: 'include' }
      );
      const data = await res.json();

      if (!data?.data?.products?.length) break;

      for (const item of data.data.products) {
        const coverUrls = item.cover?.url_list || [];
        const imageUrls = (item.images || []).flatMap(img => (img.url_list || []).slice(0, 1));
        const coverUrl = coverUrls[0] || imageUrls[0] || '';
        const hdUrl = coverUrl.replace(/resize-jpeg:\d+:\d+/g, 'resize-jpeg:540:540');

        allProducts.push({
          productId: item.product_id || '',
          name: item.title || '',
          imageUrl: hdUrl,
          images: imageUrls.map(u => u.replace(/resize-jpeg:\d+:\d+/g, 'resize-jpeg:1080:1080')),
          price: Number(item.price?.original_price || item.price?.sale_price || 0) / 100,
          priceFormatted: item.price ? `฿${(Number(item.price.sale_price || item.price.original_price || 0) / 100).toLocaleString()}` : '',
          stock: item.stock_info?.available_stock || 0,
          soldCount: item.sold_count || 0,
          rating: item.avg_review_score || 0,
          status: item.status === 1 ? 'active' : 'inactive',
          source: 'api',
          scrapedAt: Date.now()
        });
      }

      offset += data.data.products.length;
      if (data.data.products.length < batchSize) hasMore = false;
      if (data.data.total && allProducts.length >= data.data.total) hasMore = false;
    } catch (err) {
      console.error('[Bridge] API fetch error:', err);
      break;
    }
  }

  return {
    success: allProducts.length > 0,
    products: allProducts,
    total: allProducts.length,
    method: 'api'
  };
}

// ─── วิธีที่ 2: ดึงจาก DOM (scrape หน้าเว็บ) ───
function scrapeShowcaseDOM() {
  const products = [];

  // Strategy 1: TikTok Studio product modal (tbody tr)
  const rows = Array.from(document.querySelectorAll('tbody tr')).filter(row => {
    const rect = row.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && /\b\d{10,}\b/.test(row.innerText || '');
  });

  for (const row of rows) {
    try {
      const rowText = (row.innerText || '').trim();
      const idMatch = rowText.match(/\b(1[0-9]{12,}|[2-9][0-9]{12,})\b/);
      if (!idMatch) continue;

      const cells = Array.from(row.querySelectorAll(':scope > td'));
      const nameCell = row.querySelector('.product-name') || cells[1] || cells[0];
      const nameLines = (nameCell?.innerText || '').trim().split('\n').map(s => s.trim()).filter(Boolean);
      const name = nameLines.find(l => !l.includes(idMatch[1]) && !/^฿/.test(l)) || `TikTok ${idMatch[1]}`;
      const img = row.querySelector('img');
      const imageUrl = img?.currentSrc || img?.src || '';
      const priceMatch = rowText.match(/฿\s*([\d,.]+)/);

      products.push({
        productId: idMatch[1],
        name,
        imageUrl,
        images: imageUrl ? [imageUrl] : [],
        price: priceMatch ? Number(priceMatch[1].replace(/,/g, '')) : 0,
        status: /ดำเนินอยู่|วางขาย|active/i.test(rowText) ? 'active' : 'inactive',
        source: 'dom_table',
        scrapedAt: Date.now()
      });
    } catch (e) {
      console.error('[Bridge] Row parse error:', e);
    }
  }

  // Strategy 2: Product cards (generic)
  if (products.length === 0) {
    const cards = document.querySelectorAll(
      '[class*="ProductCard"], [class*="product-item"], [class*="product-card"], ' +
      '[data-e2e*="product"], [class*="showcase-product"]'
    );

    cards.forEach((card, index) => {
      try {
        const name = card.querySelector(
          '[class*="Title"], [class*="product-name"], [class*="name"], h3, h4'
        )?.innerText?.trim() || '';
        const img = card.querySelector('img');
        const imageUrl = img?.currentSrc || img?.src || '';
        const priceEl = card.querySelector('[class*="Price"], [class*="price"]');
        const priceMatch = (priceEl?.innerText || '').match(/[\d,.]+/);

        if (name || imageUrl) {
          products.push({
            productId: `card-${index}-${Date.now()}`,
            name: name || 'สินค้าไม่มีชื่อ',
            imageUrl,
            images: imageUrl ? [imageUrl] : [],
            price: priceMatch ? Number(priceMatch[0].replace(/,/g, '')) : 0,
            status: 'active',
            source: 'dom_card',
            scrapedAt: Date.now()
          });
        }
      } catch (e) {
        console.error('[Bridge] Card parse error:', e);
      }
    });
  }

  return {
    success: products.length > 0,
    products,
    total: products.length,
    method: 'dom'
  };
}

// ─── วิธีที่ 3: ดึงจาก PhimBot storage (ผ่าน background.js) ───
function fetchFromStorage() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'PHIMBOT_GET_PRODUCTS' }, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ success: false, products: [], method: 'storage', error: chrome.runtime.lastError.message });
          return;
        }
        const products = response?.products || [];
        resolve({
          success: products.length > 0,
          products,
          total: products.length,
          method: 'storage'
        });
      });
    } catch (e) {
      resolve({ success: false, products: [], method: 'storage', error: e.message });
    }
  });
}

// ─── Main: ดักฟังคำขอจาก Ai SALER PRO / เครื่องมือภายนอก ───
window.addEventListener("message", async (event) => {
  if (!event.data || event.data.source !== 'PHIMBOT_TOOL_REQUEST') return;

  const { type, options = {} } = event.data;
  console.log(`[Bridge] Received request: ${type}`, options);

  if (type === 'FETCH_SHOWCASE_API' || type === 'SYNC_PRODUCTS') {
    const limit = options.limit || 50;
    const method = options.method || 'auto'; // 'api', 'dom', 'storage', 'auto'
    let result = null;

    try {
      if (method === 'api' || method === 'auto') {
        // ลอง API ก่อน (เร็วที่สุด)
        console.log('[Bridge] 🔄 Trying API method...');
        result = await fetchShowcaseViaAPI(limit);
      }

      if ((!result || !result.success) && (method === 'dom' || method === 'auto')) {
        // Fallback: ดึงจาก DOM
        console.log('[Bridge] 🔄 Falling back to DOM scraping...');
        result = scrapeShowcaseDOM();
      }

      if ((!result || !result.success) && (method === 'storage' || method === 'auto')) {
        // Fallback: ดึงจาก storage
        console.log('[Bridge] 🔄 Falling back to storage...');
        result = await fetchFromStorage();
      }
    } catch (err) {
      console.error('[Bridge] Error:', err);
      result = { success: false, products: null, error: err.message };
    }

    console.log(`[Bridge] 📤 Sending ${result?.products?.length || 0} products (method: ${result?.method || 'none'})`);

    // ส่งข้อมูลกลับไปยัง Ai SALER PRO
    window.postMessage({
      source: 'PHIMBOT_EXTENSION_RESPONSE',
      type: 'SHOWCASE_DATA',
      products: result?.products || null,
      total: result?.total || 0,
      method: result?.method || 'none',
      success: result?.success || false
    }, "*");
  }

  // รองรับคำขอ Handshake (ตรวจสอบว่า Extension พร้อมใช้งาน)
  if (type === 'PING' || type === 'HANDSHAKE') {
    window.postMessage({
      source: 'PHIMBOT_EXTENSION_RESPONSE',
      type: 'PONG',
      version: '1.2.7',
      name: 'PhimBot Showcase Bridge',
      capabilities: ['api', 'dom', 'storage'],
      ready: true
    }, "*");
  }
});

// ─── ส่ง READY signal เมื่อ Bridge โหลดเสร็จ ───
window.postMessage({
  source: 'PHIMBOT_EXTENSION_RESPONSE',
  type: 'BRIDGE_READY',
  version: '1.2.7',
  capabilities: ['api', 'dom', 'storage']
}, "*");

console.log("✅ PhimBot Showcase Bridge Ready!");
