(function initPhimBotTikTokPoster() {
  'use strict';
  if (window.__PHIMBOT_LOADED__) return;
  window.__PHIMBOT_LOADED__ = true;

  /* ─── Utilities ───────────────────────────────────────────────────── */

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  const visible = (el) => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && s.display !== 'none' && s.visibility !== 'hidden';
  };

  const text = (v) => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();

  const findVisible = (selectors) => {
    for (const sel of selectors) {
      const el = Array.from(document.querySelectorAll(sel)).find(visible);
      if (el) return el;
    }
    return null;
  };

  const findButton = (labels, root = document) =>
    Array.from(root.querySelectorAll('button, [role="button"]'))
      .filter(visible)
      .find((btn) => labels.some((l) => text(btn.textContent).toLowerCase().includes(l.toLowerCase())));

  const waitFor = async (factory, timeoutMs = 60000, intervalMs = 400) => {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const result = factory();
      if (result) return result;
      await wait(intervalMs);
    }
    return null;
  };

  const emit = (jobId, step, message, level = 'info') => {
    chrome.runtime.sendMessage({
      type: 'PHIMBOT_TIKTOK_POST_PROGRESS',
      payload: { jobId, step, message, level },
    }).catch(() => {});
  };

  const setNativeValue = (el, value) => {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };

  const dataUrlToFile = (dataUrl, filename) => {
    const match = String(dataUrl || '').match(/^data:([^;,]+);base64,(.+)$/s);
    if (!match) throw new Error('phimbot_video_data_invalid');
    const binary = atob(match[2]);
    const chunks = [];
    for (let off = 0; off < binary.length; off += 1048576) {
      const slice = binary.slice(off, off + 1048576);
      const bytes = new Uint8Array(slice.length);
      for (let i = 0; i < slice.length; i++) bytes[i] = slice.charCodeAt(i);
      chunks.push(bytes);
    }
    return new File(chunks, filename, { type: match[1] || 'video/mp4' });
  };

  /* ─── Page Crash Detection ────────────────────────────────────────── */

  const isPageCrashed = () => {
    const body = text(document.body?.innerText);
    if (!/เกิดข้อผิดพลาด|Something went wrong/i.test(body)) return false;
    const retryBtn = Array.from(document.querySelectorAll('button, [role="button"]'))
      .filter(visible)
      .some((b) => /^(ลองใหม่|Try again|Retry)$/i.test(text(b.textContent)));
    return retryBtn;
  };

  /* ─── Caption Editor Helpers ──────────────────────────────────────── */

  const EDITOR_SELECTORS = [
    '[data-e2e="caption-editor"] [contenteditable="true"]',
    '.public-DraftEditor-content[contenteditable="true"]',
    '.public-DraftEditor-content',
    'div[contenteditable="true"][data-contents="true"]',
    '[contenteditable="true"][role="textbox"]',
    'textarea[placeholder*="caption" i]',
  ];

  const findCaptionEditor = () => findVisible(EDITOR_SELECTORS);

  const editorValue = (editor) =>
    text(editor instanceof HTMLInputElement || editor instanceof HTMLTextAreaElement ? editor.value : editor.textContent);

  async function typeText(editor, value, delayMin = 18, delayRange = 18) {
    for (const char of Array.from(String(value || ''))) {
      if (isPageCrashed()) throw new Error('phimbot_page_crashed');
      if (!editor.isConnected) return false;
      document.execCommand('insertText', false, char);
      await wait(delayMin + Math.floor(Math.random() * delayRange));
    }
    return editor.isConnected;
  }

  async function focusEditorEnd(editor) {
    editor.scrollIntoView?.({ block: 'center', inline: 'nearest' });
    const rect = editor.getBoundingClientRect?.();
    if (rect && rect.width > 0 && rect.height > 0) {
      const pointer = {
        bubbles: true, cancelable: true, composed: true, view: window, pointerType: 'mouse',
        clientX: Math.min(rect.right - 8, Math.max(rect.left + 8, rect.left + rect.width * 0.72)),
        clientY: rect.top + rect.height / 2,
        button: 0, buttons: 1,
      };
      try { editor.dispatchEvent(new PointerEvent('pointerdown', pointer)); } catch (_) {}
      editor.dispatchEvent(new MouseEvent('mousedown', pointer));
      try { editor.dispatchEvent(new PointerEvent('pointerup', pointer)); } catch (_) {}
      editor.dispatchEvent(new MouseEvent('mouseup', pointer));
      editor.dispatchEvent(new MouseEvent('click', pointer));
    }
    editor.focus();
    if (!(editor instanceof HTMLInputElement || editor instanceof HTMLTextAreaElement)) {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(editor);
      range.collapse(false);
      sel.removeAllRanges();
      sel.addRange(range);
    } else {
      editor.setSelectionRange?.(editor.value.length, editor.value.length);
    }
    await wait(180);
  }

  /* ─── Hashtag Helper Functions (OmniPost-faithful) ───────────────── */

  function visibleHashtagSuggestions() {
    return Array.from(document.querySelectorAll('.hashtag-suggestion-item')).filter(visible);
  }

  function normalizeHashtagTopic(value) {
    return text(value).replace(/^#+/, '').split(/[\s·|]/)[0].toLowerCase();
  }

  function matchingHashtagSuggestion(expectedTag) {
    const expected = normalizeHashtagTopic(expectedTag);
    if (!expected) return null;
    return visibleHashtagSuggestions().find((item) => {
      const topic = normalizeHashtagTopic(
        item.querySelector?.('.hash-tag-topic')?.textContent || item.textContent || ''
      );
      return topic === expected;
    }) || null;
  }

  async function waitForHashtagSuggestionsToClose(timeoutMs = 600) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      if (!visibleHashtagSuggestions().length) return true;
      await wait(100);
    }
    return false;
  }

  async function dismissStaleHashtagSuggestions(editor, timeoutMs = 2200) {
    if (await waitForHashtagSuggestionsToClose(500)) return true;
    const keyboard = { bubbles: true, cancelable: true, key: 'Escape', code: 'Escape', keyCode: 27, which: 27 };
    editor.dispatchEvent(new KeyboardEvent('keydown', keyboard));
    editor.dispatchEvent(new KeyboardEvent('keyup', keyboard));
    if (await waitForHashtagSuggestionsToClose(700)) return true;
    editor.blur?.();
    await wait(180);
    await focusEditorEnd(editor);
    return waitForHashtagSuggestionsToClose(Math.max(300, timeoutMs - 1380));
  }

  async function verifyTypedHashtag(editor, candidate, timeoutMs = 2200) {
    const expected = `#${candidate}`.toLowerCase();
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const val = editorValue(editor).toLowerCase();
      if (val.includes(expected)) return true;
      await wait(150);
    }
    return false;
  }

  async function removeTrailingHashtag(editor, tag, hadPrefix) {
    const escaped = String(tag || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const trailingPattern = new RegExp(`\\s*#${escaped}\\s*$`, 'i');
    if (!trailingPattern.test(editorValue(editor))) return;
    if (editor instanceof HTMLInputElement || editor instanceof HTMLTextAreaElement) {
      setNativeValue(editor, String(editor.value || '').replace(trailingPattern, ''));
      return;
    }
    await focusEditorEnd(editor);
    const removeCount = Array.from(`#${tag}`).length + (hadPrefix ? 1 : 0);
    for (let offset = 0; offset < removeCount; offset++) {
      document.execCommand('delete', false, null);
      await wait(12);
    }
  }

  async function chooseFirstHashtagSuggestion(editor, expectedTag) {
    await wait(900);
    const suggestion = await waitFor(() => matchingHashtagSuggestion(expectedTag), 9000, 200);
    if (!suggestion) return null;
    await wait(250);
    const rect = suggestion.getBoundingClientRect();
    const options = {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2,
      button: 0, buttons: 1,
    };
    try { suggestion.dispatchEvent(new PointerEvent('pointerdown', options)); } catch (_) {}
    suggestion.dispatchEvent(new MouseEvent('mousedown', options));
    try { suggestion.dispatchEvent(new PointerEvent('pointerup', options)); } catch (_) {}
    suggestion.dispatchEvent(new MouseEvent('mouseup', options));
    suggestion.dispatchEvent(new MouseEvent('click', options));
    await wait(200);
    if (visibleHashtagSuggestions().length) {
      suggestion.click();
      await wait(120);
    }
    if (visibleHashtagSuggestions().length) {
      const keyboard = { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 };
      editor.dispatchEvent(new KeyboardEvent('keydown', keyboard));
      editor.dispatchEvent(new KeyboardEvent('keyup', keyboard));
    }
    const closed = await waitForHashtagSuggestionsToClose(1600);
    if (!closed) return null;
    return text(suggestion.querySelector?.('.hash-tag-topic')?.textContent || suggestion.textContent);
  }

  /* ─── Step 3: Append Hashtags (OmniPost-faithful) ────────────────── */

  async function appendHashtags(job, editor) {
    let rawTags = [];
    if (Array.isArray(job.hashtags)) {
      rawTags = job.hashtags;
    } else if (typeof job.hashtags === 'string' && job.hashtags.trim()) {
      rawTags = job.hashtags.replace(/,/g, ' ').split(/\s+/);
    }

    // Auto-extract hashtags from caption if job.hashtags was empty
    if (rawTags.length === 0 && job.caption) {
      const match = job.caption.match(/#([a-zA-Z0-9ก-๙_]+)/g);
      if (match) rawTags = match.map(m => m.replace(/^#+/, ''));
    }

    // Fallback to high-converting tags if still empty and autoHashtags is not explicitly disabled
    if (rawTags.length === 0 && job.autoHashtags !== false) {
      rawTags = ['TikTokShop', 'TikTokShopTH', 'ของดีบอกต่อ', 'รีวิว'];
    }

    const hashtags = Array.from(new Set(
      rawTags
        .map((t) => text(t).replace(/^#+/, ''))
        .filter(Boolean)
    )).slice(0, 5);

    if (!hashtags.length) return editor;

    const fallbackTags = [
      'TikTokShop', 'TikTokShopTH', 'ของดีบอกต่อ', 'ป้ายยา', 'รีวิวสินค้า',
      'ช้อปออนไลน์', 'ของมันต้องมี', 'ไอเทมน่าใช้', 'ใช้ดีบอกต่อ', 'รีวิวของดี',
      'พิกัดของดี', 'คุ้มเกินราคา', 'ของดีราคาดี', 'สินค้าขายดี', 'พร้อมส่ง',
      'Shopping', 'OnlineShopping', 'MustHaves', 'TikTokMadeMeBuyIt', 'TikTokShopMadeMeBuyIt',
    ];
    const usedTags = new Set();

    emit(job.id, 'hashtag', `กำลังเพิ่มแฮชแท็ก ${hashtags.length} คำ`);
    let currentEditor = editor;

    for (let i = 0; i < hashtags.length; i++) {
      const tag = hashtags[i];
      currentEditor = currentEditor?.isConnected ? currentEditor : await waitFor(findCaptionEditor, 15000, 350);
      if (!currentEditor) throw new Error('phimbot_hashtag_editor_not_found');

      // Build candidate list: primary tag + fallbacks (excluding used)
      const candidates = Array.from(new Set([tag, ...fallbackTags]))
        .filter((c) => !usedTags.has(c.toLowerCase()))
        .slice(0, 6);

      let selectedText = '';

      for (let ci = 0; ci < candidates.length; ci++) {
        const candidate = candidates[ci];
        currentEditor = currentEditor?.isConnected ? currentEditor : await waitFor(findCaptionEditor, 8000, 200);
        if (!currentEditor) break;

        await focusEditorEnd(currentEditor);
        await dismissStaleHashtagSuggestions(currentEditor, 2200);
        currentEditor = findCaptionEditor() || currentEditor;
        await focusEditorEnd(currentEditor);

        const prefix = Boolean(editorValue(currentEditor));
        if (prefix) await typeText(currentEditor, ' ', 100, 1);
        await typeText(currentEditor, '#', 300, 1);
        const typed = await typeText(currentEditor, candidate, 40, 51);

        if (!typed) {
          emit(job.id, 'hashtag', `ช่องแคปชั่นถูกรีโหลดระหว่างพิมพ์ #${candidate}`, 'warn');
          currentEditor = null;
          break;
        }

        const acceptedByEditor = await verifyTypedHashtag(currentEditor, candidate, 2200);
        if (!acceptedByEditor) {
          emit(job.id, 'hashtag', `ช่องแคปชั่นยังไม่รับ #${candidate} ลองคำใหม่`, 'warn');
          currentEditor = findCaptionEditor() || currentEditor;
          await removeTrailingHashtag(currentEditor, candidate, prefix);
          await dismissStaleHashtagSuggestions(currentEditor, 2200);
          await wait(600);
          continue;
        }

        emit(job.id, 'hashtag', `พิมพ์ #${candidate} แล้ว กำลังรอรายการ (${i + 1}/${hashtags.length})`);
        selectedText = await chooseFirstHashtagSuggestion(currentEditor, candidate);

        if (selectedText) {
          currentEditor = findCaptionEditor() || currentEditor;
          const selectedTag = text(selectedText).replace(/^#/, '').split(/\s+/)[0] || candidate;
          usedTags.add(selectedTag.toLowerCase());
          emit(job.id, 'hashtag', `เลือก ${selectedText} แล้ว`, 'ok');
          break;
        }

        await removeTrailingHashtag(currentEditor, candidate, prefix);
        emit(job.id, 'hashtag', `ไม่พบ #${candidate} ลบแล้ว ลองคำถัดไป`, 'warn');
        await dismissStaleHashtagSuggestions(currentEditor, 2200);
        currentEditor = findCaptionEditor() || currentEditor;
        await focusEditorEnd(currentEditor);
        await wait(700);
      }

      if (!currentEditor) {
        i -= 1;
        await wait(700);
        continue;
      }
      if (!selectedText) emit(job.id, 'hashtag', `ไม่มีคำแนะนำสำหรับช่อง ${i + 1} ข้ามไป`, 'warn');
      await focusEditorEnd(currentEditor);
      await wait(100);
    }

    emit(job.id, 'hashtag', 'เพิ่มแฮชแท็กครบแล้ว', 'ok');
    return currentEditor;
  }

  async function uploadVideo(job) {
    emit(job.id, 'upload', 'กำลังรอช่องอัปโหลดวิดีโอ');
    if (isPageCrashed()) throw new Error('phimbot_page_crashed');

    const input = await waitFor(() => {
      if (isPageCrashed()) return null;
      return document.querySelector('input[type="file"][accept="video/*"]')
        || document.querySelector('input[type="file"][accept*="video"]')
        || document.querySelector('[data-e2e="select_video_container"] input[type="file"]')
        || document.querySelector('input[type="file"]');
    }, 90000);
    if (!input) throw new Error('phimbot_upload_input_not_found');

    const file = dataUrlToFile(job.videoDataUrl, job.filename || `phimbot_${Date.now()}.mp4`);
    const transfer = new DataTransfer();
    transfer.items.add(file);

    emit(job.id, 'upload', `กำลังส่งไฟล์ ${(file.size / 1048576).toFixed(1)} MB`);
    try {
      input.files = transfer.files;
      input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
    } catch {
      const dropZone = document.querySelector('[data-e2e="select_video_container"]')
        || document.querySelector('.upload-card, .upload-stage-container');
      if (!dropZone) throw new Error('phimbot_dropzone_not_found');
      ['dragenter', 'dragover', 'drop'].forEach((type) => {
        dropZone.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, composed: true, dataTransfer: transfer }));
      });
    }

    emit(job.id, 'upload', 'ส่งไฟล์แล้ว กำลังรอ Editor');

    const editor = await waitFor(() => findCaptionEditor(), 180000);
    if (!editor) throw new Error(isPageCrashed() ? 'phimbot_page_crashed' : 'phimbot_editor_timeout');

    // Wait for upload to complete
    emit(job.id, 'upload', 'กำลังรออัปโหลดครบ 100%');
    const start = Date.now();
    while (Date.now() - start < 300000) {
      if (isPageCrashed()) throw new Error('phimbot_page_crashed');
      const container = document.querySelector('[data-e2e="upload_status_container"]');
      if (container) {
        const statusText = text(container.textContent);
        const success = Boolean(
          container.querySelector('.info-status.success, [data-icon="CheckCircleFill"]')
          || /อัปโหลดแล้ว|Uploaded|Upload complete|100\s*%/i.test(statusText)
        );
        if (success) {
          emit(job.id, 'upload', 'อัปโหลดสำเร็จ 100%', 'ok');
          await wait(700);
          break;
        }
      } else if (Date.now() - start >= 20000) {
        const postBtn = findButton(['Post', 'โพสต์']);
        if (findCaptionEditor() && postBtn && !postBtn.disabled) {
          emit(job.id, 'upload', 'หน้าโพสต์พร้อมแล้ว', 'ok');
          break;
        }
      }
      await wait(1000);
    }

    // Wait for editor stability
    let stableCount = 0;
    const readyEditor = await waitFor(() => {
      const ed = findCaptionEditor();
      const hasPreview = Array.from(document.querySelectorAll('video, canvas')).some(visible);
      if (ed && (hasPreview || stableCount > 5)) stableCount++;
      else stableCount = 0;
      return stableCount >= 2 ? ed : null;
    }, 60000, 350);

    if (!readyEditor) throw new Error('phimbot_editor_not_stable');
    emit(job.id, 'upload', 'Editor พร้อมแล้ว', 'ok');
    return readyEditor;
  }

  /* ─── Step 2: Fill Caption ────────────────────────────────────────── */

  async function fillCaption(job, editor) {
    let caption = String(job.caption || '').trim();
    if (!caption) return editor;

    // Clean internal debug bracket tags like [คลิป 1/2 - Hook A]
    caption = caption.replace(/\s*\[คลิป\s*\d+\/\d+[^\]]*\]/g, '').trim();

    // If job has hashtags or autoHashtags is active, strip trailing #hashtags from plain text caption
    // so appendHashtags can add them as real clickable suggestion pills
    if (job.hashtags || job.autoHashtags !== false) {
      const stripped = caption.replace(/(\s*#[a-zA-Z0-9ก-๙_]+)+$/g, '').trim();
      if (stripped) caption = stripped;
    }

    emit(job.id, 'caption', 'กำลังใส่แคปชั่น');
    let currentEditor = editor;

    for (let attempt = 1; attempt <= 3; attempt++) {
      if (isPageCrashed()) throw new Error('phimbot_page_crashed');
      currentEditor = currentEditor?.isConnected ? currentEditor : await waitFor(findCaptionEditor, 20000);
      if (!currentEditor) continue;

      currentEditor.focus();
      await wait(300);

      if (currentEditor instanceof HTMLInputElement || currentEditor instanceof HTMLTextAreaElement) {
        setNativeValue(currentEditor, caption);
      } else {
        document.execCommand('selectAll', false, null);
        document.execCommand('delete', false, null);
        await wait(150);
        await typeText(currentEditor, caption);
      }

      await wait(700);
      if (!currentEditor.isConnected) continue;

      const expected = text(caption).slice(0, 20).toLowerCase();
      const actual = editorValue(currentEditor).toLowerCase();
      if (!expected || actual.includes(expected)) {
        emit(job.id, 'caption', 'ใส่แคปชั่นแล้ว', 'ok');
        return currentEditor;
      }

      emit(job.id, 'caption', `ลองใหม่ (${attempt}/3)`, 'warn');
      currentEditor = null;
      await wait(800);
    }
    throw new Error('phimbot_caption_failed');
  }



  /* ─── Step 4: Apply Sound ─────────────────────────────────────────── */

  async function applySound(job) {
    const settings = job.tiktokSettings || {};
    if (!settings.soundEnabled) {
      emit(job.id, 'sound', 'ข้ามขั้นตอนเพลง', 'ok');
      return;
    }

    emit(job.id, 'sound', 'กำลังเปิดเมนูเพลง');

    // Find and click Sound button
    const soundBtn = await waitFor(() => {
      const candidates = Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible);
      return candidates.find((btn) => /^(เสียง|เพลง|Sound|Music)$/i.test(text(btn.textContent)));
    }, 20000);

    if (!soundBtn) throw new Error('phimbot_sound_button_not_found');
    soundBtn.click();
    await wait(1000);

    // Find sound picker panel
    const picker = await waitFor(() => {
      const panels = Array.from(document.querySelectorAll('div')).filter(visible);
      return panels.find((p) => {
        const t = text(p.textContent);
        return /สำหรับคุณ|For You/i.test(t) && /รายการโปรด|Favorites/i.test(t);
      });
    }, 20000);

    if (!picker) throw new Error('phimbot_sound_picker_not_found');

    // Click the appropriate tab
    const tabLabels = {
      foryou: ['สำหรับคุณ', 'For You'],
      favorites: ['รายการโปรด', 'Favorites'],
      unlimited: ['ไม่จำกัด', 'Unlimited'],
    };
    const tabKey = settings.soundTab || 'foryou';
    const tab = findButton(tabLabels[tabKey] || tabLabels.foryou, picker);
    if (tab) { tab.click(); await wait(900); }

    // Find and click add button at the desired index
    const addBtns = await waitFor(() => {
      const btns = Array.from(picker.querySelectorAll('button, [role="button"]')).filter(visible).filter((btn) => {
        const label = text(btn.getAttribute('aria-label') || btn.textContent);
        const plusIcon = btn.querySelector('[data-icon="PlusBold"]');
        return Boolean(plusIcon) || /^\+$/.test(label) || /^(เพิ่ม|ใช้|Add|Use)/i.test(label);
      });
      return btns.length ? btns : null;
    }, 20000);

    if (!addBtns?.length) throw new Error('phimbot_sound_list_empty');

    const soundIndex = Math.max(0, Math.min((settings.soundIndex || 1) - 1, addBtns.length - 1));
    const selectedBtn = settings.soundSearchMode === 'random'
      ? addBtns[Math.floor(Math.random() * Math.min(settings.soundRandomRange || 5, addBtns.length))]
      : addBtns[soundIndex];

    selectedBtn.scrollIntoView({ block: 'center' });
    selectedBtn.click();
    await wait(1500);

    emit(job.id, 'sound', `เลือกเพลงแล้ว`, 'ok');

    // Volume adjustment (simplified — set via timeline clips if available)
    if (settings.originalVolume !== undefined || settings.addedVolume !== undefined) {
      emit(job.id, 'sound', 'กำลังปรับระดับเสียง');
      await wait(1000);

      // Find volume sliders
      const sliders = Array.from(document.querySelectorAll('input[type="range"], [role="slider"]')).filter(visible);
      for (const slider of sliders) {
        const min = Number(slider.min || slider.getAttribute('aria-valuemin')) || -60;
        const max = Number(slider.max || slider.getAttribute('aria-valuemax'));
        if (min === -60 && max === 20) {
          // This is likely a volume slider
          const vol = settings.addedVolume ?? 50;
          const db = Math.round(0.8 * vol - 60);
          if (slider instanceof HTMLInputElement) setNativeValue(slider, String(db));
          else { slider.setAttribute('aria-valuenow', String(db)); slider.dispatchEvent(new Event('input', { bubbles: true })); }
        }
      }

      // Save sound settings
      const saveBtn = findButton(['บันทึก', 'Save']);
      if (saveBtn) { saveBtn.click(); await wait(1000); }

      emit(job.id, 'sound', 'ปรับเสียงแล้ว', 'ok');
    }
  }

  /* ─── Step 5: Attach Product (based on OmniPost) ──────────────────── */

  async function attachProduct(job) {
    if (job.attachProduct === false) { emit(job.id, 'product', 'ข้ามการปักตะกร้าตามค่าที่ตั้งไว้', 'ok'); return; }
    if (!job.productId) return;
    emit(job.id, 'product', `กำลังปักสินค้า ID ${job.productId}`);

    // Helper: find topmost visible dialog by z-index
    const activeDialog = () => {
      const dialogs = Array.from(document.querySelectorAll('[role="dialog"], .TUXModal, .common-modal, [class*="modal"], [class*="Modal"]')).filter(visible);
      return dialogs.map((node, index) => ({
        node, index,
        zIndex: parseInt(getComputedStyle(node).zIndex, 10) || 0,
        area: node.getBoundingClientRect().width * node.getBoundingClientRect().height,
      })).sort((a, b) => b.zIndex - a.zIndex || b.index - a.index || a.area - b.area)[0]?.node || null;
    };

    const scopedButton = (labels, root) => findButton(labels, root || activeDialog() || document);

    const clickAndWait = async (element, ms = 700) => {
      if (!element) return false;
      element.scrollIntoView?.({ block: 'center', inline: 'center' });
      element.click();
      await wait(ms);
      return true;
    };

    // 1. Wait for anchor container
    emit(job.id, 'product', 'กำลังรอส่วนเพิ่มลิงก์สินค้าพร้อมใช้งาน');
    const anchor = await waitFor(() => {
      const exact = document.querySelector('[data-e2e="anchor_container"]');
      if (exact) return exact;
      const btn = findButton(['Add link', 'เพิ่มลิงก์', 'Add product', 'เพิ่มสินค้า', 'Add', '+ Add']);
      return btn?.closest('[data-e2e], section, div') || null;
    }, 120000, 500);
    if (!anchor) throw new Error('phimbot_product_anchor_not_ready');

    // 2. Click "Add Link"
    const addLink = await waitFor(() => scopedButton(['Add link', 'เพิ่มลิงก์', 'Add product', 'เพิ่มสินค้า', 'เพิ่ม', 'Add', '+ Add'], anchor), 45000);
    if (!addLink) throw new Error('phimbot_add_product_not_found');
    await clickAndWait(addLink, 1200);

    // 3. Find the product modal
    let dialog = await waitFor(activeDialog, 15000);
    if (!dialog) throw new Error('phimbot_product_modal_not_found');

    // 4. Check if search is already visible (sometimes Product type is pre-selected)
    let search = findVisible(['input[placeholder*="Search products" i]', 'input[placeholder*="ค้นหาสินค้า" i]']);
    if (!search) {
      // Select "Product" type
      const productChoice = scopedButton(['Product', 'สินค้า'], dialog)
        || Array.from(dialog.querySelectorAll('label, [role="radio"], .TUXRadio')).filter(visible)
          .find((node) => /สินค้า|product/i.test(text(node.textContent)));
      if (productChoice) await clickAndWait(productChoice, 500);

      const nextButton = scopedButton(['ถัดไป', 'Next'], dialog);
      if (nextButton) await clickAndWait(nextButton, 1200);
    }

    // 5. Click Showcase tab (นำเสนอสินค้า / ตู้โชว์)
    dialog = await waitFor(activeDialog, 15000) || dialog;
    const showcaseTab = Array.from(dialog.querySelectorAll('button, [role="tab"], .TUXTabBar-itemTitle'))
      .filter(visible)
      .find((node) => /showcase|ตู้โชว์|นำเสนอสินค้า/i.test(text(node.textContent)));
    if (showcaseTab) {
      await clickAndWait(showcaseTab, 700);
      emit(job.id, 'product', 'เลือกแท็บ "นำเสนอสินค้า"', 'ok');
    }

    // 6. Wait for search input and search
    search = await waitFor(() => findVisible([
      'input[placeholder*="Search products" i]',
      'input[placeholder*="ค้นหาสินค้า" i]',
    ]), 30000);
    if (!search) throw new Error('phimbot_product_search_not_found');

    setNativeValue(search, String(job.productId));
    search.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
    search.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true }));
    await wait(1800);

    // 7. Find and click product radio
    dialog = search.closest('[role="dialog"], .TUXModal, .common-modal') || activeDialog() || document;
    const radio = await waitFor(() => {
      const rows = Array.from(dialog.querySelectorAll('tbody tr, .product-tb-row, [role="row"]')).filter(visible);
      const matchingRow = rows.find((row) => text(row.textContent).includes(String(job.productId))) || rows[0];
      return matchingRow?.querySelector('input[type="radio"]') || matchingRow?.querySelector('[role="radio"]') || null;
    }, 30000);

    if (!radio) throw new Error('phimbot_product_not_found');
    await clickAndWait(radio.closest('label') || radio, 800);

    // 8. Click next after product if visible
    const nextAfterProduct = scopedButton(['ถัดไป', 'Next'], dialog);
    if (nextAfterProduct) await clickAndWait(nextAfterProduct, 1200);
    dialog = activeDialog() || dialog;

    // 9. Basket CTA name (heuristic scoring like OmniPost)
    let basketNameInput = null;
    let basketConfirmDialog = null;

    const exactButtonIn = (root, labels) => Array.from(root?.querySelectorAll?.('button, .TUXButton, [role="button"]') || [])
      .filter(visible)
      .find((button) => labels.includes(text(button.textContent).toLowerCase())) || null;

    const findBasketConfirmDialog = (input) => {
      let node = input?.parentElement || null;
      while (node && node !== document.body) {
        const context = text(node.textContent).toLowerCase();
        const add = exactButtonIn(node, ['เพิ่ม', 'add', 'ยืนยัน', 'confirm']);
        const cancel = exactButtonIn(node, ['ยกเลิก', 'cancel']);
        if (add && cancel && /ชื่อสินค้า|product name/.test(context)) return node;
        node = node.parentElement;
      }
      return null;
    };

    const ctaToSet = String(job.basketCta || 'กดตะกร้าเลย')
      .replace(/[^\w\s\u0E00-\u0E7F]/g, '')
      .trim().slice(0, 30) || 'กดตะกร้าเลย';
    emit(job.id, 'product', `กำลังตั้งชื่อตะกร้า: ${ctaToSet}`);
    dialog = activeDialog() || dialog;

    const findBasketNameInput = () => {
      const topDialog = activeDialog();
      const roots = Array.from(new Set([topDialog, dialog, document].filter(Boolean)));
      const candidates = roots.flatMap((root) => Array.from(root.querySelectorAll(
        'input[maxlength="30"], textarea[maxlength="30"], input.TUXTextInputCore-input, input[type="text"], textarea, [contenteditable="true"]'
      ))).filter((item, idx, all) => all.indexOf(item) === idx && visible(item) && item !== search && !item.closest('[data-e2e="caption-editor"]'));

      return candidates.map((item) => {
        const context = text(item.closest('label, [class*="input"], [class*="Input"], section, form, div')?.textContent || '');
        const hint = text(`${item.placeholder || ''} ${item.getAttribute('aria-label') || ''} ${context}`).toLowerCase();
        const maxLength = Number(item.maxLength || item.getAttribute('maxlength') || 0);
        let score = 0;
        if (maxLength === 30) score += 12;
        if (/ชื่อสินค้า|product name|ชื่อที่แสดง|display name/.test(hint)) score += 10;
        if (/30\s*\/\s*30|\/\s*30/.test(context)) score += 6;
        if (item.classList.contains('TUXTextInputCore-input')) score += 4;
        if (topDialog?.contains(item)) score += 4;
        if (/ค้นหา|search|caption|คำอธิบาย/.test(hint)) score -= 20;
        return { item, score };
      }).sort((a, b) => b.score - a.score)[0]?.item || null;
    };

    const nameInput = await waitFor(findBasketNameInput, 15000, 300);
    if (nameInput) {
      basketNameInput = nameInput;
      basketConfirmDialog = findBasketConfirmDialog(nameInput)
        || nameInput.closest('[role="dialog"], .TUXModal, .common-modal')
        || activeDialog();

      nameInput.scrollIntoView?.({ block: 'center', inline: 'center' });
      nameInput.click();
      nameInput.focus();
      if (nameInput instanceof HTMLInputElement || nameInput instanceof HTMLTextAreaElement) {
        nameInput.select?.();
        setNativeValue(nameInput, '');
        await wait(120);
        setNativeValue(nameInput, ctaToSet);
      } else {
        document.execCommand?.('selectAll', false, null);
        document.execCommand?.('delete', false, null);
        await wait(120);
        document.execCommand?.('insertText', false, ctaToSet);
      }
      nameInput.dispatchEvent(new Event('change', { bubbles: true }));
      nameInput.dispatchEvent(new Event('blur', { bubbles: true }));
      await wait(500);
      emit(job.id, 'product', `ตั้งชื่อตะกร้าแล้ว: ${ctaToSet}`, 'ok');
    }

    // 10. Click Confirm / Add button (up to 3 attempts)
    const exactConfirmButton = (root) => root ? exactButtonIn(root, ['เพิ่ม', 'add', 'ยืนยัน', 'confirm']) : null;
    const modalClosed = () => !basketConfirmDialog
      || !basketConfirmDialog.isConnected
      || !visible(basketConfirmDialog)
      || (basketNameInput && (!basketNameInput.isConnected || !visible(basketNameInput)));

    let confirmed = false;
    for (let attempt = 1; attempt <= 3; attempt++) {
      const root = basketNameInput?.isConnected
        ? (findBasketConfirmDialog(basketNameInput) || basketConfirmDialog)
        : (basketConfirmDialog || activeDialog() || document);
      const confirmBtn = await waitFor(() => exactConfirmButton(root) || exactConfirmButton(activeDialog()), 10000, 250);
      if (!confirmBtn) throw new Error('phimbot_product_confirm_not_found');
      emit(job.id, 'product', `กำลังกดเพิ่มสินค้า (${attempt}/3)`);
      await clickAndWait(confirmBtn, 500);
      confirmed = Boolean(await waitFor(modalClosed, 5000, 200));
      if (confirmed) break;
      emit(job.id, 'product', `หน้าต่างยังไม่ปิด ลองใหม่ (${attempt}/3)`, 'warn');
    }
    if (!confirmed) throw new Error('phimbot_product_confirm_not_closed');

    // 11. Wait for main editor to be ready again
    emit(job.id, 'product', 'กดเพิ่มแล้ว กำลังรอกลับหน้าหลัก');
    let readyChecks = 0;
    const readyStart = Date.now();
    const mainReady = await waitFor(() => {
      const basketStillVisible = basketNameInput?.isConnected && visible(basketNameInput);
      if (basketStillVisible) return false; // Dialog still open, keep waiting
      // Flexible: any ONE of these means editor is back
      const advancedEl = document.querySelector('[data-e2e="advanced_settings_container"]');
      const anchorEl = document.querySelector('[data-e2e="anchor_container"]');
      const editorEl = findCaptionEditor();
      const postBtn = document.querySelector('button[data-e2e="post_video_button"]');
      const ready = visible(advancedEl) || visible(anchorEl) || Boolean(editorEl) || visible(postBtn);
      readyChecks = ready ? readyChecks + 1 : 0;
      return Date.now() - readyStart >= 1000 && readyChecks >= 2;
    }, 30000, 300);
    if (!mainReady) {
      emit(job.id, 'product', 'ปักสินค้าแล้ว แต่รอหน้า editor กลับช้า (ดำเนินการต่อ)', 'warn');
    } else {
      emit(job.id, 'product', 'ปักสินค้าแล้ว', 'ok');
    }
  }

  /* ─── Step 6: Configure Schedule (OmniPost v1.2.7 style) ──────────── */

  async function configureSchedule(job) {
    if (job.postAction === 'draft') return;

    const scheduled = job.publishMode === 'scheduled';
    emit(job.id, 'schedule', scheduled ? 'กำลังตั้งเวลาโพสต์' : 'โพสต์ทันที');

    const radioSelectors = scheduled
      ? ['input[name="postSchedule"][value="schedule"]', 'input[type="radio"][value="schedule"]']
      : ['input[name="postSchedule"][value="post_now"]', 'input[name="postSchedule"][value="now"]'];

    const radio = radioSelectors.map((s) => document.querySelector(s)).find(Boolean);
    if (!radio && scheduled) throw new Error('phimbot_schedule_radio_not_found');
    if (radio && !radio.checked) radio.click();

    if (!scheduled) return;
    if (!job.scheduledAt) throw new Error('phimbot_schedule_time_missing');

    await wait(1000);

    // ─── Permission Modal (TikTok อนุญาตให้ตั้งเวลา) ───
    const permissionModal = document.querySelector('.TUXModal');
    if (permissionModal && /อนุญาต|allow|permission/i.test(text(permissionModal.textContent))) {
      const allowBtn = findButton(['อนุญาต', 'Allow'], permissionModal);
      if (allowBtn) {
        emit(job.id, 'schedule', 'กำลังอนุญาตให้ TikTok ตั้งเวลาโพสต์');
        allowBtn.click();
        await wait(1500);
      }
    }

    const target = new Date(job.scheduledAt);
    if (!Number.isFinite(target.getTime()) || target.getTime() < Date.now() + 15 * 60000) {
      throw new Error('phimbot_schedule_must_be_15min_ahead');
    }

    // Force minutes to round to nearest multiple of 5 (TikTok only supports 5-min intervals)
    target.setMinutes(Math.round(target.getMinutes() / 5) * 5);
    target.setSeconds(0);
    target.setMilliseconds(0);

    const pad = (v) => String(v).padStart(2, '0');
    const dateValue = `${target.getFullYear()}-${pad(target.getMonth() + 1)}-${pad(target.getDate())}`;
    const timeValue = `${pad(target.getHours())}:${pad(target.getMinutes())}`;

    // Find schedule picker
    const picker = await waitFor(() => {
      const node = document.querySelector('.scheduled-picker');
      return node && visible(node) ? node : null;
    }, 20000);
    if (!picker) throw new Error('phimbot_schedule_picker_not_found');

    const nativeInputs = Array.from(picker.querySelectorAll('.TUXTextInputCore-input')).filter(visible);
    const inputs = nativeInputs.length >= 2 ? nativeInputs : Array.from(picker.querySelectorAll('input')).filter(visible);
    const timeInput = nativeInputs[0] || inputs.find((i) => /^\d{1,2}:\d{2}$/.test(i.value) || /time/i.test(`${i.type} ${i.placeholder}`));
    const dateInput = nativeInputs[1] || inputs.find((i) => /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(i.value) || /date/i.test(`${i.type} ${i.placeholder}`));
    if (!timeInput || !dateInput) throw new Error('phimbot_schedule_inputs_not_found');

    // ─── Set Time (retry up to 3 times) ───
    const normalizeTime = (v) => String(v || '').match(/\b(\d{1,2}):(\d{2})\b/)?.slice(1).map((p) => p.padStart(2, '0')).join(':') || '';
    const chooseTimeOption = async (container, value) => {
      const options = Array.from(container?.querySelectorAll('.tiktok-timepicker-option-item') || []);
      const option = options.find((item) => parseInt(text(item.textContent), 10) === value);
      if (!option) return false;
      option.scrollIntoView?.({ block: 'center', behavior: 'instant' });
      await wait(250);
      const clickEl = option.querySelector('.tiktok-timepicker-option-text') || option;
      try {
        const rect = clickEl.getBoundingClientRect();
        const opts = { bubbles: true, cancelable: true, composed: true, pointerType: 'mouse', button: 0, buttons: 1, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
        clickEl.dispatchEvent(new PointerEvent('pointerdown', opts));
        clickEl.dispatchEvent(new MouseEvent('mousedown', opts));
        await wait(50);
        clickEl.dispatchEvent(new PointerEvent('pointerup', { ...opts, buttons: 0 }));
        clickEl.dispatchEvent(new MouseEvent('mouseup', { ...opts, buttons: 0 }));
      } catch (_) {}
      clickEl.click();
      await wait(350);
      return true;
    };

    let timeVerified = normalizeTime(timeInput.value) === timeValue;
    for (let attempt = 1; !timeVerified && attempt <= 3; attempt++) {
      emit(job.id, 'schedule', `กำลังเลือกเวลา ${timeValue}${attempt > 1 ? ` (ลองใหม่ ${attempt}/3)` : ''}`);
      timeInput.click();
      const timePicker = await waitFor(() => {
        const node = document.querySelector('.tiktok-timepicker-time-picker-container');
        return node && visible(node) ? node : null;
      }, 5000, 150);
      if (!timePicker) throw new Error('phimbot_schedule_time_picker_not_found');
      const columns = timePicker.querySelectorAll('.tiktok-timepicker-time-scroll-container');
      if (columns.length < 2) throw new Error('phimbot_schedule_time_columns_not_found');
      const hourOk = await chooseTimeOption(columns[0], target.getHours());
      const minuteOk = await chooseTimeOption(columns[1], target.getMinutes());
      if (!hourOk || !minuteOk) throw new Error('phimbot_schedule_time_option_not_found');
      document.body.click();
      await wait(400);
      timeVerified = normalizeTime(timeInput.value) === timeValue;
      if (!timeVerified) emit(job.id, 'schedule', `เวลาไม่ตรง: ต้องการ ${timeValue} แต่ได้ ${timeInput.value || '-'}`, 'warn');
    }
    if (!timeVerified) {
      try {
        timeInput.focus();
        timeInput.value = timeValue;
        timeInput.dispatchEvent(new Event('input', { bubbles: true }));
        timeInput.dispatchEvent(new Event('change', { bubbles: true }));
        await wait(300);
        timeVerified = normalizeTime(timeInput.value) === timeValue;
      } catch (_) {}
    }
    if (!timeVerified) throw new Error('phimbot_schedule_time_not_verified');

    // ─── Set Date (Thai + English month name lookup) ───
    if (String(dateInput.value || '').replace(/\//g, '-') !== dateValue) {
      emit(job.id, 'schedule', `กำลังเลือกวันที่ ${dateValue}`);
      dateInput.click();
      const calendar = await waitFor(() => {
        const node = document.querySelector('.calendar-wrapper');
        return node && visible(node) ? node : null;
      }, 5000, 150);
      if (!calendar) throw new Error('phimbot_schedule_calendar_not_found');

      const monthLookup = {
        'มกราคม': 1, 'มค': 1, 'january': 1, 'jan': 1,
        'กุมภาพันธ์': 2, 'กพ': 2, 'february': 2, 'feb': 2,
        'มีนาคม': 3, 'มีค': 3, 'march': 3, 'mar': 3,
        'เมษายน': 4, 'เมย': 4, 'april': 4, 'apr': 4,
        'พฤษภาคม': 5, 'พค': 5, 'may': 5,
        'มิถุนายน': 6, 'มิย': 6, 'june': 6, 'jun': 6,
        'กรกฎาคม': 7, 'กค': 7, 'july': 7, 'jul': 7,
        'สิงหาคม': 8, 'สค': 8, 'august': 8, 'aug': 8,
        'กันยายน': 9, 'กย': 9, 'september': 9, 'sept': 9, 'sep': 9,
        'ตุลาคม': 10, 'ตค': 10, 'october': 10, 'oct': 10,
        'พฤศจิกายน': 11, 'พย': 11, 'november': 11, 'nov': 11,
        'ธันวาคม': 12, 'ธค': 12, 'december': 12, 'dec': 12,
      };

      for (let turn = 0; turn < 12; turn++) {
        const monthText = text(calendar.querySelector('.month-title')?.textContent).replace(/[.\s]/g, '').toLowerCase();
        const yearShown = parseInt(text(calendar.querySelector('.year-title')?.textContent), 10);
        const monthShown = monthLookup[monthText] || 0;
        if (!monthShown || !yearShown ||
            yearShown > target.getFullYear() ||
            (yearShown === target.getFullYear() && monthShown >= target.getMonth() + 1)) break;
        const arrows = calendar.querySelectorAll('.arrow');
        if (arrows.length < 2) break;
        arrows[1].click();
        await wait(500);
      }

      const dayOption = Array.from(calendar.querySelectorAll('.day-span-container .day.valid'))
        .find((node) => parseInt(text(node.textContent), 10) === target.getDate());
      if (!dayOption) throw new Error('phimbot_schedule_date_option_not_found');
      dayOption.click();
      await wait(500);
    }

    if (String(dateInput.value || '').replace(/\//g, '-') !== dateValue) {
      throw new Error('phimbot_schedule_date_not_verified');
    }
    emit(job.id, 'schedule', `ตั้งเวลา ${dateValue} ${timeValue} แล้ว`, 'ok');
    return target.toISOString();
  }

  /* ─── Step 7: Enable AI Content (based on OmniPost) ────────────────── */

  function aiSwitchIsEnabled(container) {
    if (!container) return false;
    const switchContent = container.querySelector('.Switch__content');
    const switchRoot = container.querySelector('.Switch__root');
    const checkbox = container.querySelector('input[type="checkbox"]');
    return [switchContent, switchRoot, container.querySelector('[role="switch"]')].filter(Boolean).some((control) => {
      const ariaChecked = String(control.getAttribute('aria-checked') || '').toLowerCase();
      const dataState = String(control.getAttribute('data-state') || '').toLowerCase();
      return ariaChecked === 'true' || dataState === 'checked' || dataState === 'on';
    }) || checkbox?.checked === true;
  }

  async function clickControl(control) {
    control.scrollIntoView?.({ block: 'center', inline: 'center' });
    const rect = control.getBoundingClientRect();
    const options = {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2,
      button: 0, buttons: 1,
    };
    try { control.dispatchEvent(new PointerEvent('pointerdown', { ...options, pointerType: 'mouse' })); } catch (_) {}
    control.dispatchEvent(new MouseEvent('mousedown', options));
    try { control.dispatchEvent(new PointerEvent('pointerup', { ...options, pointerType: 'mouse' })); } catch (_) {}
    control.dispatchEvent(new MouseEvent('mouseup', options));
    control.click();
  }

  async function enableAiContent(job) {
    if (job.aiContentEnabled === false) { emit(job.id, 'ai-content', 'ข้าม AI Content', 'ok'); return; }
    emit(job.id, 'ai-content', 'กำลังเปิดเนื้อหาที่สร้างโดย AI');

    const advanced = await waitFor(() => {
      const node = document.querySelector('[data-e2e="advanced_settings_container"]');
      return node && visible(node) ? node : null;
    }, 20000, 300);
    if (!advanced) { emit(job.id, 'ai-content', 'ไม่พบ Advanced Settings', 'warn'); return; }

    const findAiContainer = () => {
      const exact = document.querySelector('[data-e2e="aigc_container"]');
      if (exact && visible(exact)) return exact;
      return Array.from(document.querySelectorAll('section, div, label')).filter(visible)
        .find((node) => {
          const own = text(Array.from(node.childNodes).filter((child) => child.nodeType === Node.TEXT_NODE).map((child) => child.textContent).join(' '));
          return /เนื้อหาที่สร้างโดย AI|AI-generated content|Content generated by AI/i.test(own)
            && node.querySelector('[role="switch"], input[type="checkbox"], .Switch__content, .Switch__root');
        }) || null;
    };

    let container = findAiContainer();
    if (!container) {
      const more = Array.from(advanced.querySelectorAll('button, [role="button"], .more-btn'))
        .filter(visible)
        .find((button) => ['แสดงเพิ่มเติม', 'show more', 'more'].includes(text(button.textContent).toLowerCase()));
      if (more) {
        emit(job.id, 'ai-content', 'กำลังกดแสดงเพิ่มเติม');
        await clickControl(more);
        await wait(1000);
      }
      container = await waitFor(findAiContainer, 10000, 250);
    }
    if (!container) { emit(job.id, 'ai-content', 'ไม่พบส่วน AI Content', 'warn'); return; }

    await wait(500);
    const switchContent = container.querySelector('.Switch__content');
    const switchRoot = container.querySelector('.Switch__root');
    let control = switchContent
      || container.querySelector('[role="switch"], input[type="checkbox"]')
      || switchRoot;
    if (!control) { emit(job.id, 'ai-content', 'ไม่พบสวิตช์ AI', 'warn'); return; }

    if (aiSwitchIsEnabled(container)) {
      emit(job.id, 'ai-content', 'เนื้อหาที่สร้างโดย AI เปิดอยู่แล้ว', 'ok');
      return;
    }

    control.scrollIntoView?.({ block: 'center', inline: 'center' });
    emit(job.id, 'ai-content', 'สถานะ AI ปิดอยู่ กำลังกดเปิด');
    control.click();

    let enabled = Boolean(await waitFor(() => aiSwitchIsEnabled(container), 5000, 150));
    if (!enabled) {
      emit(job.id, 'ai-content', 'ลอง clickControl แทน');
      await clickControl(control);
      await wait(700);
      enabled = aiSwitchIsEnabled(container);
    }

    if (enabled) {
      emit(job.id, 'ai-content', 'เปิดเนื้อหาที่สร้างโดย AI แล้ว', 'ok');
      await wait(700);
    } else {
      emit(job.id, 'ai-content', 'ไม่สามารถเปิด AI Content ได้', 'warn');
    }
  }

  /* ─── Step 8: Submit (OmniPost v1.2.7 style) ──────────────────────── */

  // Content / copyright check before submitting
  async function waitForContentCheck(jobId, timeoutMs = 30000) {
    emit(jobId, 'submit', 'รอ TikTok ตรวจสอบเนื้อหา...');
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      // Check for success indicator
      const success = document.querySelector('[data-e2e="copyright_container"] .status-success')
        || document.querySelector('.status-result.status-success[data-show="true"]');
      if (success) { emit(jobId, 'submit', 'ตรวจสอบเนื้อหาผ่าน', 'ok'); return true; }

      // Check for spinning / checking state
      const checking = document.querySelector('[data-e2e="copyright_container"] .spinning')
        || document.querySelector('.status-result.status-checking[data-show="true"]');
      if (!checking) break; // Not checking = not applicable, proceed

      await wait(500);
    }
    emit(jobId, 'submit', 'ข้ามการตรวจสอบเนื้อหา (หมดเวลา)', 'warn');
    return false;
  }

  // Auto-dismiss "โพสต์ต่อหรือไม่" / "Post anyway" dialogs
  function dismissConfirmDialog(jobId) {
    const modals = document.querySelectorAll('.TUXModal, [role="dialog"]');
    for (const modal of modals) {
      const txt = text(modal.textContent);
      if (/โพสต์ต่อ|post anyway|ยืนยัน|continue post/i.test(txt)) {
        const btn = modal.querySelector('.TUXButton--primary')
          || findButton(['โพสต์', 'Post', 'ยืนยัน', 'Confirm'], modal);
        if (btn) {
          emit(jobId, 'submit', 'กดปิด dialog ยืนยัน');
          btn.click();
          return true;
        }
      }
    }
    return false;
  }

  async function submit(job) {
    const saveDraft = job.postAction === 'draft';
    const scheduled = job.publishMode === 'scheduled';
    emit(job.id, 'submit', saveDraft ? 'กำลังบันทึกร่าง' : (scheduled ? 'กำลังกดตั้งเวลา' : 'กำลังกดโพสต์'));

    // Content check before clicking submit
    if (!saveDraft) {
      await waitForContentCheck(job.id, 30000);
    }

    const labels = saveDraft
      ? ['Save draft', 'Draft', 'บันทึกร่าง', 'บันทึกแบบร่าง']
      : (scheduled ? ['Schedule', 'ตั้งเวลา'] : ['Post', 'โพสต์']);

    const button = await waitFor(() => {
      const btn = saveDraft
        ? (document.querySelector('button[data-e2e="save_draft_button"]') || findButton(labels))
        : (document.querySelector('button[data-e2e="post_video_button"]') || findButton(labels));
      return btn && !btn.disabled && btn.getAttribute('aria-disabled') !== 'true' ? btn : null;
    }, 180000);

    if (!button) throw new Error('phimbot_submit_button_not_ready');
    emit(job.id, 'submit', `พบปุ่ม${saveDraft ? 'บันทึกร่าง' : (scheduled ? 'ตั้งเวลา' : 'โพสต์')}แล้ว กำลังกด`);

    // Notify background before clicking
    chrome.runtime.sendMessage({
      type: 'PHIMBOT_TIKTOK_SUBMIT_HANDOFF',
      jobId: String(job.id || ''),
      postAction: job.postAction || 'publish',
      publishMode: job.publishMode || 'now',
    }).catch(() => null);

    button.click();

    // Wait for result + auto-dismiss confirm dialogs
    const confirmed = await waitFor(() => {
      dismissConfirmDialog(job.id);
      // Primary: URL redirect to content page
      return location.pathname.includes('/tiktokstudio/content');
    }, 90000);

    if (!confirmed) throw new Error('phimbot_submit_not_confirmed');
    emit(job.id, 'done', saveDraft ? 'บันทึกร่างสำเร็จ' : (scheduled ? 'ตั้งเวลาโพสต์สำเร็จ' : 'โพสต์สำเร็จ'), 'ok');
  }

  /* ─── Main Runner ─────────────────────────────────────────────────── */

  async function run(job) {
    const editor = await uploadVideo(job);
    const captionEditor = await fillCaption(job, findCaptionEditor() || editor);
    await appendHashtags(job, captionEditor || findCaptionEditor() || editor);
    await applySound(job);
    await attachProduct(job);
    const scheduledAt = await configureSchedule(job);
    await enableAiContent(job);
    await submit(job);
    return { ok: true, scheduledAt };
  }

  /* ─── Message Listener ────────────────────────────────────────────── */

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.action !== 'PHIMBOT_TIKTOK_POST') return false;
    run(message.job || {})
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, reason: String(error?.message || error) }));
    return true;
  });
})();
