/**
 * PhimBot — TikTok Showcase Product Scanner
 * Scans product showcase from TikTok Studio upload page
 * Injected via chrome.scripting.executeScript from background.js
 */

async function phimbotScanShowcase(scanOptions = {}) {
  'use strict';

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const text = (v) => String(v == null ? '' : v).trim();
  const number = (v) => {
    if (typeof v === 'number' && Number.isFinite(v)) return v;
    const m = text(v).replace(/,/g, '').match(/-?\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : 0;
  };
  const compactNumber = (v) => {
    const n = text(v).replace(/,/g, '').toUpperCase();
    const m = n.match(/(-?\d+(?:\.\d+)?)\s*([KMB]?)/);
    if (!m) return 0;
    const mul = { K: 1e3, M: 1e6, B: 1e9 }[m[2]] || 1;
    return Number(m[1]) * mul;
  };
  const visible = (el) => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 3 && r.height > 3 && s.display !== 'none' && s.visibility !== 'hidden';
  };
  const findButton = (labels, root = document) =>
    Array.from(root.querySelectorAll('button, [role="button"], [tabindex]'))
      .filter(visible)
      .find((btn) => labels.some((l) => text(btn.textContent).toLowerCase().includes(l.toLowerCase())));
  const waitFor = async (factory, timeoutMs = 20000, intervalMs = 300) => {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const result = factory();
      if (result) return result;
      await sleep(intervalMs);
    }
    return null;
  };
  const dedupe = (items) => Array.from(new Map(items.filter(Boolean).map((i) => [i.productId, i])).values());

  /* ─── Image extraction helpers ─────────────────────────────── */

  const expandedImageUrls = (url) => {
    const v = text(url);
    if (!/^https?:\/\//i.test(v)) return [];
    const variants = [v];
    try {
      const decoded = decodeURIComponent(v);
      [
        decoded.replace(/([?&](?:width|height|w|h)=)\d+/gi, (_, p) => `${p}720`),
        decoded.replace(/([?&](?:image_size|size)=)\d+x\d+/gi, (_, p) => `${p}720x720`),
      ].forEach((c) => { if (c && c !== v && /^https?:\/\//i.test(c)) variants.push(c); });
    } catch {}
    return variants;
  };

  const collectImageCandidates = (root) => {
    const candidates = [];
    Array.from(root?.querySelectorAll?.('img, source') || []).forEach((img) => {
      [img.currentSrc, img.src, img.getAttribute('src'), img.getAttribute('data-src')]
        .filter(Boolean)
        .forEach((url) => expandedImageUrls(url).forEach((u) => candidates.push(u)));
    });
    return Array.from(new Set(candidates.filter((u) => /^https?:\/\//i.test(u)))).slice(0, 12);
  };

  /* ─── Ensure editor is ready (upload placeholder if needed) ── */

  const hasTikTokEditorAnchor = () => Boolean(document.querySelector('div[data-e2e="anchor_container"]'));

  const ensureEditorReady = async () => {
    if (hasTikTokEditorAnchor()) return true;

    // Try discarding unsaved draft
    const bodyText = text(document.body?.innerText);
    if (/ไม่ได้รับการบันทึก|hasn't been saved/i.test(bodyText)) {
      const discardBtn = findButton(['ละทิ้ง', 'Discard']);
      if (discardBtn) {
        discardBtn.click();
        await sleep(900);
        const confirmBtn = findButton(['ละทิ้ง', 'Discard'], document.querySelector('[role="dialog"]') || document);
        if (confirmBtn && confirmBtn !== discardBtn) { confirmBtn.click(); await sleep(1200); }
      }
    }

    if (hasTikTokEditorAnchor()) return true;

    // Upload a tiny placeholder video to access the product modal
    if (scanOptions.placeholderVideoDataUrl) {
      const match = String(scanOptions.placeholderVideoDataUrl).match(/^data:([^;,]+)?(?:;base64)?,(.*)$/);
      if (match) {
        const binary = atob(match[2] || '');
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const file = new File([bytes], 'phimbot-scan-placeholder.mp4', { type: match[1] || 'video/mp4' });

        const input = await waitFor(() =>
          Array.from(document.querySelectorAll('input[type="file"]'))
            .find((n) => /video|\*/i.test(n.getAttribute('accept') || '')),
          25000, 500
        );

        if (input) {
          const dt = new DataTransfer();
          dt.items.add(file);
          input.files = dt.files;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
    }

    return Boolean(await waitFor(hasTikTokEditorAnchor, 120000, 1000));
  };

  /* ─── Open product modal ───────────────────────────────────── */

  const activeProductModal = () =>
    Array.from(document.querySelectorAll('.TUXModal, .common-modal, [role="dialog"]'))
      .filter(visible)
      .sort((a, b) => b.querySelectorAll('tbody tr').length - a.querySelectorAll('tbody tr').length)[0] || document;

  const clickShowcaseTab = async () => {
    const tabs = Array.from(document.querySelectorAll('.TUXTabBar-itemTitle, [role="tab"], button')).filter(visible);
    const tab = tabs.find((n) => {
      const v = text(n.textContent);
      return v === 'นำเสนอสินค้า' || v === 'Showcase products' || v.includes('Showcase');
    });
    if (tab) { tab.click(); await sleep(800); }
  };

  const ensureProductModal = async () => {
    const hasRows = () => Array.from(document.querySelectorAll('tbody tr'))
      .some((r) => visible(r) && /\b\d{10,}\b/.test(text(r.innerText)));

    if (hasRows()) return true;
    await ensureEditorReady();
    if (hasRows()) return true;

    // Click "Add link" button
    const anchor = document.querySelector('[data-e2e="anchor_container"]');
    const addLink = anchor
      ? (anchor.querySelector('.TUXButton') || findButton(['เพิ่ม', 'Add'], anchor))
      : findButton(['Add link', 'เพิ่มลิงก์', 'เพิ่มสินค้า']);

    if (addLink) { addLink.click(); await sleep(2000); }

    // Select "Product" type if dropdown is visible
    const dropdownBtn = document.querySelector('button[role="combobox"]');
    if (dropdownBtn && visible(dropdownBtn)) {
      const sel = text(dropdownBtn.textContent);
      if (!/สินค้า|Product/i.test(sel)) {
        dropdownBtn.click();
        await sleep(800);
        const opt = Array.from(document.querySelectorAll('[role="option"]'))
          .filter(visible)
          .find((n) => /สินค้า|Product/i.test(text(n.textContent)));
        if (opt) { opt.click(); await sleep(600); }
      }
    }

    // Click "Next"
    const nextBtn = findButton(['ถัดไป', 'Next']);
    if (nextBtn) { nextBtn.click(); await sleep(1500); }

    await clickShowcaseTab();
    await sleep(1000);

    // Wait for products to load
    return Boolean(await waitFor(hasRows, 30000, 500));
  };

  /* ─── Parse product rows ───────────────────────────────────── */

  const parseProductRows = () => {
    const root = activeProductModal();
    return Array.from(root.querySelectorAll('tbody tr'))
      .filter((row) => visible(row) && /\b(1[0-9]{12,}|[2-9][0-9]{12,})\b/.test(text(row.innerText)))
      .map((row) => {
        const rowText = text(row.innerText);
        const idMatch = rowText.match(/\b(1[0-9]{12,}|[2-9][0-9]{12,})\b/);
        const productId = idMatch?.[1] || '';
        if (!productId) return null;

        const cells = Array.from(row.querySelectorAll(':scope > td')).filter((c) => text(c.innerText) || c.querySelector('img'));
        const productCell = row.querySelector('.product-name')?.closest('td') || cells.find((c) => c.querySelector('img')) || cells[1] || row;
        const productLines = text(productCell.innerText).split('\n').map(text).filter(Boolean);

        const name = text(row.querySelector('.product-name')?.textContent)
          || productLines.find((l) => !l.includes(productId) && !/^฿/.test(l) && !/^\d+(\.\d+)?$/.test(l))
          || `TikTok ${productId}`;

        const gallery = collectImageCandidates(productCell);
        const priceText = text(cells.find((c) => /฿|THB/i.test(c.innerText))?.innerText) || rowText.match(/฿\s*[\d,.]+/)?.[0] || '';
        const statusLabel = text(row.querySelector('.product-status')?.textContent) || text(cells[cells.length - 1]?.innerText) || '';
        const stockCandidates = cells.map((c) => text(c.innerText)).filter((v) => /^\d[\d,.KMB]*$/i.test(v));

        return {
          productId,
          name,
          imageUrl: gallery[0] || '',
          galleryImages: gallery,
          price: number(priceText),
          stock: compactNumber(stockCandidates[stockCandidates.length - 1] || '0'),
          stockLabel: stockCandidates[stockCandidates.length - 1] || '',
          currency: 'THB',
          status: /ดำเนินอยู่|วางขาย|active|available/i.test(statusLabel) ? 'active' : 'inactive',
          statusLabel: statusLabel || '',
          scrapedAt: Date.now(),
          source: 'phimbot_scan',
        };
      })
      .filter(Boolean);
  };

  /* ─── Pagination ───────────────────────────────────────────── */

  const paginationRoot = () => {
    const root = activeProductModal();
    return Array.from(root.querySelectorAll('[class*="pagination"], [class*="Pagination"]'))
      .filter((n) => visible(n) && /\d/.test(text(n.textContent)))[0]
      || Array.from(document.querySelectorAll('.tiktok-pagination, .arco-pagination'))
        .filter(visible)[0]
      || null;
  };

  const activePage = () => {
    const root = paginationRoot() || document;
    return text(root.querySelector('.tiktok-pagination-item-is-active, .arco-pagination-item-active, [aria-current="page"]')?.textContent) || '1';
  };

  const findNextButton = () => {
    const root = paginationRoot();
    if (!root) return null;
    const selectors = [
      '.tiktok-pagination-item-right-arrow',
      '.arco-pagination-item-next',
      '[aria-label*="ถัด"]',
      '[aria-label*="Next"]',
    ];
    for (const sel of selectors) {
      const el = root.querySelector(sel);
      if (el && visible(el) && !el.disabled) return el;
    }
    return Array.from(root.querySelectorAll('button, [role="button"]'))
      .filter(visible)
      .find((n) => /^(>|›|»|ถัดไป|next)$/i.test(text(n.textContent)));
  };

  const goToNextPage = async (prevPage, prevFirstId) => {
    const nextBtn = findNextButton();
    if (!nextBtn) return false;
    nextBtn.click();
    // Wait for page change
    for (let i = 0; i < 30; i++) {
      await sleep(250);
      const firstId = parseProductRows()[0]?.productId || '';
      if (activePage() !== prevPage || (firstId && firstId !== prevFirstId)) return true;
    }
    return false;
  };

  /* ─── Main scan loop ───────────────────────────────────────── */

  const limit = Math.max(0, Math.min(5000, Number(scanOptions.limit) || 0));
  const MAX_PAGES = 500;

  await ensureProductModal();

  const allItems = [];
  const visitedPages = new Set();

  for (let page = 0; page < MAX_PAGES; page++) {
    const rows = await waitFor(() => {
      const r = parseProductRows();
      return r.length ? r : null;
    }, 5000, 250) || [];

    const pageKey = `${activePage()}:${rows[0]?.productId || ''}`;
    if (!rows.length || visitedPages.has(pageKey)) break;
    visitedPages.add(pageKey);
    allItems.push(...rows);

    const unique = dedupe(allItems);
    if ((limit && unique.length >= limit) || unique.length >= 5000) break;

    const prevPage = activePage();
    const prevFirstId = rows[0]?.productId || '';
    if (!await goToNextPage(prevPage, prevFirstId)) break;
  }

  const uniqueItems = dedupe(allItems);
  const items = uniqueItems.slice(0, limit || 5000);

  // Get account name
  const accountName = text(document.querySelector('[data-e2e="user-name"]')?.textContent) || 'default';

  return {
    ok: items.length > 0,
    items,
    totalScanned: items.length,
    accountKey: `${location.hostname}:${accountName}`,
    reason: items.length ? '' : 'no_products_found',
  };
}
