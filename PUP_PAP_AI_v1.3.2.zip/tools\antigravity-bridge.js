/**
 * Antigravity <-> PUP PAP AI Live Bridge Server
 * Runs on http://127.0.0.1:19888
 * Allows Antigravity AI to inspect, extract code from, and update Google Flow Tools
 * and interact with the live Chrome Extension in real time.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 19888;
const DUMP_DIR = path.join(__dirname, '..', 'flow_tool_v5');

if (!fs.existsSync(DUMP_DIR)) {
  fs.mkdirSync(DUMP_DIR, { recursive: true });
}

let extensionState = {
  connected: false,
  lastPollAt: 0,
  version: '',
  source: '',
  flowTabs: []
};

const commandQueue = [];
const pendingResolvers = new Map();
const commandHistory = [];

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function sendJson(res, status, data) {
  setCors(res);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try {
        const raw = Buffer.concat(chunks).toString('utf8');
        resolve(raw ? JSON.parse(raw) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    setCors(res);
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);

  try {
    // 1. Status check
    if (url.pathname === '/status' || url.pathname === '/health') {
      const ageMs = Date.now() - extensionState.lastPollAt;
      return sendJson(res, 200, {
        ok: true,
        connected: extensionState.lastPollAt > 0 && ageMs < 10000,
        lastPollAgeMs: extensionState.lastPollAt ? ageMs : null,
        ...extensionState,
        queueLength: commandQueue.length,
        pendingCount: pendingResolvers.size
      });
    }

    // 2. Extension polls for next command
    if (url.pathname === '/poll') {
      extensionState.connected = true;
      extensionState.lastPollAt = Date.now();
      extensionState.version = url.searchParams.get('v') || extensionState.version;
      extensionState.source = url.searchParams.get('src') || extensionState.source;

      const nextCmd = commandQueue.shift() || null;
      return sendJson(res, 200, {
        ok: true,
        command: nextCmd
      });
    }

    // 3. Extension posts result of a command
    if (url.pathname === '/result' && req.method === 'POST') {
      const body = await readBody(req);
      const { id, ok, result, error } = body;

      // Auto-save extracted files if present
      if (result && result.files && typeof result.files === 'object') {
        const savedFiles = [];
        for (const [relPath, content] of Object.entries(result.files)) {
          const safeName = relPath.replace(/^[\/\\]+/, '').replace(/\.\./g, '_');
          const fullPath = path.join(DUMP_DIR, safeName);
          const dir = path.dirname(fullPath);
          if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
          fs.writeFileSync(fullPath, String(content || ''), 'utf8');
          savedFiles.push(fullPath);
        }
        result.savedToDisk = savedFiles;
      }

      commandHistory.unshift({ id, ok, completedAt: new Date().toISOString(), error: error || null });
      if (commandHistory.length > 50) commandHistory.length = 50;

      const pending = pendingResolvers.get(id);
      if (pending) {
        clearTimeout(pending.timer);
        pendingResolvers.delete(id);
        pending.resolve({ id, ok, result, error });
      }

      return sendJson(res, 200, { ok: true });
    }

    // 4. Antigravity sends a command and waits for result
    if (url.pathname === '/exec' && req.method === 'POST') {
      const body = await readBody(req);
      const cmd = body.cmd;
      const args = body.args || {};
      const timeoutMs = Number(body.timeoutMs) || 60000;

      if (!cmd) {
        return sendJson(res, 400, { ok: false, error: 'Missing cmd' });
      }

      const id = 'cmd_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
      const cmdObj = { id, cmd, args, createdAt: Date.now() };

      const resultPromise = new Promise((resolve) => {
        const timer = setTimeout(() => {
          pendingResolvers.delete(id);
          resolve({ id, ok: false, error: `Timeout after ${timeoutMs}ms waiting for Extension response` });
        }, timeoutMs);
        pendingResolvers.set(id, { resolve, timer });
      });

      commandQueue.push(cmdObj);
      const outcome = await resultPromise;
      return sendJson(res, 200, outcome);
    }

    return sendJson(res, 404, { ok: false, error: 'Not found' });
  } catch (err) {
    return sendJson(res, 500, { ok: false, error: err.message || String(err) });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[Antigravity Bridge] Listening on http://127.0.0.1:${PORT}`);
  console.log(`[Antigravity Bridge] Dump directory: ${DUMP_DIR}`);
});
