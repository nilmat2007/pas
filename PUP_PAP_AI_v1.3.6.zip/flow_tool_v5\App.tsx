{
  "name": "ชื่อสินค้าของคุณ",
  "tiktokProductId": "PID_123456",
  "keywords": "คำค้นหา, จุดเด่น1, จุดเด่น2",
  "assets": [
    { "url": "data:image/png;base64,..." }
  ]
}
