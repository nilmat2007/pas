/**
 * flow-video-interceptor.js (v2)
 * MAIN world script สำหรับ iframe ของ Tool (*.scf.usercontent.goog)
 * - ปรับระยะห่าง UI (CSS Spacing Fix) ใน Ai SALER PRO ไม่ให้ปุ่มและข้อความชิดติดกัน
 * - ดักจับ video blob ทุกชนิดที่ Tool สร้าง (video/*, application/octet-stream จาก FFmpeg out.mp4, MediaSource, <a download>, <video src="blob:...">)
 * - ทำความสะอาดรหัสสินค้า (ตัด PID_ และ PID_UNKNOWN) แล้วส่งกลับให้ Extension เก็บเข้าคลังวีดีโออัตโนมัติ
 */
(() => {
  if (!window.__FLOW_EXPORT_VIDEOS__) window.__FLOW_EXPORT_VIDEOS__ = [];
  if (!window.__PHIMBOT_CAPTURED_BLOB_SIGS__) window.__PHIMBOT_CAPTURED_BLOB_SIGS__ = new Set();

  // ═══════════ 0. Inject Clean UI Spacing CSS into Ai SALER PRO iframe ═══════════
  const injectSpacingCss = () => {
    try {
      if (document.head && !document.getElementById('phimbot-flow-tool-spacing-fix')) {
        const st = document.createElement('style');
        st.id = 'phimbot-flow-tool-spacing-fix';
        st.textContent = `
          body { padding: 6px 10px !important; box-sizing: border-box !important; }
          section, .card, [class*="card"], [class*="panel"] { margin-bottom: 10px !important; }
          button, select, input, textarea { margin-top: 3px !important; margin-bottom: 3px !important; }
          h1, h2, h3, h4 { margin-top: 6px !important; margin-bottom: 6px !important; line-height: 1.35 !important; }
        `;
        document.head.appendChild(st);
      }
    } catch (_) {}
  };
  injectSpacingCss();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectSpacingCss, { once: true });
  }

  if (window.__PHIMBOT_VIDEO_INTERCEPTOR_V2__) return;
  window.__PHIMBOT_VIDEO_INTERCEPTOR_V2__ = true;
  window.__PHIMBOT_VIDEO_INTERCEPTOR__ = true;

  console.log('[PhimBot] 🎬 Video Interceptor v2 loaded on:', location.href.slice(0, 80));

  const cleanPid = (raw) => {
    const s = String(raw || '').trim();
    if (!s) return '';
    const stripped = s.replace(/^PID_/i, '').trim();
    if (!stripped || /^(unknown|null|undefined|none|n\/a|-)$/i.test(stripped)) return '';
    return stripped;
  };

  window.__phimbotResolveProductMeta = () => {
    const inj = window.__PHIMBOT_INJECTED_PAYLOAD__?.products?.[0]
      || window.__PHIMBOT_CLIPBOARD_DATA__?.products?.[0]
      || window.__PHIMBOT_CLIPBOARD_DATA__
      || {};
    const pid = cleanPid(inj.tiktokProductId || inj.productId || '');
    const pName = (inj.name || '').trim() || 'สินค้าจาก AI SALER PRO';
    const pUrl = (inj.productUrl || inj.affiliateUrl || '').trim();
    return {
      productId: pid,
      productName: pName,
      productUrl: pUrl,
      platform: pUrl.includes('shopee') ? 'shopee' : 'tiktok'
    };
  };

  window.__phimbotCaptureVideoBlob = (blob, sourceUrl = '', label = '') => {
    try {
      if (!(blob instanceof Blob)) return;
      const bType = String(blob.type || '').toLowerCase();
      const isVideoMime = bType.startsWith('video/');
      const isOctetVideo = (bType === 'application/octet-stream' || bType === '') && blob.size > 60000;
      if (!isVideoMime && !isOctetVideo) return;
      if (blob.size < 40000) return;

      const sigKey = `${blob.size}_${bType}`;
      if (window.__PHIMBOT_CAPTURED_BLOB_SIGS__.has(sigKey)) return;
      window.__PHIMBOT_CAPTURED_BLOB_SIGS__.add(sigKey);

      const videoBlob = isVideoMime ? blob : new Blob([blob], { type: 'video/mp4' });
      const reader = new FileReader();
      reader.onload = () => {
        let base64 = String(reader.result || '');
        if (!base64 || base64.length < 50000) return;
        if (base64.startsWith('data:application/octet-stream')) {
          base64 = base64.replace('data:application/octet-stream', 'data:video/mp4');
        }
        const meta = window.__phimbotResolveProductMeta();
        const exportPayload = {
          productId: meta.productId,
          productName: meta.productName,
          productUrl: meta.productUrl,
          headline: label || `${meta.productName} รีวิวของดีบอกต่อ`,
          videoBase64: base64,
          videoUrl: sourceUrl,
          thumbnail: '',
          caption: `${meta.productName} รีวิวของดีบอกต่อ`,
          hashtags: '#TikTokShop #รีวิว #ป้ายยา',
          platform: meta.platform
        };
        if (!window.__FLOW_EXPORT_VIDEOS__) window.__FLOW_EXPORT_VIDEOS__ = [];
        window.__FLOW_EXPORT_VIDEOS__.push(exportPayload);
        const msg = { type: 'EXT_EXPORT_VIDEO', payload: exportPayload };
        window.postMessage(msg, '*');
        try { window.parent.postMessage(msg, '*'); } catch (_) {}
        console.log('[PhimBot] 📤 Captured & exported video blob! Size:', blob.size, 'Total:', window.__FLOW_EXPORT_VIDEOS__.length);
      };
      reader.readAsDataURL(videoBlob);
    } catch (e) {
      console.warn('[PhimBot] Video capture error:', e);
    }
  };

  // ═══════════ 1. ดักจับ URL.createObjectURL ═══════════
  const origCreateObjectURL = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (obj) {
    const url = origCreateObjectURL(obj);
    try {
      if (obj instanceof Blob) {
        window.__phimbotCaptureVideoBlob(obj, url, 'วิดีโอ AI ผลิตเสร็จ');
      }
    } catch (_) {}
    return url;
  };

  // ═══════════ 2. ดักจับ <a download>.click() ═══════════
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    try {
      if (this.href && (this.href.startsWith('blob:') || this.download)) {
        const dlName = this.download || 'วิดีโอ AI ผลิตเสร็จ';
        fetch(this.href)
          .then(r => r.blob())
          .then(blob => window.__phimbotCaptureVideoBlob(blob, this.href, dlName))
          .catch(() => {});
      }
    } catch (_) {}
    return origClick.call(this);
  };

  // ═══════════ 3. Scan DOM สำหรับ <video src="blob:..."> หรือ <a download> ═══════════
  const scannedUrls = new Set();
  setInterval(() => {
    injectSpacingCss();
    try {
      document.querySelectorAll('video, a[download]').forEach(el => {
        const src = el.src || el.currentSrc || el.href || '';
        if (!src || scannedUrls.has(src)) return;
        if (src.startsWith('blob:') || (el.tagName === 'VIDEO' && src.startsWith('http'))) {
          scannedUrls.add(src);
          fetch(src)
            .then(r => r.blob())
            .then(blob => window.__phimbotCaptureVideoBlob(blob, src, el.download || 'วิดีโอ AI ผลิตเสร็จ'))
            .catch(() => {});
        }
      });
    } catch (_) {}
  }, 2500);
})();
