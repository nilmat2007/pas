const prompt = `กรุณาแก้ไขโค้ด UI Layout, Margin, Padding และการซ้อนทับกันขององค์ประกอบใน ProductionMonitor.tsx, App.tsx และ BatchManager.tsx ให้เรียบร้อยสวยงาม (รองรับหน้าจอขนาดกลางเมื่อเปิดคู่กับ Chrome Sidepanel ด้านขวา) ดังนี้:

1. แก้ไขหน้า ProductionMonitor (ProductionMonitor.tsx) ไม่ให้ซ้อนทับกันเด็ดขาด:
- แถบป้ายด้านบน ("หน้าจอแสดงผลสดจากระบบ" และ "มอนิเตอร์ 01.A"): ห้ามใช้ class absolute top-0 left-0 เพราะทำให้กรอบจอมือถือ 9:16 ไปซ้อนทับป้าย ให้แยกออกมาเป็นแถว Flex ปกติด้านบนสุดของฝั่งขวา มี mb-4 pb-3 border-b border-white/10 flex items-center justify-between shrink-0
- กรอบจอมือถือ 9:16 (Live Preview): ห้ามล็อกความกว้างใหญ่เกินไปจนความสูงทะลุไปทับป้ายด้านบนและทับกล่อง Log ด้านล่าง ให้ใส่ Container รอบจอมือถือเป็น flex-1 min-h-0 flex items-center justify-center py-3 my-2 overflow-hidden และตัวกรอบจอมือถือใช้ h-full max-h-[44vh] w-auto aspect-[9/16] mx-auto bg-[#111] rounded-[28px] border-[6px] border-white/10 shadow-2xl overflow-hidden relative shrink-0 เพื่อให้ย่อขยายพอดีพื้นที่ว่างตรงกลางเสมอ มีระยะห่าง (Margin) ชัดเจนทั้งด้านบนและด้านล่าง
- กล่อง Terminal Logs (AI_PROD_OS >) ด้านล่าง: ให้มี mt-3 h-[125px] p-4 rounded-2xl bg-black/50 border border-white/10 shrink-0 overflow-y-auto แยกเป็นสัดส่วนไม่ซ้อนกับกรอบจอมือถือ
- แถบซ้ายของ ProductionMonitor (สายการผลิตอัตโนมัติ): ปรับความกว้างเป็น w-full md:w-[280px] lg:w-[310px] พร้อม p-5 gap-3 และปุ่มด้านล่าง ("ดูหน้าตั้งค่า" / "หยุดผลิต") ให้มี p-4 gap-2.5 border-t border-white/10 mt-auto ไม่เบียดชิดขอบ

2. แก้ไขหน้าหลัก (App.tsx และ BatchManager.tsx) ให้มี Margin และ Padding ที่เป็นระเบียบ:
- ปรับ Sidebar ด้านซ้ายให้ใช้ w-full md:w-[300px] lg:w-[320px] p-5 gap-6 shrink-0 เพื่อเหลือพื้นที่ฝั่งขวา (คลังไอเดียโฆษณา IDEA BANK) กว้างขึ้นเมื่อเปิดคู่กับแถบ Extension
- ในพื้นที่หลักฝั่งขวา (Main Workspace) ใช้ flex-1 p-6 md:p-8 overflow-y-auto space-y-6 และปรับ Grid ของการ์ดในคลังไอเดียโฆษณา (IDEA BANK) ให้มี gap-4 p-5 ขอบการ์ดไม่เบียดกัน และข้อความหัวข้อมี leading-relaxed mb-2 อ่านง่ายไม่ซ้อนทับกัน

3. รักษาการตั้งค่าเชื่อมต่อกับ Extension:
- ตอนรับข้อมูลตัวละครจาก Extension (influencer.gender) หากเป็น 'male' ให้ตั้งค่าเพศและคำลงท้ายเป็น 'male' ('ชาย (ครับ)') ทันที
- ใน finalizeCampaign ใช้ ffmpegService.exec(['-f', 'concat', '-safe', '0', '-i', 'list.txt', '-c:v', 'copy', '-c:a', 'aac', '-ar', '44100', '-ac', '2', '-b:a', '128k', '-y', 'out.mp4']) และ new Blob([res], { type: 'video/mp4' })`;

async function run() {
  const res = await fetch('http://127.0.0.1:19888/exec', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      cmd: 'FLOW_SEND_BUILDER_PROMPT',
      args: { prompt },
      timeoutMs: 25000
    })
  });
  const data = await res.json();
  console.log(JSON.stringify(data, null, 2));
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
